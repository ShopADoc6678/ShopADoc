<?php global $product; ?>
<div class='swf_container'>
	<span class='swf_message'></span>
	<button class="swf_add_to_favourites" data-productid='<?php echo $product->id; ?>'><i class="far fa-heart">&nbsp;</i></button>
</div>