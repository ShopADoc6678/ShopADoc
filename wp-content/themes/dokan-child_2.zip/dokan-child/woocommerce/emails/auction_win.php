<?php
/**
 * Email auction won
 *
 */
if (!defined('ABSPATH')) exit ; // Exit if accessed directly
$product_data = wc_get_product($product_id);
$post   = get_post($product_id);
$Client = get_user_by( 'id', $post->post_author );
$client_name = $Client->first_name.' '.$Client->last_name;
$client_email = $Client->user_email;
$client_cell_ph = get_user_meta($post->post_author, 'client_cell_ph', true );

$dentist = get_user_by('email',$user_email);
$designation = get_user_meta($dentist->ID, 'designation', true );
if($designation!=""){
	$winnner_name = $dentist->first_name.' '.$dentist->last_name." ".$designation;
}else{
	$winnner_name = $dentist->first_name.' '.$dentist->last_name;
}
$winnner_id = $dentist->ID;
$user_id = $dentist->ID;
$dentist_street = get_user_meta( $user_id, 'dentist_office_street', true);
$dentist_apt_no = get_user_meta( $user_id, 'dentist_office_apt_no', true);
$dentist_city = get_user_meta( $user_id, 'dentist_office_city', true);
$dentist_state = get_user_meta( $user_id, 'dentist_office_state', true);
$dentist_zip_code = get_user_meta( $user_id, 'dentist_office_zip_code', true);
$dentist_cell_ph = get_user_meta( $user_id, 'dentist_personal_cell', true );
$dentist_state = $US_state[$dentist_state];
$dentist_address = $dentist_street." ".$dentist_apt_no." ".$dentist_city." ".$dentist_state." ".$dentist_zip_code;
?>
<style type="text/css">
#template_header{ background-color: #000 !important; }
</style>
<?php do_action( 'woocommerce_email_header', $email_heading, $email ); ?>
<?php /*?>
<?php if( ( $product_data->get_auction_type() == 'reverse' ) && ( get_option('simple_auctions_remove_pay_reverse') == 'yes')  ) { ?>

<p><?php printf( __( "Congratulations. You have won the auction.<br /><br />Service: <a href='%s'>%s</a><br />Winning Bid: %s.", 'wc_simple_auctions' ), get_permalink( $product_id ), $product_data -> get_title(), wc_price( $current_bid ) ); ?></p>
<?php } else { ?>
<p><?php printf(__( "Congratulations. You have won the auction.<br /><br />Service: <a href='%s'>%s</a><br />Winning Bid: %s.<br /><br />Please click on this link to pay for your auction %s ", 'wc_simple_auctions' ), get_permalink( $product_id  ), $product_data -> get_title(), wc_price( $current_bid ), '<a href="' . esc_attr( add_query_arg( "pay-auction",$product_id, $checkout_url ) ). '">' . __( 'payment', 'wc_simple_auctions' ) . '</a>' ); ?></p>
<?php } ?>
<?php */?>
<div style="margin-bottom: 40px;margin-top: 0;">
<?php /*?>
  <table cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="0">
    <tbody>
    <tr>
        <td colspan="2" align="center" style="text-align:center;font-style:italic;padding:0 0 12px 0;"><p style="text-align:center;font-style:italic;margin:0;padding:0;"><img src="<?php echo get_site_url().'/wp-content/themes/dokan-child/win-email-photo.jpg';?>" border="0" alt="" title="shopadoc"></p></td>
      </tr>
      <tr>
        <td colspan="2" style="padding:0 0 12px 0;"><strong>Winner:</strong> <?php echo $winnner_name; ?> ID: <?php echo $winnner_id;?><br /><strong>Dentist Office & Contact:</strong> <?php echo $dentist_address;?> / <?php echo $dentist_cell_ph;?> / <?php echo $user_email;?></td>
      </tr>
      <tr>
        <td colspan="2" style="padding:0 0 12px 0;"><strong>Client:</strong> <?php echo $client_name; ?> ID: <?php echo $post->post_author;?><br /><strong>Contact Info:</strong> <?php echo $client_cell_ph;?> / <?php echo $client_email;?></td>
      </tr>
      <tr>
        <td width="48%" style="padding:0;"><table cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="0">
            <tr>
              <td style="padding:0;">Auction ID:</td>
              <td style="padding:0;"><?php echo $product_id; ?></td>
            </tr>
            <tr>
              <td style="padding:0 0 12px 0">Service:</td>
              <td style="padding:0;"><a href='<?php echo get_permalink( $product_id  );?>'><?php echo $product_data -> get_title();?></a></td>
            </tr>
          </table></td>
        <td width="52%" style="padding:0;vertical-align:top;"><table cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="0">
            <tr>
              <td style="padding:0;">Winning Bid:</td>
              <td style="padding:0;"><?php echo wc_price( $current_bid ); ?></td>
            </tr>
            <tr>
              <td style="padding:0;">&nbsp;</td>
              <td style="padding:0;">&nbsp;</td>
            </tr>
          </table></td>
      </tr>
      <tr>
        <td colspan="2" align="center" style="text-align:center;font-style:italic;padding:0;"><p style="text-align:center;font-style:italic;"><strong>We appreciate the opportunity to be of service and extend our warmest regards to you both.</strong></p>
        <p style="text-align:center;font-style:italic;"><strong>Staff of ShopADoc ® The Dentist Marketplace, Inc.</strong></p></td>
      </tr>
    </tbody>
  </table>
  <?php */?>
  <div style="margin-bottom: 30px;top: -30px;padding:0;">
  <table width="100%" border="0">
  <tr>
    <td align="center" style="padding:0;vertical-align:top;"><p style="text-align:center;font-style:italic;margin:0;padding:0;"><img src="<?php echo get_site_url().'/wp-content/themes/dokan-child/win-email-photo.jpg';?>" border="0" alt="" title="shopadoc" ></p></td>
  </tr>
</table>
</div>
  <table width="100%" border="0">
  <tr>
    <td width="50%" style="padding:0;vertical-align:top;">Auction ID:&nbsp;<?php echo $product_id; ?></td>
    <td width="50%" style="padding:0;vertical-align:top;">Winning Bid:&nbsp;<?php echo wc_price( $current_bid ); ?></td>
  </tr>
  <tr>
    <td style="padding:0;vertical-align:top;">Service:&nbsp;<a href='<?php echo get_permalink( $product_id  );?>'><?php echo $product_data -> get_title();?></a></td>
    <td style="padding:0;vertical-align:top;">&nbsp;</td>
  </tr>
</table>

<table width="100%" border="1">
  <tr>
    <td width="50%"><strong><strong>Winner:</strong></strong></td>
    <td width="50%"><strong>Client:</strong></td>
  </tr>
  <tr>
    <td><?php echo $winnner_name; ?>&nbsp;&nbsp;&nbsp;ID:&nbsp;<?php echo $winnner_id;?></td>
    <td><?php echo $client_name; ?>&nbsp;&nbsp;&nbsp;ID:&nbsp;<?php echo $post->post_author;?></td>
  </tr>
  <tr>
    <td><?php echo $dentist_address;?></td>
    <td><?php echo $client_cell_ph;?> </td>
  </tr>
  <tr>
    <td><?php echo $dentist_cell_ph;?> / <?php echo $user_email;?></td>
    <td><?php echo $client_email;?></td>
  </tr>
</table>
<table width="100%" border="0">
  <tr>
    <td align="center"><p style="text-align:center;font-style:italic;">We appreciate the opportunity to be of service<br />and extend our warmest regards to you both.</p><p style="text-align:center;font-style:italic;">Staff of ShopADoc® The Dentist Marketplace, Inc</p></td>
  </tr>
</table>
</div>
<?php do_action( 'woocommerce_email_footer', $email ); ?>