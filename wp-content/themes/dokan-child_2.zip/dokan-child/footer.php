<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package dokan
 * @package dokan - 2014 1.0
 */
 global $woocommerce
 //var_dump($woocommerce->session->get_session_cookie());

?>
</div>
<!-- .row -->
</div>
<!-- .container -->
<?php 
global $wp;
$current_url =  home_url($wp->request);
$dentist_account_status = get_user_meta(get_current_user_id(), 'dentist_account_status', true );
$dentist_account_status = get_user_meta(get_current_user_id(), 'dentist_account_status', true );
$plan_orderid = get_plan_orderid();
$plan_status = get_post_meta($plan_orderid,'_plan_status', true );
if(($dentist_account_status !='unsubscribe' && $dentist_account_status !='de-active') || strpos($current_url,"/checkout") > 0){?>
	<style type="text/css">
		.sgpb-content-2721,.sgpb-popup-overlay-2721{display:none;}
		.sgpb-overflow-hidden {
			width: 100%;
			height: 100%;
			overflow: auto !important;
		}
	</style>
<?php 
}

	if(strpos($current_url,"auction-activity/auction") > 0 || strpos($current_url,"shopadoc-auction-activity") > 0){?>
    <style type="text/css">
		#main.site-main {
			min-height: calc(100vh - 31.7333px - 45px - 242px);
		}
		@media only screen and (max-width: 448px) {
			#main.site-main{
				min-height: calc(100vh - 31.7333px - 29px - 342px) !important;
			}
		}
	</style>
    <?php }?>
    <?php if(is_product() || strpos($current_url,"/auction-") > 0){?>
    	<style type="text/css">
		#main.site-main {
			min-height: calc(100vh - 31.7333px - 45px - 242px);
		}
		@media only screen and (max-width: 448px) {
			#main.site-main{
				min-height: calc(100vh - 31.7333px - 29px - 352px) !important;
			}
		}
	</style>
    <?php }?>
    <?php if(is_product() || (strpos($current_url,"/auction-") > 0 && strpos($current_url,"/auction-activity") === false ) || strpos($current_url,"auction-activity/auction") > 0 || strpos($current_url,"shopadoc-auction-activity") > 0){?>
    <?php if($_GET['action'] != 'edit'){?>
<div class="container content-wrap">
<?php do_shortcode("[ad_section]");?>
</div>
<?php }?>
<?php }?>
</div>
<!-- #main .site-main -->
<?php
add_thickbox();
//the_ad_group(59);
?>

<style type="text/css">
.fa {
	font-size:2em;
}
ul.panel-icon li {
	padding:15px 5px;
}
.jsProfileType h3 {
	font-weight:normal !important;
}
.bg {
	background-image: linear-gradient(to bottom, #fefefe, #f6f6f6) !important;
	background-repeat: repeat-x !important;
	color:#818588;
	padding:1%;
	cursor:pointer;
	font-weight:bold;
	border:solid 1px #e9e9e9;
}
.bg h3 {
	color:#818588 !important;
	font-weight:bold !important;
	font-size:23px !important;
}
.bg_opacity {
	border: 6px solid #e9e9e9;
	border-radius: 10px;
	opacity: 0.4;
	padding:6px;
	cursor:default;
}
.gantry-width-20 {
	width:20%;
}
.gantry-width-3 {
	float: left;
	width: 4%;
	margin-top: -41px;
}
.blue {
	color:#e67902;
}
.gantry-width-30 {
	width:28.5%;
}
.gantry-width-49 {
	width:48%;
	padding:2%;
	float:left;
	margin-top:10px;
}
.hide {
	display:none;
}
.mainDiv {
	float:left;
	margin:0 auto;
	padding-bottom:10px;
	width:100%;
}
.childDiv {
	float:left;
	margin:0 auto;
	clear:both;
	padding-bottom:10px;
	width:100%;
}
.div100 {
	float:left;
	width:100%;
}
.rt-center {
	text-align:center;
}
</style>
<?php 
if(isset($_GET['TestMode'])&& $_GET['TestMode']==1){
	?>
	<style type="text/css">
		.woocommerce-account .woocommerce-MyAccount-navigation{
			display:block !important;
		}
		.woocommerce-account .woocommerce-MyAccount-content{
			width:75% !important;;
		}
	</style>
	<?php
}
?>
<!--<div style="text-align:center;padding:20px 0;"> 
<input class="sg-popup-id-675" type="button" value="Show Thickbox Example Pop-up 1" />  
</div>-->
<footer id="colophon" class="site-footer" role="contentinfo">
  <div class="footer-widget-area">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <?php dynamic_sidebar( 'footer-1' ); ?>
        </div>
        <div class="col-md-3">
          <?php dynamic_sidebar( 'footer-2' ); ?>
        </div>
        <div class="col-md-3">
          <?php dynamic_sidebar( 'footer-3' ); ?>
        </div>
        <div class="col-md-3">
          <?php dynamic_sidebar( 'footer-4' ); ?>
        </div>
      </div>
      <!-- .footer-widget-area --> 
    </div>
  </div>
  <div class="copy-container">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="footer-copy">
            <div class="col-md-8 site-info">
              <?php
                            $footer_text = get_theme_mod( 'footer_text' );

                            if ( empty( $footer_text ) ) {
                                printf( __( '&copy; 2018-%d, %s. All rights are reserved.', 'dokan-theme' ), date( 'Y' ), 'ShopADoc® The Dentist Marketplace, Inc');
                                printf( __( 'Powered by <a href="%s" target="_blank">GrossiWeb</a>', 'dokan-theme' ), esc_url( 'http://grossiweb.com' ));
                            } else {
                                echo str_replace("[year]",date('Y'),$footer_text);
                            }
                            ?>
            </div>
            <!-- .site-info -->
            
            <div class="col-md-4 footer-gateway">
              <?php
                                wp_nav_menu( array(
                                    'theme_location'  => 'footer',
                                    'depth'           => 1,
                                    'container_class' => 'footer-menu-container clearfix',
                                    'menu_class'      => 'menu list-inline pull-right',
                                ) );
                            ?>
            </div>
          </div>
        </div>
      </div>
      <!-- .row --> 
    </div>
    <!-- .container --> 
  </div>
  <!-- .copy-container --> 
</footer>
<!-- #colophon .site-footer -->
</div>
<!-- #page .hfeed .site -->

<style type="text/css">
/*unhide copuon code checkout*/
.checkout_coupon {
	display: block !important;
}
/*hide message have a coupon?*/
.woocommerce-info {
	display:none;
}
/*coupon code checkout style*/
.checkout_coupon button.button {
	background-color: #insert button color here;
}
#billing_full_name_field_2 {
	/*margin-top: -80px;*/
	float: left;
	width:100%;
	/*margin-left: 15px;*/
}
.woocommerce-checkout-payment#payment {
	padding-bottom:20px;
}
</style>
<?php 
//New Layout
$role = 'dentist';
if (is_user_logged_in()){
	$user = wp_get_current_user();
	if($user->roles[0]=='seller'){
		$role = 'seller';
	}else{
		$role = 'dentist';
	}
}
?>
<?php if($role=='dentist'){?>
	<style type="text/css">
	.price.priceBox table tr td table tr{float:left;width:50%;}
	.price.priceBox{padding:0px 10px !important;}
	.priceBox{font-size:18px;}	
	@media only screen and (max-width: 448px) {
	.desktop_miles_label{
		display:none;
	}
	.mobile_miles_label{
		display:block;
	}
	.mobile_price{
		display:block;
	}
	.desktop_price{
		display:none;
	}
	}
	</style>
<?php }?>

<script type="text/javascript">
jQuery(document).ready(function() {
	var height1 = jQuery(".elementor-section.elementor-section-height-full").height();
	var height2 = jQuery(".home_slide .text_section").height();
	var heightimg = height1 - height2;
	var windowsize = jQuery(window).width();
	//alert(windowsize);
	/*if(windowsize <= 448){
		jQuery(".selction_1").css('width',"100%");
		jQuery(".selction_2,.selction_3").css('width',"50%;");
		
		jQuery(".home_slide,.home_slide table").css('height',height1+"px");
		jQuery(".home_slide_img").css('height',"300px");
		jQuery(".home_slide_img").css('width',"100%");
	}else{
		var margin = 30;
		jQuery(".home_slide_img").css('height',heightimg - margin +"px");
		jQuery(".home_slide_img").css('margin-top',margin +"px");
	}*/
	if(windowsize <= 448){
		jQuery( ".status_col label span" ).each(function( index ) {
		   jQuery( this ).html(jQuery( this ).text().replace(/\ /g, '<br/>'));
		});
		jQuery( ".date_col label" ).each(function( index ) {
		   jQuery( this ).html(jQuery( this ).text().replace(/\ /g, '<br/>'));
		});
		jQuery( "th.ask_fee" ).html(jQuery( "th.ask_fee" ).text().replace(/\ /g, '<br/>'));
		jQuery(".site-info").text('<?php echo "© 2018-".date("Y")." ShopADoc Inc. All Rights Reserved"?>');
		//jQuery(".status_col label span").html(jQuery(".status_col label").text().replace(" ", '<br/>'));
		var navbarHeight = jQuery('.navbar').height();
		var footerHeight = jQuery('#colophon').height();
		var rotation_mainHeight = jQuery('.rotation_main').height();
		var product_listing_topHeight = jQuery('.product-listing-top').height();
		if (product_listing_topHeight === null){
			product_listing_topHeight = 0;
		}
		//alert($("body").height()+"=="+$(window).height());
		var full_window_height = jQuery(window).height();
		var body_height = jQuery("body").height();
		var my_listing_customHeight = parseInt(full_window_height) - parseInt(navbarHeight) - parseInt(footerHeight) - parseInt(rotation_mainHeight) - parseInt(product_listing_topHeight) - 20;
		jQuery(".my-listing-custom").height(my_listing_customHeight+"px");
		
	}else{
		var navbarHeight = jQuery('.navbar').height();
		var footerHeight = jQuery('#colophon').height();
		var rotation_mainHeight = jQuery('.rotation_main').height();
		var product_listing_topHeight = jQuery('.product-listing-top').height();
		if (product_listing_topHeight === null){
			product_listing_topHeight = 0;
		}
		//alert($("body").height()+"=="+$(window).height());
		var full_window_height = jQuery(window).height();
		var body_height = jQuery("body").height();
		var my_listing_customHeight = parseInt(full_window_height) - parseInt(navbarHeight) - parseInt(footerHeight) - parseInt(rotation_mainHeight) - parseInt(product_listing_topHeight) - 30;
		jQuery(".my-listing-custom").height(my_listing_customHeight+"px");
	}
		
});
<?php if(is_product()){?>
jQuery(document).ready(function() {
jQuery('.close_link a').bind("click",function(){
		jQuery('.accordion_div').hide('slow');
 });
var windowsize = jQuery(window).width();
if(windowsize <= 448){
	 var gallery = jQuery(".woocommerce-product-gallery");
	 var abuse = jQuery(".abuse");
	 <?php if($role=='seller'){?>
	  var priceBox = jQuery(".price.priceBox");
	  priceBox.insertAfter('.product');
	  jQuery(".price.priceBox").css('float','left').css('clear','both').css('width','100%');
	  //var bidding_section_live = jQuery(".bidding_section_live");
	  //bidding_section_live.insertAfter('.entry-title');
	  var biding_form = jQuery(".biding_form");
	  biding_form.insertAfter('.price.priceBox');
	  jQuery(".accordion_div").show();
	  //Allocate height to price box
		var main_height = jQuery(".content-area #main").height();
		var product_div = jQuery(".content-area  #main .product").height();
		var biding_form_height = jQuery(".biding_form").height();
		//alert(main_height+"=="+product_div+"=="+biding_form_height);
		var black_box_height = main_height - (product_div + biding_form_height) - 20;
		jQuery(".price.priceBox,table.main_table").height(black_box_height+"px");
		if(black_box_height < 64){
			jQuery(".up_img, .down_img").css('width','34%');
		}
		<?php }?>
	  <?php if($role=='dentist'){?>
	   /*var current_bid = jQuery(".buttons_added.current_bid");
	  	current_bid.insertAfter('.product');
		
		var auction_form = jQuery("#auction_form");
	  	auction_form.insertAfter('.product');*/
		var biding_form = jQuery(".biding_form");
	  	biding_form.insertAfter('.product');
		jQuery(".biding_form").css('margin-top','10px');
		jQuery(".biding_form .quantity").css('float','left');
		jQuery(".biding_form .quantity .bid_amount_txt").css('margin-top','20px');
		//jQuery(".biding_form .bid_now_img").css('top','-20px !important');
	  <?php }?>
	 //jQuery(".auction_detail").prepend(abuse);
	 
	  jQuery('.detail_link').bind("click",function(){
           	jQuery('.accordion_div').show('slow');
			setTimeout("jQuery('.accordion_div').hide('slow');",12000);
     });
	 jQuery(".detail_link").unbind("mouseover");
}else{
	 var gallery = jQuery(".woocommerce-product-gallery");
      gallery.insertBefore('.summary');
	  var abuse = jQuery(".abuse");
	  jQuery(".woocommerce-product-gallery").append(abuse);
	  jQuery('.detail_link').bind("mouseover",function(){
            jQuery('.accordion_div').show('slow');
			setTimeout("jQuery('.accordion_div').hide('slow');",12000);
			//jQuery('.ads_div').css('position','fixed').css('bottom','0px').css('width','86%').css('z-index','101');
			//setTimeout("jQuery('.accordion_div').hide('slow');jQuery('.ads_div').css('position','inherit').css('bottom','0px').css('width','100%').css('z-index','1');",4000);
			
     });
	  jQuery(".detail_link").unbind("click");
}
jQuery(window).resize(function() {
  windowsize = jQuery(window).width();
  /*if (windowsize <= 448) {
	  
	  var gallery = jQuery(".woocommerce-product-gallery");
      gallery.insertAfter('.product_title');
	  var abuse = jQuery(".abuse");
	  jQuery(".auction_detail").prepend(abuse);
	 jQuery('.detail_link').bind("click",function(){
           	jQuery('.accordion_div').show('slow');
			setTimeout("jQuery('.accordion_div').hide('slow');",12000);
     });
	 jQuery(".detail_link").unbind("mouseover");
  }else{
	  var gallery = jQuery(".woocommerce-product-gallery");
      gallery.insertBefore('.summary');
	  var abuse = jQuery(".abuse");
	  jQuery(".woocommerce-product-gallery").append(abuse);
	  jQuery('.detail_link').bind("mouseover",function(){
            jQuery('.accordion_div').show('slow');
			setTimeout("jQuery('.accordion_div').hide('slow');",12000);
			
     });
	  jQuery(".detail_link").unbind("click");
	  
  }*/
});
});
<?php } /************New layout********/?>


(function($) {
    $(document).ready(function() { 
	
	$(function() {
	<?php 
	global $wp;
	$current_url =  home_url($wp->request);
	if(!is_product() && strpos($current_url,"checkout/order-received")==false){?>
	/*if($(".container.content-wrap").height() <= 800){
		jQuery('.site-footer').css('position','absolute').css('bottom','0px').css('width','100%');
	}else{
		jQuery('.site-footer').css('position','inherit').css('bottom','0px').css('width','100%');
	}*/
	var footerHeight = $('#colophon').height();
	//alert($("body").height()+"=="+$(window).height());
	if (parseInt($("body").height()) - parseInt(footerHeight) > $(window).height()) {
       // $(".ads_div").css('position','inherit').css('width','100%').css("bottom",footerHeight+"px");
    }else{
		var footerHeight = $('#colophon').height();
        //$(".ads_div").css('position','fixed').css('width','86%').css("bottom",footerHeight+"px");
	}
	<?php }?>
  $(".table-wrap").each(function() {
    var nmtTable = $(this);
    var nmtHeadRow = nmtTable.find("thead tr");
    nmtTable.find("tbody tr").each(function() {
      var curRow = $(this);
      for (var i = 0; i < curRow.find("td").length; i++) {
        var rowSelector = "td:eq(" + i + ")";
        var headSelector = "th:eq(" + i + ")";
        curRow.find(rowSelector).attr('data-title', nmtHeadRow.find(headSelector).text());
      }
    });
  });
});
$(window).on("scroll", function() {
	var footerHeight = $('#colophon').height();
	//var scrollHeight = $(document).height();
	//var scrollPosition = $(window).height() + $(window).scrollTop();
	//console.log((scrollHeight - scrollPosition) / scrollHeight);
	/*if ((scrollHeight - scrollPosition) / scrollHeight <= '0.00029683304172695906') {
	    $(".ads_div").css("bottom",footerHeight+"px");
	}else{
		 $(".ads_div").css("bottom","0");
	}*/
	/*if($(window).scrollTop() + window.innerHeight > $(document).height() - footerHeight) {	
        $(".ads_div").css("bottom",footerHeight+"px");
    }else{
		$(".ads_div").css("bottom","0");
	}*/
});
/*$(window).scroll(function(){
	var footerHeight = $('#colophon').height();
	if($(window).scrollTop() + $(window).height() > $(document).height() - footerHeight) {
		alert($(document).height());
		 $(".ads_div").css("bottom",footerHeight+"px");
	}else{
		$(".ads_div").css("bottom","0");
	}
});*/
		//var coupon2 = $(".checkout_coupon.woocommerce-form-coupon");
        //coupon2.insertAfter('.shop_table.woocommerce-checkout-review-order-table');
		var coupon2 = $(".checkout_coupon.woocommerce-form-coupon").remove();
		$(".checkout_coupon.woocommerce-form-coupon").hide();
		var billing_full_name_field = $("#billing_full_name_field").remove();
		var html = '<td colspan="2" ><div class="woocommerce-form-coupon-toggle"><div class="woocommerce-info">Have a coupon? <a href="#" class="showcoupon">Click here to enter your code</a></div></div><form class="checkout_coupon woocommerce-form-coupon" method="post" style="display:none"><p>If you have a coupon code, please apply it below.</p><p class="form-row form-row-first"><input type="text" name="coupon_code" class="input-text" placeholder="Coupon code" id="coupon_code" value=""/></p><p class="form-row form-row-last"><button type="submit" class="button" name="apply_coupon" value="Apply">Apply</button></p><div class="clear"></div></form></td>';
		$(".cart-coupon").html(html);
       // billing_full_name_field.insertAfter('.woocommerce-checkout-payment#payment');
	   // billing_full_name_field.insertAfter('.test');
		
		 var sos_help = $("#sos_help");
        sos_help.insertAfter('#wpforms-185-field_43-container .wpforms-required-label');
		$( document.body ).on( 'update_order_review', function(){
			var html = '<td colspan="2" ><div class="woocommerce-form-coupon-toggle"><div class="woocommerce-info">Have a coupon? <a href="#" class="showcoupon">Click here to enter your code</a></div></div><form class="checkout_coupon woocommerce-form-coupon" method="post" style="display:none"><p>If you have a coupon code, please apply it below.1</p><p class="form-row form-row-first"><input type="text" name="coupon_code" class="input-text" placeholder="Coupon code" id="coupon_code" value=""/></p><p class="form-row form-row-last"><button type="button" onclick="jQuery(\'.checkout_coupon\').submit();" class="button" name="apply_coupon" value="Apply">Apply</button></p><div class="clear"></div></form></td>';
		$(".cart-coupon").html(html);
		});
    })
})
(jQuery);

</script>
<?php /*?>
// checks if the the device is a mobile or not by testing for regex in the navigator.userAgent

var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};
/*
// after testing, we can simply rotate the html body element how many degrees we want and also set other things like width/height parameters that will be enforced later in the code. in the example below the original orientaion is set to fit to mobile horizontal display (rotated 90 degrees in css), so if the code runs on a PC i will apply 0 degrees orientation to reset the css rotation

if(isMobile.any()){
        widthRatio = 0.95;
        heightRatio = 0.65;
        var deg = 90;
        document.body.style.webkitTransform = 'rotate('+deg+'deg)'; 
        document.body.style.mozTransform    = 'rotate('+deg+'deg)'; 
        document.body.style.msTransform     = 'rotate('+deg+'deg)'; 
        document.body.style.oTransform      = 'rotate('+deg+'deg)'; 
        document.body.style.transform       = 'rotate('+deg+'deg)'; 
}

<script type="text/javascript">
// Get a handle to the player
/*
	player       = document.getElementById('video-element');
	btnPlayPause = document.getElementById('btnPlayPause');
	btnMute      = document.getElementById('btnMute');
	progressBar  = document.getElementById('progress-bar');
  volumeBar    = document.getElementById('volume-bar');

  // Update the video volume
  volumeBar.addEventListener("change", function(evt) {
		player.volume = evt.target.value;
	});
  document.getElementById('btnFullScreen').disabled = true;
	// Add a listener for the timeupdate event so we can update the progress bar
	player.addEventListener('timeupdate', updateProgressBar, false);
	
	// Add a listener for the play and pause events so the buttons state can be updated
	player.addEventListener('play', function() {
		// Change the button to be a pause button
		changeButtonType(btnPlayPause, 'pause');
	}, false);
  
	player.addEventListener('pause', function() {
		// Change the button to be a play button
		changeButtonType(btnPlayPause, 'play');
	}, false);
	
	player.addEventListener('volumechange', function(e) { 
		// Update the button to be mute/unmute
		if (player.muted) changeButtonType(btnMute, 'unmute');
		else changeButtonType(btnMute, 'mute');
	}, false);	
  
	player.addEventListener('ended', function() { this.pause(); }, false);	
  
  progressBar.addEventListener("click", seek);

  function seek(e) {
      var percent = e.offsetX / this.offsetWidth;
      player.currentTime = percent * player.duration;
      e.target.value = Math.floor(percent / 100);
      e.target.innerHTML = progressBar.value + '% played';
  }

  function playPauseVideo() {
  	if (player.paused || player.ended) {
  		// Change the button to a pause button
  		changeButtonType(btnPlayPause, 'pause');
  		player.play();
  	}
  	else {
  		// Change the button to a play button
  		changeButtonType(btnPlayPause, 'play');
  		player.pause();
  	}
  }
   document.getElementById("btnPlayPause").click();
  // Stop the current media from playing, and return it to the start position
  function stopVideo() {
  	player.pause();
  	if (player.currentTime) player.currentTime = 0;
  }
  
  // Toggles the media player's mute and unmute status
  function muteVolume() {
  	if (player.muted) {
  		// Change the button to a mute button
  		changeButtonType(btnMute, 'mute');
  		player.muted = false;
  	}
  	else {
  		// Change the button to an unmute button
  		changeButtonType(btnMute, 'unmute');
  		player.muted = true;
  	}
  }
  
  // Replays the media currently loaded in the player
  function replayVideo() {
  	resetPlayer();
  	player.play();
  }
  
  // Update the progress bar
  function updateProgressBar() {
  	// Work out how much of the media has played via the duration and currentTime parameters
  	var percentage = Math.floor((100 / player.duration) * player.currentTime);
  	// Update the progress bar's value
  	progressBar.value = percentage;
  	// Update the progress bar's text (for browsers that don't support the progress element)
  	progressBar.innerHTML = percentage + '% played';
  }
  
  // Updates a button's title, innerHTML and CSS class
  function changeButtonType(btn, value) {
  	btn.title     = value;
  	btn.innerHTML = value;
  	btn.className = value;
  }
  
  function resetPlayer() {
  	progressBar.value = 0;
  	// Move the media back to the start
  	player.currentTime = 0;
  	// Set the play/pause button to 'play'
  	changeButtonType(btnPlayPause, 'play');
  }  
  
  function exitFullScreen() {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
    } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
    }
  }
  
  function toggleFullScreen() {
    //var player = document.getElementById("player");

    if (player.requestFullscreen)
        if (document.fullScreenElement) {
            document.cancelFullScreen();
        } else {
            player.requestFullscreen();
        }
        else if (player.msRequestFullscreen)
        if (document.msFullscreenElement) {
            document.msExitFullscreen();
        } else {
            player.msRequestFullscreen();
        }
        else if (player.mozRequestFullScreen)
        if (document.mozFullScreenElement) {
            document.mozCancelFullScreen();
        } else {
            player.mozRequestFullScreen();
        }
        else if (player.webkitRequestFullscreen)
        if (document.webkitFullscreenElement) {
            document.webkitCancelFullScreen();
        } else {
            player.webkitRequestFullscreen();
        }
    else {
        alert("Fullscreen API is not supported");
        
    }
  }

</script>
<?php */?>
<?php wp_footer(); ?>
<?php
	global $post,$wp;
	$current_url =  home_url( $wp->request );
	if(strpos($current_url,"/contact") > 0 || strpos($current_url,"/checkout") > 0 || strpos($current_url,"/my-account/payment-methods") > 0){?>
		<style type="text/css">
			.responsive-menu-label{
				display:block !important;
			}
		</style>
	<?php }elseif(strpos($current_url,"/shopadoc-auction-activity") > 0){?> 
    	
    	<style type="text/css">
			.entry-title{display:none !important;}
		</style>
	<?php }else{?>
    	<style type="text/css">
			
		</style>
	<?php }?>
<div id="yith-wcwl-popup-message" style="display:none;">
  <div id="yith-wcwl-message"></div>
</div>
</body></html>