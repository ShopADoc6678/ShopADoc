<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package dokan
 * @package dokan - 2014 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/assets/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php wp_head(); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery(".sgpb-popup-dialog-main-div-wrapper,.sgpb-theme-1-overlay").css('display','none !important');
	jQuery(".woocommerce-product-gallery img").removeAttr('title');
});
function startSlide(current){
	 if(current > 10){
		 startSlide(1);
	 }else{
		 jQuery(".rotation_set").hide();
		 jQuery("#rotation_set_"+current).show();
		 setTimeout("trackSlide("+current+");",1000);
		 current++;
	 	 setTimeout("startSlide("+current+");",6000);
	 }
 }
 function trackSlide(current){
	 var set_ads = jQuery("#set_ads_"+current).val();
	 jQuery.ajax({	
				url:'<?php echo get_site_url();?>/ajax.php',	
				type:'POST',
				data:{'mode':'track','set_ads':set_ads},
				beforeSend: function() {},
				complete: function() {
				},
				success:function (data){}
		
				});
 }
		function removecode(){
			var code = jQuery("#wpforms-895-field_26").val();
		  	var price = parseFloat(jQuery(".wpforms-single-item-price .wpforms-price").html().replace("$ ",""));
		    jQuery(".wpforms-payment-total").html("$ "+price);
			jQuery("#wpforms-895-field_29").val(price);
			jQuery("#wpforms-895-field_26").val('');
			jQuery("#wpforms-895-field_34").val(price);
		}
		function apply_code(){
		  var code = jQuery("#wpforms-895-field_26").val();
		  var price = parseFloat(jQuery(".wpforms-single-item-price .wpforms-price").html().replace("$ ",""));
		  if(code ==''){
			  Custom_popup("Error!","Please enter a Promo Code","col-md-6 col-md-offset-3");
			  return false;
		  }
		  jQuery.ajax({	
					url:'<?php echo get_site_url();?>/apply_coupon.php',	
					type:'POST',
					data:{'code':code,'price':price},
					beforeSend: function() {
						//jQuery('#'+gallery).prepend('<div class="loading" style="text-align:center;"><img src="<?php echo WP_SITEURL;?>/page-loader.gif" title="loading" alt="loading" /></div>');
						jQuery(".wpforms-payment-total").html('<div class="loading" style="text-align:left;"><img src="<?php echo get_site_url();?>/wp-content/plugins/woocommerce/assets/images/wpspin-2x.gif" title="loading" alt="loading" /></div>');
					},
        			complete: function() {
						jQuery('.wpforms-payment-total .loading').remove();	
					},
					success:function (data){
							if(data=='error'){
								jQuery(".wpforms-payment-total").html("$ "+price);
								jQuery("#wpforms-895-field_29").val(price);
								jQuery("#wpforms-895-field_26").val('');
								//alert('Coupon "'+code+'" does not exist!');
								Custom_popup("Error!","Invalid Promo Code","col-md-6 col-md-offset-3");
							}else{
								var new_price = data;
								//wpforms-payment-total
								//Coupon: code10 (remove)
								jQuery(".wpforms-payment-total").html("$ "+new_price+" (<a href='javascript:removecode();' title='remove coupon code'>remove</a>)");
								jQuery("#wpforms-895-field_34").val(new_price);
								jQuery("#wpforms-895-field_29").val(new_price);
							}
					}
			
					});
		}
function chooseProfile(id){

	if(id==1){
		 jQuery(".childDiv1").show();
		 jQuery(".childDiv2").hide();
	 }if(id==2){
		 jQuery(".childDiv1").hide();
		 jQuery(".childDiv2").show();
	 }
	/* 
	 jQuery("#type-1").removeClass('bg_opacity');
	 jQuery("#type-2").removeClass('bg_opacity');
	 jQuery("#type-3").removeClass('bg_opacity');
	 jQuery("#type-4").removeClass('bg_opacity');
	 jQuery("#type-5").removeClass('bg_opacity');
	 jQuery("#type-6").removeClass('bg_opacity');
	 jQuery("#type-7").removeClass('bg_opacity');
	 jQuery("#type-8").removeClass('bg_opacity');
	 jQuery("#type-child").removeClass('bg_opacity');
	 jQuery("#type-"+id).addClass('bg_opacity');*/

	 /*jQuery('#btnSubmit').click();*/
 }
 function pageRedirect(page) {
	 	<?php
			global $post;
		?>
        window.location.replace("<?php echo get_site_url();?>/?action=add_to_cart&type="+page+"&auction_id=<?php echo $post->ID;?>");
    }
	 function pageRedirect_Relist() {
	 	<?php
			global $post;
		?>
        window.location.replace("<?php echo get_site_url();?>/?action=relist&mode=discount&product_id=<?php echo $post->ID;?>");
    }	
  jQuery(document).ready(function(){
	  	jQuery("#wpforms-895-field_31 li,#wpforms-895-field_45 li").addClass("container_my");
		jQuery("#wpforms-895-field_31_1,#wpforms-895-field_45_1").after('<span class="checkmark_my"></span>');
		jQuery("#wpforms-895-field_31 li .checkmark_my,#wpforms-895-field_45 li .checkmark_my").click(function() {
		  jQuery("#wpforms-895-field_31 label,#wpforms-895-field_45 label").click();
		});
		
	  	jQuery("#menu-item-browse").text("My Uploads");
	  	jQuery("#wpforms-185-field_4").after('<span toggle="#wpforms-185-field_4" class="fa fa-fw fa-eye field-icon toggle-password wpform-password"></span>');
		jQuery("#wpforms-895-field_4").after('<span toggle="#wpforms-895-field_4" class="fa fa-fw fa-eye field-icon toggle-password wpform-password"></span>');
		
	 	jQuery(".toggle-password").click(function() {
		  jQuery(this).toggleClass("fa-eye fa-eye-slash");
		  var input = jQuery(jQuery(this).attr("toggle"));
		  if (input.attr("type") == "password") {
			input.attr("type", "text");
		  } else {
			input.attr("type", "password");
		  }
		});
	  	jQuery(document).on('change', "input[name='plan']", function() {
			if(this.checked) {
				var val = jQuery(this).val(); 
				jQuery("#selected_plan").val(val);
				//setTimeout("pageRedirect('"+val+"')", 1000);
			}
		});
		jQuery( "#wpforms-895-field_44") .change(function () {    
			var val = jQuery(this).val(); 
			if(val=='Same as address listed above'){
				var street = jQuery("#wpforms-895-field_17").val();
				var street2 = jQuery("#wpforms-895-field_18").val();
				var city = jQuery("#wpforms-895-field_19").val();
				var state = jQuery("#wpforms-895-field_20").val();
				var zip = jQuery("#wpforms-895-field_22").val();
				jQuery("#wpforms-895-field_7-container").addClass('hide');
				jQuery("#wpforms-895-field_8-container").addClass('hide');
				jQuery("#wpforms-895-field_9-container").addClass('hide');
				jQuery("#wpforms-895-field_11-container").addClass('hide');
				jQuery("#wpforms-895-field_12-container").addClass('hide');
			}else{
				jQuery("#wpforms-895-field_7-container").removeClass('hide');
				jQuery("#wpforms-895-field_8-container").removeClass('hide');
				jQuery("#wpforms-895-field_9-container").removeClass('hide');
				jQuery("#wpforms-895-field_11-container").removeClass('hide');
				jQuery("#wpforms-895-field_12-container").removeClass('hide');
				var street = '';
				var street2 = '';
				var city = '';
				var state = '';
				var zip = '';
			}
			jQuery("#wpforms-895-field_7").val(street);
			jQuery("#wpforms-895-field_8").val(street2);
			jQuery("#wpforms-895-field_9").val(city);
			jQuery("#wpforms-895-field_11").val(state);
			jQuery("#wpforms-895-field_12").val(zip);
		});
		jQuery(document).on('change', "#wpforms-895-field_11,#wpforms-895-field_20", function() {
				var val = jQuery("#wpforms-895-field_11").val(); 
				var val_1 = jQuery("#wpforms-895-field_20").val();
				if(val === null || val == ""){
					jQuery("#wpforms-895-field_11").val(val_1);
					jQuery("#wpforms-submit-895").removeAttr('disabled');
					return true;
				}else{
					if(val=="" || val_1 == ""){
						jQuery("#wpforms-submit-895").removeAttr('disabled');
						return true;
					}
					if(val != val_1){
						jQuery("#wpforms-submit-895").attr('disabled','disabled');
						Custom_popup("Error!","Office where treatment is rendered must be same state as address on file with State Board of Dental Examiners.","col-md-6 col-md-offset-3");
						jQuery("#wpforms-895-field_11").val(val_1);
						jQuery("#wpforms-submit-895").removeAttr('disabled');
					}else{
						jQuery("#wpforms-submit-895").removeAttr('disabled');
					}
				}
				
				
		});
		jQuery(document).on('click', "#bid_on,#pay_now_btn", function() {
				//var val = jQuery("input[name='plan']:checked").val(); // retrieve the value
				var val = jQuery("#selected_plan").val();
				if(val==''){
					Custom_popup("Error!","Please select a payment option.","col-md-6 col-md-offset-3");
				}else{
					pageRedirect(val);
				}
				//setTimeout("pageRedirect('"+val+"')", 1000);
		});
		jQuery(document).on('click', "#pay_now_btn_relist", function() {
				//var val = jQuery("input[name='plan']:checked").val(); // retrieve the value
				var val = jQuery("#selected_plan").val();
				if(val==''){
					Custom_popup("Error!","Please select Re-list Option.","col-md-6 col-md-offset-3");
				}else{
					pageRedirect_Relist();
				}
				//setTimeout("pageRedirect('"+val+"')", 1000);
		});
		<?php if(is_front_page()) {?>
			//responsive-menu-label responsive-menu-label-left
			jQuery("#responsive-menu-button").append('<span class="responsive-menu-label responsive-menu-label-home responsive-menu-label-right"> <span class="responsive-menu-button-text">Menu</span> </span>');
		<?php }?>
		//jQuery(document).on('click', ".bid_on", function() {
						<?php 
							$subscriptions = YWSBS_Subscription_Helper()->get_subscriptions_by_user( get_current_user_id() );
							$status = ywsbs_get_status();
							$flag = false;
							foreach ( $subscriptions as $subscription_post ) :
								$subscription = ywsbs_get_subscription( $subscription_post->ID );
								//if(($status[$subscription->status]=='active' || $status[$subscription->status] == 'expired') && $subscription->product_id != 1141):
								if(($status[$subscription->status]=='active') && $subscription->product_id != 1141){
									$flag = true;
									$active_plan = $subscription->product_id;
								}
							endforeach;
						if($flag):
							if($active_plan == 942){
								$change_plan = 'monthly';?>
								jQuery("input[name=plan][value='single']").prop("checked", true);
								jQuery("input[name=plan][value='single']").hide();
								jQuery("#plan0_span").prepend('<span class="tooltips popup_tooltip" title="This is your current subscription."><img src="<?php echo home_url('/wp-content/themes/dokan-child/checkbok.png');?>" alt="checkbox" /></span>');
								jQuery("#pay_now_btn").hide();
								jQuery("#plan1_span").hide();
								jQuery(document).on('click', "input[name=plan]", function() {
									if(jQuery(this).val()=='single'){
										jQuery("#pay_now_btn").hide();
									}else{
										jQuery("#pay_now_btn").show();
									}
								});
							<?php }
							if($active_plan == 948){
								
								$plan_orderid =get_plan_orderid();
								$plan_status = get_post_meta($plan_orderid,'_plan_status',true);
								$status = get_post_meta($plan_orderid,'status',true);
								$change_plan = 'single';?>
								jQuery("input[name=plan][value='monthly']").prop("checked", true);
								jQuery("input[name=plan][value='monthly'],#plan1_span").hide();
								jQuery(".tooltips.popup_tooltip").html('<img src="<?php echo home_url('/wp-content/themes/dokan-child/checkbok.png');?>" alt="checkbox" />');
								jQuery("#pay_now_btn").hide();
								//jQuery("#plan0_span").hide();
								jQuery("#deactive_span").show();
								<?php if($plan_status =="active_cancelled"){?>
									jQuery("#deactive_span").html('Unsubscription takes effect 4 weeks from your request per <a href="/user-agreement/" title="Terms of Use.">Terms of Use</a>.');
								<?php }?>
								jQuery(document).on('click', "input[name=plan]", function() {
									if(jQuery(this).val()=='single'){
										jQuery("#pay_now_btn").show();
										jQuery("#deactive_span").hide();
									}else{
										jQuery("#pay_now_btn").hide();
										jQuery("#deactive_span").show();
									}
								});
								jQuery('input[name=plan_deactive]').on('click', function(){
									jQuery(".sgpb-popup-dialog-main-div-wrapper .sgpb-popup-close-button-1,.sgpb-popup-overlay-955").click();
                                    jQuery.confirm({
                                        title: 'Please Confirm',
										columnClass: 'col-md-10 col-md-offset-1',
                                        content: '<br />',
                                        buttons: {
											Yes: {
                                                text: 'Yes, Please Cancel my Auction <br />Participation Subscription',
                                               // btnClass: 'btn-blue',
                                                /*keys: [
                                                    'enter',
                                                    'shift'
                                                ],*/
                                                action: function(){
                                                   // this.jQuerycontent // reference to the content
                                                    //jQuery.alert('Yes');
													window.location.replace("<?php echo get_site_url().'/?mode=de-active-sub';?>");
                                                }
                                            },
											No: {
                                                text: 'No, keep my current payment plan',
                                                btnClass: 'btn-blue',
                                                /*keys: [
                                                    'enter',
                                                    'shift'
                                                ],*/
                                                action: function(){
                                                    //this.jQuerycontent // reference to the content
                                                    //jQuery.alert('No');
													jQuery("#plan_deactive").removeAttr('checked');
                                                }
                                            }
                                        }
                                    });
                                });
							<?php }
						endif;
						?>
				//});
				
	});
	//Custom_popup("Error!","","col-md-6 col-md-offset-3");
	function Custom_popup(title,message,class_name){
				jQuery.confirm({
					title: '',
					columnClass: class_name,
					content: message,
					buttons: {
						Yes: {
							text: "X",
						   	//btnClass: 'btn-blue',
							keys: ['enter'],
							action: function(){
							}
						}
					}
				});
                                
	}
</script>
<?php if(is_front_page()) {?>
	<style type="text/css">
		.responsive-menu-label.responsive-menu-label-home{
			display:block !important;right:-37px;top:22px;
		}
		#responsive-menu-button.is-active .responsive-menu-label.responsive-menu-label-home{display:none !important;}
		.responsive-menu-label.responsive-menu-label-home .responsive-menu-button-text{color:#fff;}
	</style>
<?php }?>
<script>
function myFunction() {
  var x = document.getElementById("sub-active");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
<script type="text/javascript">
 jQuery(document).ready(function(){
	 var post_id = jQuery(".variation dd.variation-Auctionid").text();
	 	if(post_id=='46'){
				jQuery("#coupon_code").attr('placeholder','Promo code');
				jQuery(".woocommerce-terms-and-conditions-checkbox-text").html('I authorize ShopADoc The Dentist Marketplace charge to my credit/debit card, listed below, an annual registration fee in the amount of $29.99.<br />The annual registration fee will be a recurring charge to this credit/debit card on your anniversary date of registration.<br /><br /> Under penalty of law, I certify I hold an active unrestricted license to practice dentistry and I am without pending investigation for disciplinary/ administrative action(s) against me. Should my status change, I agree to notify ShopADoc The Dentist Marketplace immediately by email to <a href="<?php echo home_url('/contact/');?>" title="Contact" >ShopADoc1@gmail.com</a> and refrain from further participation on this site until reinstatement by the State Board of Dentistry. I accept the <a href="<?php echo home_url('/user-agreement/');?>" title="User Agreement" >User Agreement</a>, <a href="<?php echo home_url('/privacy-policy/');?>" title="Privacy Policy" >Privacy Policy</a>, and <a href="<?php echo home_url('/house-rules/');?>" title="House Rules" >House Rules</a>.');
		}
	 });
</script>
	<link href="https://fonts.googleapis.com/css?family=Cinzel|Quattrocento+Sans&display=swap" rel="stylesheet">
</head>

<body <?php body_class( 'woocommerce' ); ?>>
    <div id="page" class="hfeed site">
        <?php do_action( 'before' ); ?>

        <nav class="navbar navbar-inverse navbar-top-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-5">
                           
                        <div class="navbar-header">
                   
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-top-collapse">
                                <span class="sr-only"><?php _e( 'Toggle navigation', 'dokan-theme' ); ?></span>
                                <i class="fa fa-bars"></i>
                            </button>
                                      <?php echo do_shortcode('[aps-social id="1"]')?>
                            
                        </div>
                        <?php
                            wp_nav_menu( array(
                                'theme_location'    => 'top-left',
                                'depth'             => 0,
                                'container'         => 'div',
                                'container_class'   => 'collapse navbar-collapse navbar-top-collapse',
                                'menu_class'        => 'nav navbar-nav',
                                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                'walker'            => new wp_bootstrap_navwalker())
                            );
                        ?>
                        
                    </div>

                    <div class="col-md-6 col-sm-7 menu-div">
                        <div class="collapse navbar-collapse navbar-top-collapse">
                            <?php dokan_header_user_menu_custom(); ?>
                        </div>
                    </div>
                </div> <!-- .row -->
            </div> <!-- .container -->
        </nav>

        <header id="masthead" class="site-header" role="banner">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-5">
                        <hgroup>
                            <h1 class="site-title"><a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?> <small> - <?php bloginfo( 'description' ); ?></small></a></h1>
                        </hgroup>
                    </div><!-- .col-md-6 -->

                    <div class="col-md-8 col-sm-7 clearfix">
                        <?php dynamic_sidebar( 'sidebar-header' ) ?>
                    </div>
                </div><!-- .row -->
            </div><!-- .container -->

            <div class="menu-container">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <nav role="navigation" class="site-navigation main-navigation clearfix">
                                <h1 class="assistive-text"><i class="icon-reorder"></i> <?php _e( 'Menu', 'dokan-theme' ); ?></h1>
                                <div class="assistive-text skip-link"><a href="#content" title="<?php esc_attr_e( 'Skip to content', 'dokan-theme' ); ?>"><?php _e( 'Skip to content', 'dokan-theme' ); ?></a></div>
                                    <nav class="navbar navbar-default" role="navigation">
                                        <div class="navbar-header">
                                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                                                <span class="sr-only"><?php _e( 'Toggle navigation', 'dokan-theme' ); ?></span>
                                                <i class="fa fa-bars"></i>
                                            </button>
                                            <a class="navbar-brand" href="<?php echo home_url(); ?>"><i class="fa fa-home"></i> <?php _e( 'Home', 'dokan-theme' ); ?></a>
                                        </div>
                                        <div class="collapse navbar-collapse navbar-main-collapse">
                                            <?php
                                                wp_nav_menu( array(
                                                    'theme_location'    => 'primary',
                                                    'container'         => 'div',
                                                    'container_class'   => 'collapse navbar-collapse navbar-main-collapse',
                                                    'menu_class'        => 'nav navbar-nav',
                                                    'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                                    'walker'            => new wp_bootstrap_navwalker())
                                                );
                                            ?>
                                        </div>
                                    </nav>
                            </nav><!-- .site-navigation .main-navigation -->
                        </div><!-- .span12 -->
                    </div><!-- .row -->
                </div><!-- .container -->
            </div> <!-- .menu-container -->
        </header><!-- #masthead .site-header -->
        <div id="main" class="site-main">
            <div class="container content-wrap">
                <div class="row">