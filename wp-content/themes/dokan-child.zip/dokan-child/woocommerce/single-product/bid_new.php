<?php
/**
 * Auction bid
 *
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $woocommerce, $product, $post,$US_state,$today_date_time;
if(!(method_exists( $product, 'get_type') && $product->get_type() == 'auction')){
	return;
}
//get_CURLDATA(home_url('/cronJobFlash.php'));

$current_user = wp_get_current_user();
$product_id =  $product->get_id();
$_auction_current_bid = get_post_meta( $product_id, '_auction_current_bid', true );
$_auction_start_price = get_post_meta( $product_id, '_auction_start_price',TRUE);
if(isset($_GET['action']) && $_GET['action']=='expire'){
	if(is_user_logged_in() && $post->post_author == $current_user->ID){
		update_post_meta( $product_id, '_auction_relist_expire','yes');
	}
}
$_auction_relist_expire = get_post_meta( $product_id, '_auction_relist_expire', true );
$_auction_dates_to = get_post_meta($product_id, '_auction_dates_to', true );
$_flash_cycle_start = get_post_meta($product_id, '_flash_cycle_start' , TRUE);
$_flash_cycle_end = get_post_meta($product_id, '_flash_cycle_end' , TRUE);
$_auction_maximum_travel_distance = get_post_meta($product_id, '_auction_maximum_travel_distance',true);
$_auction_relist_expire = get_post_meta( $product_id, '_auction_relist_expire', true );

$user_max_bid = $product->get_user_max_bid($product_id ,$current_user->ID );
$max_min_bid_text = $product->get_auction_type() == 'reverse' ? __( 'Your min bid is', 'wc_simple_auctions' ) : __( 'Your max bid is', 'wc_simple_auctions' );
$gmt_offset = get_option('gmt_offset') > 0 ? '+'.get_option('gmt_offset') : get_option('gmt_offset');
$auction_user = wp_get_current_user($post->post_author);
//print_r($auction_user);
$client_street = get_user_meta($post->post_author, 'client_street', true );
$client_apt_no = get_user_meta($post->post_author, 'client_apt_no', true );
$client_city = get_user_meta($post->post_author, 'client_city', true);
$client_state = get_user_meta($post->post_author, 'client_state', true);
$client_zip_code = get_user_meta($post->post_author, 'client_zip_code', true);
$address = '';

if($client_city){
	$address = $client_city;
}
if($client_state){
	$address .= ", ".$client_state;
}
if($client_zip_code){
	$address .= " ".$client_zip_code;
}
$user_role = $current_user->roles[0];

$user_id = $current_user->ID;	
$dentist_office_street = get_user_meta( $user_id, 'dentist_office_street', true );
$dentist_office_apt_no = get_user_meta( $user_id, 'dentist_office_apt_no', true );
$dentist_office_city = get_user_meta( $user_id, 'dentist_office_city', true );
$dentist_office_state = get_user_meta( $user_id, 'dentist_office_state', true );
$dentist_office_zip_code = get_user_meta( $user_id, 'dentist_office_zip_code', true );
$dentist_office_state = $US_state[$dentist_office_state];
$dentist_office_address = '';
if($dentist_office_street){
	$dentist_office_address .= $dentist_office_street;
}
if($dentist_office_apt_no){
	$dentist_office_address .= " ".$dentist_office_apt_no;
}
if($dentist_office_city){
	$dentist_office_address .= " ".$dentist_office_city;
}
if($dentist_office_state){
	$dentist_office_address .= " ".$dentist_office_state;
}
if($dentist_office_zip_code){
	$dentist_office_address .= ", ".$dentist_office_zip_code;
}
$distance = get_driving_information($dentist_office_address,trim($client_street." ".$client_apt_no." ".$address));
$distance = 30;
$client_ID = str_pad($post->post_author, 5, "0", STR_PAD_LEFT);
$auction_current_bid_price = wc_price(get_post_meta($product_id, '_auction_current_bid', true ));
$html_detail = '
<p class="auction-user"><a href="javascript:"  class="detail_link">Details</a></p>
  <div class="accordion_div" style="display:none;">
    <p class="auction-start">'.apply_filters("time_left_text", __( "<strong>Auction Begins:</strong>", "wc_simple_auctions" ), $product).date_i18n( get_option( "date_format" ),  strtotime( $product->get_auction_start_time() )).date_i18n( get_option( "time_format" ),  strtotime( $product->get_auction_start_time() )).' <span class="close_link"><a href="javascript:" >X</a></span></p>
    <p class="auction-start">'.apply_filters("time_left_text", __( "<strong>Auction Ends:</strong>", "wc_simple_auctions" ), $product).date_i18n( get_option( "date_format" ),  strtotime( $product->get_auction_end_time() )).date_i18n( get_option( "time_format" ),  strtotime( $product->get_auction_end_time() )).'</p>
    <p class="auction-user">'.apply_filters("time_left_text", __( "<strong>*Flash Bid Cycle<span class=\"TM_flash\">®</span>:</strong>", "wc_simple_auctions" ), $product).date_i18n(get_option("date_format"),strtotime($_flash_cycle_start))." from ".date("g:i A",strtotime($_flash_cycle_start))." to ".date_i18n(str_replace("@ ","",get_option("time_format")),strtotime($_flash_cycle_end)).'<span style="float:right;font-style:italic;font-size:10px;">* if needed</span></p>
    <p class="auction-user"><strong>Auction ID#:</strong>'.$product_id.'</p>
  </div>';
if($user_role =='seller' ) {?>
<style type="text/css">
	.current_bid_txt, .current.auction, .winned-for.auction {
		color:red;
	}
</style>
<?php }?>
<div class="popup_product_title" data-title="<?php echo $product->get_name();?>"> &nbsp;</div>
<!----------------------Show Expire Popup------------------------------------------>
<?php 
if(is_user_logged_in() && $post->post_author == $current_user->ID && ($_auction_relist_expire=='' ||$_auction_relist_expire=='no')){?>
<?php if(strtotime($_auction_dates_to) < strtotime($today_date_time) && strtotime($today_date_time) >= strtotime($_flash_cycle_end) && ($_auction_current_bid == '' || $_auction_current_bid == 0)){?>
<script type="text/javascript">
	setTimeout(function() {window.location.replace("<?php echo get_permalink( $product_id );?>?action=expire");}, 30000);
</script>
<?php }else{?>
	<style type="text/css">
    .sgpb-content-1640,.sgpb-popup-overlay-1640{display:none;}
    </style>
<?php }
}else{?>
	<style type="text/css">
    .sgpb-content-1640,.sgpb-popup-overlay-1640{display:none;}
    </style>
<?php }?>
<!---------------------End Show Expire Popup---------------------------------------------------------------->
<!---------------------Auction Live Section----------------------------------------------------------------->
<?php if(($product->is_closed() === FALSE ) && ($product->is_started() === TRUE )){
	$_auction_dates_extend = get_post_meta($product_id, '_auction_dates_extend', true );?>
    <!----------------------CountDown For Live-------------------------------->
    <div class="auction-time" id="countdown">
      <div class="main-auction auction-time-countdown" data-time="<?php echo $product->get_seconds_remaining() ?>" data-auctionid="<?php echo $product_id ?>" data-format="<?php echo get_option( 'simple_auctions_countdown_format' ) ?>"></div>
    </div>
    <!------------------------Auction Extended-------------------------->
    <?php if($_auction_dates_extend == 'yes'){
			/***************************Auction Extended**********************************/
			$auction_status = '<span class="extend_text">extended</span>';
			$play_sound = home_url('wp-content/uploads/sounds/087168277-helicopter-sound-effect.mp3');
			$play_snipping = 'yes';
			$auction_detail_class = ' extend';
			/***************************End Auction Extended**********************************/
		}else{
			/***************************Check Whether Live Or Flash Cycle Live**********************************/
			$_flash_status = get_post_meta($product_id, '_flash_status', true );
			$play_sound = home_url('wp-content/uploads/sounds/033581166-energetic-auctioneer-cattle-li.mp3');
			$auction_detail_class = ' live';
			$play_snipping = 'no';
			if($_flash_status == 'yes'){
				$auction_status = 'Flash Bid Cycle<span class="TM_flash">®</span> live';
			}else{
				$auction_status = '<span>auction live</span>';
			}
			/***************************END Whether Live Or Flash Cycle Live**********************************/
		?>
			<style type="text/css"> 
                 <?php if($user_role !='seller' ){?>
                    #mep_0{height:18px !important;}
                <?php }?>
                div.quantity .bid_amount_txt.amt {
                  -webkit-animation: mymove 5s infinite; /* Safari 4.0 - 8.0 */
                  animation: mymove 5s infinite;
                }
                /* Safari 4.0 - 8.0 */
                @-webkit-keyframes mymove {
                    from {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                  }
                
                  50% {
                    -webkit-transform: scale3d(1.05, 1.05, 1.05);
                    transform: scale3d(1.05, 1.05, 1.05);
                  }
                
                  to {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                  }
                }
                @keyframes mymove {
                  from {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                  }
                
                  50% {
                    -webkit-transform: scale3d(1.2, 1.2, 1.2);
                    transform: scale3d(1.2, 1.2, 1.2);
                  }
                
                  to {
                    -webkit-transform: scale3d(1, 1, 1);
                    transform: scale3d(1, 1, 1);
                  }
                }
            </style>
    	<?php }?>
      	<div class="auction_detail <?php echo $auction_detail_class?>">
            <?php 
            if($user_role=='customer' || !is_user_logged_in()){ 
                echo do_shortcode("[simple_favourites_button]");
            }
            $auctionend = new DateTime($product->get_auction_dates_to());
            $auctionendformat = $auctionend->format('Y-m-d H:i:s');
            $time = current_time( 'timestamp' );
            $timeplus5 = date('Y-m-d H:i:s', strtotime('+5 minutes', $time));
            echo do_shortcode('[sc_embed_player_template1 autoplay=true loops="true" volume="10" fileurl="'.$play_sound.'"]');
            echo '<input type="hidden" id="play_snipping" value="'.$play_snipping.'" />';
            ?>
            <script type="text/javascript">
                jQuery( document ).ready(function() {
                    setTimeout('jQuery(".mejs-play button").click();',1000); 
                });
            </script>
            <?php echo $auction_status;?>
        </div>
        <!---------------------------Title Section------------------------------------>
        <?php the_title( '<h1 class="product_title entry-title">', '</h1>' );?>
        <?php if(is_user_logged_in() && $post->post_author == $current_user->ID){?>
        	  <!-------------------------Update Distance and Price Section For Seller------------------------------------>
        	  <div class="price priceBox">
                <form action="<?php echo get_permalink()?>" method="post" id="price_form" >
                <input type="hidden" name="product_id" value="<?php echo $product_id;?>" />
                <input type="hidden" name="mode" value="update" />
                <input type="hidden" value="<?php echo $_auction_start_price;?>" id="_new_price" name="_new_price" />
                <input type="hidden" value="<?php echo $_auction_maximum_travel_distance;?>" id="_auction_maximum_travel_distance" name="_auction_maximum_travel_distance" />
                <style type="text/css">
					table tr td {
						height: 25px;
						vertical-align: middle;
					}
					@media only screen and (max-width: 448px) {
						table tr td {
							height: auto;
							width:65%;
						}
						.priceBox{
							padding:0 2px !important;
						}
					}
                </style>
                <table width="100%" border="0" >
                <tr>
                <td><table width="100%" border="0" >
                    <tr>
                      <td>Ask Fee:&nbsp;<span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></td>
                    </tr>
                    <tr>
                      <td><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?> <span class="desktop_miles_label">Miles</span></span> </td>
                    </tr>
                  </table></td>
                <td  class="up_down"><table width="100%" border="0" >
                    <tr>
                      <td><?php if($_auction_current_bid == '' || $_auction_current_bid == 0){?>
                        <span><img src="<?php echo home_url('wp-content/themes/dokan-child/Up.png');?>" onclick="updatePrice('up');" alt="up" class="up_img" border="0" style="width:30px;"/><img id="down_price_btn" src="<?php echo home_url('wp-content/themes/dokan-child/Down.png');?>" onclick="updatePrice('down');" alt="down" class="down_img" border="0" style="width:30px;"/></span>
                        <?php }?></td>
                    </tr>
                    <tr>
                      <td><?php if($_auction_maximum_travel_distance < 36){?>
                        <span ><img src="<?php echo home_url('wp-content/themes/dokan-child/Up.png');?>" class="up_img" onclick="updateDistance('up');" alt="up" border="0" style="width:30px;"/><img src="<?php echo home_url('wp-content/themes/dokan-child/Down.png');?>" class="down_img" onclick="updateDistance('down');" alt="Down" border="0" style="width:30px;" id="down_btn"/></span>
                        <?php }?></td>
                    </tr>
                  </table></td>
                <td><table width="100%" border="0" >
                    <tr>
                      <td colspan="2" rowspan="2"><input type="image" src="<?php echo home_url('wp-content/themes/dokan-child/Update.png');?>"  name="update_distance" id="update_distance" style="width:100px;padding:0;border:0;background:transparent;vertical-align:top;"/></td>
                    </tr>
                  </table></td>
                </tr>
                </table>
                </form>
            </div>
            <script type="text/javascript">
  		jQuery("#price_form").submit(function(e) {
			e.preventDefault(); // avoid to execute the actual submit of the form.
			var form = jQuery(this);
			var url = '<?php echo get_site_url();?>/ajax.php';
    		jQuery.ajax({
				   type: "POST",
				   url: url,
				   data: form.serialize(), // serializes the form's elements.
				   success: function(data)
				   {
					   var tmp = data.split("##");
					   jQuery("#price_txt").html(tmp[0]);
					   jQuery("#distance_txt").text(tmp[1]);
				   }
				 });
		});
		function updateDistance(dir){
			var _auction_maximum_travel_distance = parseInt(jQuery("#_auction_maximum_travel_distance").val());
			if(dir == 'up'){
				_auction_maximum_travel_distance++;
				if(_auction_maximum_travel_distance > 35){
					Custom_popup("Error!","Travel Miles must be within "+parseInt('<?php echo $_auction_maximum_travel_distance;?>')+" - 35 mile range","col-md-4 col-md-offset-4");
				}else{
					jQuery("#distance_txt").text(_auction_maximum_travel_distance);
					jQuery("#_auction_maximum_travel_distance").val(_auction_maximum_travel_distance);
					jQuery("#update_distance").show();
					jQuery("#down_btn").show();
				}
			}
			if(dir == 'down'){
				_auction_maximum_travel_distance--;
				if(_auction_maximum_travel_distance < parseInt('<?php echo $_auction_maximum_travel_distance;?>')){
					Custom_popup("Error!","Travel Miles must be within "+parseInt('<?php echo $_auction_maximum_travel_distance;?>')+" - 35 mile range","col-md-4 col-md-offset-4");
				}else{
					jQuery("#distance_txt").text(_auction_maximum_travel_distance);
					jQuery("#_auction_maximum_travel_distance").val(_auction_maximum_travel_distance);
					jQuery("#update_distance").show();
				}
			}
		}
		function updatePrice(dir){
			var _new_price = parseInt(jQuery("#_new_price").val());
			if(dir == 'up'){
				_new_price++;
				jQuery(".woocommerce-Price-amount.amount").html('<span class="woocommerce-Price-currencySymbol">$</span>'+_new_price.toFixed(2));
				jQuery("#_new_price").val(_new_price);
				jQuery("#update_price").show();
				jQuery("#down_price_btn").show();
			}
			if(dir == 'down'){
				_new_price--;
				if(_new_price < parseInt('<?php echo $_auction_start_price;?>')){
					Custom_popup("Error!","Ask Fee must be greater than $"+parseInt('<?php echo $_auction_start_price;?>'),"col-md-3 col-md-offset-4");
				}else{
					jQuery(".woocommerce-Price-amount.amount").html('<span class="woocommerce-Price-currencySymbol">$</span>'+_new_price.toFixed(2));
					jQuery("#_new_price").val(_new_price);
					jQuery("#update_price").show();
				}
			}
		}
	</script>
    		<!-------------------------End Distance and Price Section For Seller------------------------------------>
        <?php }else{?>
        	<!-------------------------Update Distance and Price Section For Dentist------------------------------------>
            <style type="text/css">
				.price.priceBox table tr td table tr{float:left;width:50%;}
				.price.priceBox{padding:0px 10px !important;}
				.priceBox{font-size:18px;}	
				.price_box_left{
					width:50%;
					float:left;
				}
				.price_box_right{
					width:50%;
					float:left;
				}
				.priceBox p{
					margin: 5px 0;
					line-height: 14px;
				}
				@media only screen and (max-width: 448px) {
					.priceBox{font-size:15px;}
					.priceBox p .label_price1{float:left;width:55%;}
					.priceBox p .label_price2{float:left;width:80%;}
					.price.priceBox{padding:0px 5px !important;}
					.priceBox p{
						font-size:10px !important;
					}
				}
				</style>
			  <div class="price priceBox">
				  <div class="price_box_left">
					<p><span class="label_price1">Ask Fee:&nbsp;</span><span class="label_text1"><span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></span></p>
				  </div>
				  <div class="price_box_right">
					<p><span class="label_price2"><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span></span><span class="label_text2"><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?> </span> <span class="desktop_miles_label">Miles</span></span></p>
				  </div>
			  </div>
            <!-------------------------End Distance and Price Section For Dentist------------------------------------>
        <?php }?>
        <!-----------------------------Auction Detail,Price,Bid Form Live auction Section------------------------------------>
        <div class='bidding_section_live auction-ajax-change' >
        <!-----------------------------Auction Detail Section Live auction Section------------------------------------>
        	<?php echo $html_detail;?>
        <!-----------------------------End Auction Detail Section Live auction Section--------------------------------->
        <!-----------------------------Auction Prices Section Live----------------------------------------------------->
        <?php if($user_role=='seller' || $user_role=='customer'){?>
		  <?php if($_auction_current_bid == '' || $_auction_current_bid == 0){?>
                  <div class="buttons_added current_bid"> 
                    <span class="bid_amount_txt">
                        <span class="auction-price starting-bid" data-auction-id="<?php echo esc_attr( $product_id ); ?>" data-bid="" data-status="running"><span class="starting auction current_bid_txt">Current Bid:&nbsp;</span><span class="woocommerce-Price-amount_new amount underline">None</span></span>
                    </span>
                  </div>
          <?php }else{?>
                <div class="buttons_added current_bid"> 
                    <span class="bid_amount_txt current_bid_txt"> <?php echo str_replace("Ask Price","Current Bid",$product->get_price_html()); ?></span>
                </div>
          <?php }?>
      <?php }?>
           <!-----------------------------End Auction Prices Section Live-------------------------------------------------->
           <!-----------------------------Bidding Form------------------------------------------------------------------------->
           <?php do_action('woocommerce_before_bid_form'); ?>
           <?php if((int) $distance <= (int) get_option('mile_radius') && ($user_role=='customer' || !is_user_logged_in())){?>
           		<div class="ajax_loader"><img src="<?php echo home_url('/wp-content/themes/dokan-child/ajax_loader.gif');?>" alt="ajax request" title="ajax loader" /></div>
               <form id="auction_form" class="auction_form cart" method="post" enctype='multipart/form-data' data-product_id="<?php echo $product_id; ?>" >
                <?php do_action('woocommerce_before_bid_button'); ?>
                <input type="hidden" id="bid" name="bid" value="<?php echo esc_attr( $product_id ); ?>" />
                <div class="quantity buttons_added"> 
                	<!-----------------Next Bid Text And Value And bid success Msg----------------------->
                	<span class="next_bid_txt bid_amount_txt red">NEXT BID:</span>
                    <span class="next_bid bid_amount_txt amt"><?php echo '$'.number_format((float)$product->bid_value(), 2, '.', ''); ?></span>
                  	<span id="bid_msg"></span>
				  	<?php 
						$already_bid = 'no';
						$message_bid = woocommerce__simple_auctions_winning_bid_message_custom($product_id);
						echo $message_bid;
						if($message_bid!=""){
							$already_bid = 'yes';
						}
                  	?>
                    <!-----------------End Next Bid Text And Value And bid success Msg Section----------------------->
                  <input type="button" value="+" class="plus" />
                  <input type="hidden" id="bid_value" name="bid_value" data-auction-id="<?php echo esc_attr( $product_id ); ?>"  <?php if ($product->get_auction_sealed() != 'yes'){ ?> value="<?php echo $product->bid_value() ?>" max="<?php echo $product->bid_value()  ?>"  <?php } ?> step="any" size="<?php echo strlen($product->get_curent_bid())+2 ?>" title="bid"  class="input-text  qty bid text left" readonly="readonly">
                  <input type="button" value="-" class="minus" />
                  <input type="hidden" id="already_bid" value="<?php echo $already_bid;?>" />
                </div>
				<?php //$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($current_user->ID);?>
                <?php if (!is_user_logged_in() ) { ?>
                    <input type="image" class="bid_now_img bid_button" name="submit" src="<?php echo home_url().'/bid_now_btn.png';?>" border="0" alt="Submit" />
                <?php }else{
						$plan_status = get_plan_status();
						if($plan_status=='active'){?>
							<a href="javascript:AjaxTest('<?php echo $already_bid;?>');" <?php if($already_bid !='yes'){?> onclick=""<?php }?>><img class="bid_now_img bid_button" src="<?php echo home_url().'/bid_now_btn.png';?>" border="0" alt="With each bid the amount is reduced by 3%" style="" /></a>
						<?php }else{
							$dentist_account_status = get_user_meta(get_current_user_id(), 'dentist_account_status', true );
							if($dentist_account_status =='unsubscribe'){?>
								<img class="bid_now_img bid_button reactive_btn" src="<?php echo home_url().'/bid_now_btn.png';?>" border="0" alt="With each bid the amount is reduced by 3%" style="" />
							<?php }else{?>
								<img class="bid_now_img bid_button bid_on" src="<?php echo home_url().'/bid_now_btn.png';?>" border="0" alt="With each bid the amount is reduced by 3%" style="" /> 
							<?php }?>
						<?php }?>
                <?php }?>
                <input type="hidden" id="place-bid" name="place-bid" value="<?php echo $product_id; ?>" />
                <input type="hidden" id="product_id" name="product_id" value="<?php echo esc_attr( $product_id ); ?>" />
                <?php if ( is_user_logged_in() ) { ?>
                <input type="hidden" id="user_id" name="user_id" value="<?php echo  get_current_user_id(); ?>" />
                <?php  } ?>
                <?php do_action('woocommerce_after_bid_button'); ?>
              </form>
           <?php }?>
           <!-----------------------------End Bid Form---------------------------------------------------------------------->
           </div>
           <!----------------------------End Auction Detail,Price,Bid Form Live auction Section----------------------------->
<?php }elseif(($product->is_closed() === FALSE ) && ($product->is_started() === FALSE )){?>
		<!----------------------Countdown to auction Section----------------------------------------------------------------->
		<!----------------------CountDown For Upcoming----------------------------------------------------------------------->
		<div class="auction-time future" id="countdown">
      		<div class="auction-time-countdown future" data-time="<?php echo $product->get_seconds_to_auction() ?>" data-format="<?php echo get_option( 'simple_auctions_countdown_format' ) ?>"></div>
    	</div>
        <div class="auction_detail upcoming">
			<?php if($user_role=='customer' || !is_user_logged_in()){ echo do_shortcode("[simple_favourites_button]");}?>
            <span>countdown to auction</span>
    	</div>
        <?php the_title( '<h1 class="product_title entry-title">', '</h1>' );?>
        <?php if(is_user_logged_in() && $post->post_author == $current_user->ID){?>
        		<!-------------------------Update Distance and Price Section For Seller--------------------------------->
        		<style type="text/css">.fa {font-size: 20px !important;}</style>
        		<div class="price priceBox">
          <form action="<?php echo get_permalink()?>" method="post" id="price_form" onsubmit="playAudio('<?php echo home_url('wp-content/uploads/sounds/Money%20(MP3).mp3')?>')">
            <input type="hidden" name="mode" value="update" />
            <input type="hidden" name="product_id" value="<?php echo $product_id;?>" />
            <input type="hidden" value="<?php echo $_auction_start_price;?>" id="_new_price" name="_new_price" />
            <input type="hidden" value="<?php echo $_auction_maximum_travel_distance;?>" id="_auction_maximum_travel_distance" name="_auction_maximum_travel_distance" />
            <style type="text/css">
                table tr td {
                    height: 25px;
                    vertical-align: middle;
                }
				@media only screen and (max-width: 448px) {
					table tr td {
						 height: auto;
                    	width:65%;
					}
					.priceBox{
						padding:0 2px !important;
					}
				}
            </style>
            <table width="100%" border="0" >
              <tr>
                <td><table width="100%" border="0" >
                    <tr>
                      <td>Ask Fee:&nbsp;<span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></td>
                    </tr>
                    <tr>
                      <td><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?> <span class="desktop_miles_label">Miles</span></span></td>
                    </tr>
                  </table></td>
                <td  class="up_down"><table width="100%" border="0" >
                    <tr>
                      <td><?php if($_auction_current_bid == '' || $_auction_current_bid == 0){?>
                        <span><img src="<?php echo home_url('wp-content/themes/dokan-child/Up.png');?>" onclick="updatePrice('up');" alt="up" class="up_img" border="0" style="width:30px;"/><img id="down_price_btn" src="<?php echo home_url('wp-content/themes/dokan-child/Down.png');?>" onclick="updatePrice('down');" alt="down" class="down_img" border="0" style="width:30px;"/></span>
                        <?php }?></td>
                    </tr>
                    <tr>
                      <td><?php if($_auction_maximum_travel_distance < 36){?>
                        <span ><img src="<?php echo home_url('wp-content/themes/dokan-child/Up.png');?>" class="up_img" onclick="updateDistance('up');" alt="up" border="0" style="width:30px;"/><img src="<?php echo home_url('wp-content/themes/dokan-child/Down.png');?>" class="down_img" onclick="updateDistance('down');" alt="Down" border="0" style="width:30px;" id="down_btn"/></span>
                        <?php }?></td>
                    </tr>
                  </table></td>
                <td><table width="100%" border="0" >
                    <tr>
                      <td colspan="2" rowspan="2"><input type="image" src="<?php echo home_url('wp-content/themes/dokan-child/Update.png');?>"  name="update_distance" id="update_distance" style="width:100px;padding:0;border:0;background:transparent;vertical-align:top;"/></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
          </form>
        </div>
				<script type="text/javascript">
		jQuery("#price_form").submit(function(e) {
				e.preventDefault(); // avoid to execute the actual submit of the form.
				var form = jQuery(this);
				var url = '<?php echo get_site_url();?>/ajax.php';
				jQuery.ajax({
					   type: "POST",
					   url: url,
					   data: form.serialize(), // serializes the form's elements.
					   success: function(data)
					   {
						   var tmp = data.split("##");
						   jQuery("#price_txt").html(tmp[0]);
						   jQuery("#distance_txt").text(tmp[1]);
					   }
					 });
			});
			function updateDistance(dir){
				var _auction_maximum_travel_distance = parseInt(jQuery("#_auction_maximum_travel_distance").val());
				if(dir == 'up'){
					_auction_maximum_travel_distance++;
					if(_auction_maximum_travel_distance > 35){
						Custom_popup("Error!","Travel Miles must be within "+parseInt('<?php echo $_auction_maximum_travel_distance;?>')+" - 35 mile range","col-md-4 col-md-offset-4");
					}else{
						jQuery("#distance_txt").text(_auction_maximum_travel_distance);
						jQuery("#_auction_maximum_travel_distance").val(_auction_maximum_travel_distance);
						jQuery("#update_distance").show();
						jQuery("#down_btn").show();
					}
				}
				if(dir == 'down'){
					_auction_maximum_travel_distance--;
					if(_auction_maximum_travel_distance < parseInt('<?php echo $_auction_maximum_travel_distance;?>')){
						Custom_popup("Error!","Travel Miles must be within "+parseInt('<?php echo $_auction_maximum_travel_distance;?>')+" - 35 mile range","col-md-4 col-md-offset-4");
					}else{
						jQuery("#distance_txt").text(_auction_maximum_travel_distance);
						jQuery("#_auction_maximum_travel_distance").val(_auction_maximum_travel_distance);
						jQuery("#update_distance").show();
					}
				}
			}
			function updatePrice(dir){
				var _new_price = parseInt(jQuery("#_new_price").val());
				if(dir == 'up'){
					_new_price++;
					jQuery(".woocommerce-Price-amount.amount").html('<span class="woocommerce-Price-currencySymbol">$</span>'+_new_price.toFixed(2));
					jQuery("#_new_price").val(_new_price);
					jQuery("#update_price").show();
					jQuery("#down_price_btn").show();
				}
				if(dir == 'down'){
					_new_price--;
					if(_new_price < parseInt('<?php echo $_auction_start_price;?>')){
						Custom_popup("Error!","Ask Fee must be greater than $"+parseInt('<?php echo $_auction_start_price;?>'),"col-md-3 col-md-offset-4");
					}else{
						jQuery(".woocommerce-Price-amount.amount").html('<span class="woocommerce-Price-currencySymbol">$</span>'+_new_price.toFixed(2));
						jQuery("#_new_price").val(_new_price);
						jQuery("#update_price").show();
					}
				}
			}
	</script>
    			<!-------------------------End Distance and Price Section For Seller------------------------------------>
        <?php }else{?>
        		<!-------------------------Update Distance and Price Section For Dentist-------------------------------->
        		<style type="text/css">
				.price.priceBox table tr td table tr{float:left;width:50%;}
				.price.priceBox{padding:0px 10px !important;}
				.priceBox{font-size:18px;}	
				.price_box_left{
					width:50%;
					float:left;
				}
				.price_box_right{
					width:50%;
					float:left;
				}
				.priceBox p{
					margin: 5px 0;
					line-height: 14px;
				}
				@media only screen and (max-width: 448px) {
					.price.priceBox{padding:0px 5px !important;}
					.priceBox{font-size:15px;}
					.priceBox p .label_price1{float:left;width:55%;}
					.priceBox p .label_price2{float:left;width:80%;}
					.priceBox p{
						font-size:10px !important;
					}
				}
				</style>
				<div class="price priceBox">
				  <div class="price_box_left">
					<p><span class="label_price1">Ask Fee:&nbsp;</span><span class="label_text1"><span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></span></p>
				  </div>
				  <div class="price_box_right">
					<p><span class="label_price2"><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span></span><span class="label_text2"><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?> <span class="desktop_miles_label">Miles</span></span></span></p>
				  </div>
				</div>
                <!-------------------------End Distance and Price Section For Dentist------------------------------->
		<?php }?>
        <?php echo $html_detail;?>
<?php }elseif($product->is_closed() === TRUE){?>
	<!----------------------Auction Closed Section------------------------------------------------------------------>
    <?php if($_auction_current_bid){?>
    	<!-------------------Auction Ended With no Bid------------------------------------------------------------>
        <div class="auction-time" id="countdown">
      		<div class="main-auction auction-time-countdown" data-status="win" data-time="<?php echo $product->get_seconds_to_auction() ?>" data-format="<?php echo get_option( 'simple_auctions_countdown_format' ) ?>"></div>
    	</div>
        <div class="auction_detail ended">
		  <?php if($user_role=='customer' || !is_user_logged_in()){ echo do_shortcode("[simple_favourites_button]");}?>
          <?php $customer_winner = get_post_meta($product_id,'_auction_current_bider', true ) ;
         		if((is_user_logged_in() && $post->post_author == $current_user->ID) || ($customer_winner ==$current_user->ID)){?>
                	 <span class="red">✓ Email (Spam)</span>
                 <?php }else{?>
                 	<span>ended</span>
          		<?php }?>
        </div>
        <?php the_title( '<h1 class="product_title entry-title">', '</h1>' );?>
        <!-------------------------Distance and Price Section For Dentist------------------------------------------->
        <style type="text/css">
			.swf_container{display:none;}
			.price.priceBox table tr td table tr{float:left;width:50%;}
			.price.priceBox{padding:0px 10px !important;}
			.priceBox{font-size:18px;}	
			.price_box_left{
				width:50%;
				float:left;
			}
			.price_box_right{
				width:50%;
				float:left;
			}
			.priceBox p{
				margin: 5px 0;
				line-height: 14px;
			}
			@media only screen and (max-width: 448px) {
				.priceBox{font-size:15px;}
				.priceBox p .label_price1{float:left;width:55%;}
				.priceBox p .label_price2{float:left;width:80%;}
				.price.priceBox{padding:0px 5px !important;}
				.priceBox p{
					font-size:10px !important;
				}
			}
		</style>
		<div class="price priceBox">
		  <div class="price_box_left">
			<p><span class="label_price1">Ask Fee:&nbsp;</span><span class="label_text1"><span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></span></p>
		  </div>
		  <div class="price_box_right">
			<p><span class="label_price2"><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span></span><span class="label_text2"><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?></span> <span class="desktop_miles_label">Miles</span></span></p>
		  </div>
		</div>
        <!-------------------------End Distance and Price Section For Dentist--------------------------------------->
        <?php echo $html_detail;?>
        <!-----------------------------Auction Prices Section Ended------------------------------------------------->
        <div class="buttons_added current_bid" style="width:100%;float:left;padding-bottom:0;"> <span class="bid_amount_txt current_bid_txt"> <?php echo str_replace("Winning Bid","Current Bid",$product->get_price_html()); ?></span></div>
		<?php if($user_role !='seller'){?>
    		<div class="buttons_added" style="width:100%;float:left;padding-bottom:10px;padding-top:10px;"> 
        	<span class="bid_amount_txt" style="margin-top:10px;"> 
            	<span class="starting-bid" data-auction-id="<?php echo esc_attr( $product_id ); ?>" data-bid="" data-status="running"><span class="starting auction red">Next Bid:&nbsp;</span><span class="woocommerce-Price-amount amount">$0.00</span></span>
            </span>
        </div>
    	<?php }?>
    	<!-----------------------------End Auction Prices Section Ended--------------------------------------------->
    <?php }else{?>
    	<!-------------------Auction Ended Without no Bid----------------------------------------------------------->
        
        <!-------------------Auction Ended With Flash to Come ------------------------------------------------------>
        	<?php if(strtotime($today_date_time) <= strtotime($_flash_cycle_start) && strtotime($_flash_cycle_end) > strtotime($today_date_time)){?>
            	<?php $second = apply_filters('woocommerce_simple_auctions_get_seconds_remaining', strtotime($_flash_cycle_start)  -  (get_option( 'gmt_offset' )*3600) ,1);?>
                <div class="auction-time future" id="countdown">
  					<div class="main-auction auction-time-countdown" <?php if($_auction_relist_expire=='yes' || $_GET['action']=='expire'){?> data-status="win"<?php }else{}?> data-time="<?php echo $second; ?>" data-auctionid="<?php echo $product_id ?>" data-format="<?php echo get_option( 'simple_auctions_countdown_format' ) ?>"></div>
				</div>
                <div class="auction_detail upcomming_flash">
					<?php if($user_role=='customer' || !is_user_logged_in()){ echo do_shortcode("[simple_favourites_button]");}?>
                    <span>countdown to Flash Bid Cycle<span class="TM_flash">®</span></span>
                </div>
                <?php the_title( '<h1 class="product_title entry-title">', '</h1>' );?>
                <?php if(is_user_logged_in() && $post->post_author == $current_user->ID){?>
                        <!-------------------------Update Distance and Price Section For Seller--------------------------------->
                        <style type="text/css">.fa {font-size: 20px !important;}</style>
                        <div class="price priceBox">
                  <form action="<?php echo get_permalink()?>" method="post" id="price_form" onsubmit="playAudio('<?php echo home_url('wp-content/uploads/sounds/Money%20(MP3).mp3')?>')">
                    <input type="hidden" name="mode" value="update" />
                    <input type="hidden" name="product_id" value="<?php echo $product_id;?>" />
                    <input type="hidden" value="<?php echo $_auction_start_price;?>" id="_new_price" name="_new_price" />
                    <input type="hidden" value="<?php echo $_auction_maximum_travel_distance;?>" id="_auction_maximum_travel_distance" name="_auction_maximum_travel_distance" />
                    <style type="text/css">
                        table tr td {
                            height: 25px;
                            vertical-align: middle;
                        }
                        @media only screen and (max-width: 448px) {
                            table tr td {
                                 height: auto;
                                width:65%;
                            }
                            .priceBox{
                                padding:0 2px !important;
                            }
                        }
                    </style>
                    <table width="100%" border="0" >
                      <tr>
                        <td><table width="100%" border="0" >
                            <tr>
                              <td>Ask Fee:&nbsp;<span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></td>
                            </tr>
                            <tr>
                              <td><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?> <span class="desktop_miles_label">Miles</span></span></td>
                            </tr>
                          </table></td>
                        <td  class="up_down"><table width="100%" border="0" >
                            <tr>
                              <td><?php if($_auction_current_bid == '' || $_auction_current_bid == 0){?>
                                <span><img src="<?php echo home_url('wp-content/themes/dokan-child/Up.png');?>" onclick="updatePrice('up');" alt="up" class="up_img" border="0" style="width:30px;"/><img id="down_price_btn" src="<?php echo home_url('wp-content/themes/dokan-child/Down.png');?>" onclick="updatePrice('down');" alt="down" class="down_img" border="0" style="width:30px;"/></span>
                                <?php }?></td>
                            </tr>
                            <tr>
                              <td><?php if($_auction_maximum_travel_distance < 36){?>
                                <span ><img src="<?php echo home_url('wp-content/themes/dokan-child/Up.png');?>" class="up_img" onclick="updateDistance('up');" alt="up" border="0" style="width:30px;"/><img src="<?php echo home_url('wp-content/themes/dokan-child/Down.png');?>" class="down_img" onclick="updateDistance('down');" alt="Down" border="0" style="width:30px;" id="down_btn"/></span>
                                <?php }?></td>
                            </tr>
                          </table></td>
                        <td><table width="100%" border="0" >
                            <tr>
                              <td colspan="2" rowspan="2"><input type="image" src="<?php echo home_url('wp-content/themes/dokan-child/Update.png');?>"  name="update_distance" id="update_distance" style="width:100px;padding:0;border:0;background:transparent;vertical-align:top;"/></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table>
                  </form>
                </div>
                        <script type="text/javascript">
                jQuery("#price_form").submit(function(e) {
                        e.preventDefault(); // avoid to execute the actual submit of the form.
                        var form = jQuery(this);
                        var url = '<?php echo get_site_url();?>/ajax.php';
                        jQuery.ajax({
                               type: "POST",
                               url: url,
                               data: form.serialize(), // serializes the form's elements.
                               success: function(data)
                               {
                                   var tmp = data.split("##");
                                   jQuery("#price_txt").html(tmp[0]);
                                   jQuery("#distance_txt").text(tmp[1]);
                               }
                             });
                    });
                    function updateDistance(dir){
                        var _auction_maximum_travel_distance = parseInt(jQuery("#_auction_maximum_travel_distance").val());
                        if(dir == 'up'){
                            _auction_maximum_travel_distance++;
                            if(_auction_maximum_travel_distance > 35){
                                Custom_popup("Error!","Travel Miles must be within "+parseInt('<?php echo $_auction_maximum_travel_distance;?>')+" - 35 mile range","col-md-4 col-md-offset-4");
                            }else{
                                jQuery("#distance_txt").text(_auction_maximum_travel_distance);
                                jQuery("#_auction_maximum_travel_distance").val(_auction_maximum_travel_distance);
                                jQuery("#update_distance").show();
                                jQuery("#down_btn").show();
                            }
                        }
                        if(dir == 'down'){
                            _auction_maximum_travel_distance--;
                            if(_auction_maximum_travel_distance < parseInt('<?php echo $_auction_maximum_travel_distance;?>')){
                                Custom_popup("Error!","Travel Miles must be within "+parseInt('<?php echo $_auction_maximum_travel_distance;?>')+" - 35 mile range","col-md-4 col-md-offset-4");
                            }else{
                                jQuery("#distance_txt").text(_auction_maximum_travel_distance);
                                jQuery("#_auction_maximum_travel_distance").val(_auction_maximum_travel_distance);
                                jQuery("#update_distance").show();
                            }
                        }
                    }
                    function updatePrice(dir){
                        var _new_price = parseInt(jQuery("#_new_price").val());
                        if(dir == 'up'){
                            _new_price++;
                            jQuery(".woocommerce-Price-amount.amount").html('<span class="woocommerce-Price-currencySymbol">$</span>'+_new_price.toFixed(2));
                            jQuery("#_new_price").val(_new_price);
                            jQuery("#update_price").show();
                            jQuery("#down_price_btn").show();
                        }
                        if(dir == 'down'){
                            _new_price--;
                            if(_new_price < parseInt('<?php echo $_auction_start_price;?>')){
                                Custom_popup("Error!","Ask Fee must be greater than $"+parseInt('<?php echo $_auction_start_price;?>'),"col-md-3 col-md-offset-4");
                            }else{
                                jQuery(".woocommerce-Price-amount.amount").html('<span class="woocommerce-Price-currencySymbol">$</span>'+_new_price.toFixed(2));
                                jQuery("#_new_price").val(_new_price);
                                jQuery("#update_price").show();
                            }
                        }
                    }
            </script>
                        <!-------------------------End Distance and Price Section For Seller------------------------------------>
				<?php }else{?>
                        <!-------------------------Update Distance and Price Section For Dentist-------------------------------->
                        <style type="text/css">
                        .price.priceBox table tr td table tr{float:left;width:50%;}
                        .price.priceBox{padding:0px 10px !important;}
                        .priceBox{font-size:18px;}	
                        .price_box_left{
                            width:50%;
                            float:left;
                        }
                        .price_box_right{
                            width:50%;
                            float:left;
                        }
                        .priceBox p{
                            margin: 5px 0;
                            line-height: 14px;
                        }
                        @media only screen and (max-width: 448px) {
                            .price.priceBox{padding:0px 5px !important;}
                            .priceBox{font-size:15px;}
                            .priceBox p .label_price1{float:left;width:55%;}
                            .priceBox p .label_price2{float:left;width:80%;}
                            .priceBox p{
                                font-size:10px !important;
                            }
                        }
                        </style>
                        <div class="price priceBox">
                          <div class="price_box_left">
                            <p><span class="label_price1">Ask Fee:&nbsp;</span><span class="label_text1"><span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></span></p>
                          </div>
                          <div class="price_box_right">
                            <p><span class="label_price2"><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span></span><span class="label_text2"><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?> <span class="desktop_miles_label">Miles</span></span></span></p>
                          </div>
                        </div>
                        <!-------------------------End Distance and Price Section For Dentist------------------------------->
                <?php }?>
        <!-------------------End Auction Ended With Flash to Come ------------------------------------------------------>
            <?php }else{?>
        <!-------------------Auction Ended With Flash to Expire------------------------------------------------------>
        			<div class="auction-time" id="countdown">
      		<div class="main-auction auction-time-countdown" data-status="win" data-time="<?php echo $product->get_seconds_to_auction() ?>" data-format="<?php echo get_option( 'simple_auctions_countdown_format' ) ?>"></div>
    	</div>
                    <div class="auction_detail ended">
                      <?php if($user_role=='customer' || !is_user_logged_in()){ echo do_shortcode("[simple_favourites_button]");}?>
                      <?php $customer_winner = get_post_meta($product_id,'_auction_current_bider', true ) ;
                            if((is_user_logged_in() && $post->post_author == $current_user->ID) || ($customer_winner ==$current_user->ID)){?>
                                 <span class="red">✓ Email (Spam)</span>
                             <?php }else{?>
                                <span>ended</span>
                            <?php }?>
                    </div>
                    <?php the_title( '<h1 class="product_title entry-title">', '</h1>' );?>
                    <!-------------------------Distance and Price Section For Dentist------------------------------------------->
                    <style type="text/css">
                        .swf_container{display:none;}
                        .price.priceBox table tr td table tr{float:left;width:50%;}
                        .price.priceBox{padding:0px 10px !important;}
                        .priceBox{font-size:18px;}	
                        .price_box_left{
                            width:50%;
                            float:left;
                        }
                        .price_box_right{
                            width:50%;
                            float:left;
                        }
                        .priceBox p{
                            margin: 5px 0;
                            line-height: 14px;
                        }
                        @media only screen and (max-width: 448px) {
                            .priceBox{font-size:15px;}
                            .priceBox p .label_price1{float:left;width:55%;}
                            .priceBox p .label_price2{float:left;width:80%;}
                            .price.priceBox{padding:0px 5px !important;}
                            .priceBox p{
                                font-size:10px !important;
                            }
                        }
                    </style>
                    <div class="price priceBox">
                      <div class="price_box_left">
                        <p><span class="label_price1">Ask Fee:&nbsp;</span><span class="label_text1"><span id="price_txt" class="desktop_price"><?php echo wc_price($_auction_start_price)?></span><span id="price_txt_mobile" class="mobile_price"><?php echo '$'.abs($_auction_start_price);?></span></span></p>
                      </div>
                      <div class="price_box_right">
                        <p><span class="label_price2"><span class="mobile_miles_label">Travel Miles:&nbsp;</span><span class="desktop_miles_label">Travel Distance:&nbsp;</span></span><span class="label_text2"><span id="distance_txt"><?php echo $_auction_maximum_travel_distance;?></span> <span class="desktop_miles_label">Miles</span></span></p>
                      </div>
                    </div>
                    <!-------------------------End Distance and Price Section For Dentist--------------------------------------->
                    <?php echo $html_detail;?>
                    <!-----------------------------Auction Prices Section Ended------------------------------------------------->
                    <div class="buttons_added current_bid" style="width:100%;float:left;padding-bottom:0;"> <span class="bid_amount_txt current_bid_txt"> <?php echo str_replace("Winning Bid","Current Bid",$product->get_price_html()); ?></span></div>
                    <?php if($user_role !='seller'){?>
                        <div class="buttons_added" style="width:100%;float:left;padding-bottom:10px;padding-top:10px;"> 
                        <span class="bid_amount_txt" style="margin-top:10px;"> 
                            <span class="starting-bid" data-auction-id="<?php echo esc_attr( $product_id ); ?>" data-bid="" data-status="running"><span class="starting auction red">Next Bid:&nbsp;</span><span class="woocommerce-Price-amount amount">$0.00</span></span>
                        </span>
                    </div>
                    <?php }?>
                    <!-----------------------------End Auction Prices Section Ended--------------------------------------------->
        <!-------------------End Auction Ended With Flash to Expire------------------------------------------------------>
        	<?php }?>
	<?php }?>
<?php }?>
<script type="text/javascript">
	function showHide(id){
		jQuery("."+id).slideToggle('slow');
	}
	function showHover(id){
		jQuery("."+id).show('slow');
	}
	function playAudio(url) {
	  var a = new Audio(url);
	  a.play();
	}
	function playAudioLoop_old(url) {
	  var audio = new Audio()
	  audio.src = url;
	  audio.loop = true;
	  audio.load();
	  audio.play();
	}
	
	var audio;
	function playAudioLoop(url) {
		audio = document.getElementById("myAudio");
		document.getElementById("myAudio").style.display="block";
		//audio = new Audio(url);
		audio.src = url;
		audio.loop = true;
		audio.volume = 0.3; 
		audio.load();
		audio.play();
	}
	
	function play(){
		audio.play();
		jQuery("#play_btn").hide();
		jQuery("#pause_btn").show();
	}
	
	function pause(){
		audio.pause();
		jQuery("#play_btn").show();
		jQuery("#pause_btn").hide();
	}
</script>