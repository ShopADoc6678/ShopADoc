<?php
/*$user_id = 235;
wp_set_current_user( $user_id );
wp_set_auth_cookie( $user_id );*/
global $US_state,$today_date_time,$monday,$thursday,$flash_cycle_start,$flash_cycle_end,$radius_distance;
//echo get_the_modified_date("Y-m-d H:i:s",60);
date_default_timezone_set('America/Los_Angeles');
$today_date_time = date('Y-m-d g:i A');
$monday = date("Y-m-d",strtotime( "monday next week" ))." 08:30";
$thursday = date('Y-m-d', strtotime( 'thursday next week' ) )." 13:00";
$flash_cycle_start = date('Y-m-d', strtotime( 'friday next week' ) )." 08:30";
$flash_cycle_end = date('Y-m-d', strtotime( 'friday next week' ) )." 10:30";
$radius_distance = 50;

$US_state = array("Alabama" => "AL",
				"Alaska" => "AK",
				"Arizona" => "AZ",
				"Arkansas" => "AR",
				"California" => "CA",
				"Colorado" => "CO",
				"Connecticut" => "CT",
				"Delaware" => "DE",
				"District of Columbia" => "DC",
				"Florida" => "FL",
				"Georgia" => "GA",
				"Hawaii" => "HI",
				"Idaho" => "ID",
				"Illinois" => "IL",
				"Indiana" => "IN",
				"Iowa" => "IA",
				"Kansas" => "KS",
				"Kentucky" => "KY",
				"Louisiana" => "LA",
				"Maine" => "ME",
				"Maryland" => "MD",
				"Massachusetts" => "MA",
				"Michigan" => "MI",
				"Minnesota" => "MN",
				"Mississippi" => "MS",
				"Missouri" => "MO",
				"Montana" => "MT",
				"Nebraska" => "NE",
				"Nevada" => "NV",
				"New Hampshire" => "NH",
				"New Jersey" => "NJ",
				"New Mexico" => "NM",
				"New York" => "NY",
				"North Carolina" => "NC",
				"North Dakota" => "ND",
				"Ohio" => "OH",
				"Oklahoma" => "OK",
				"Oregon" => "OR",
				"Pennsylvania" => "PA",
				"Rhode Island" => "RI",
				"South Carolina" => "SC",
				"South Dakota" => "SD",
				"Tennessee" => "TN",
				"Texas" => "TX",
				"Utah" => "UT",
				"Vermont" => "VT",
				"Virginia" => "VA",
				"Washington" => "WA",
				"West Virginia" => "WV",
				"Wisconsin" => "WI",
				"Wyoming" => "WY",
				"Armed Forces Americas" => "AA",
				"Armed Forces Europe" => "AE",
				"Armed Forces Pacific" => "AP",);
function my_theme_enqueue_styles() {
    $parent_style = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',get_stylesheet_directory_uri() . '/style.css',array( $parent_style ),wp_get_theme()->get('Version'));
	//wp_enqueue_style( 'print',get_stylesheet_directory_uri() . '/print.css',array( $parent_style ),false,'print');
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );
function check_first_auction($auction_id){
	global $wpdb;
	$bid_count = $wpdb->get_var($wpdb->prepare("SELECT count(id) as count FROM wp_simple_auction_log WHERE auction_id = %d LIMIT 1",$product_id));
}
function makeFlashLive() {
	global $wpdb,$today_date_time;
	$args = array(
					'post_status'         => array('publish','pending'),
					'posts_per_page'      => -1,
					'tax_query'           => array( array( 'taxonomy' => 'product_type', 'field' => 'slug', 'terms' => 'auction' ) ),
					'meta_query' => array(array('key' => '_auction_closed','operator' => 'EXISTS',)),
				  );
			$query = new WP_Query($args );
			$posts = $query->posts;
	foreach($posts as $post) {
	global $today_date_time;
	$_flash_cycle_start = get_post_meta($post->ID, '_flash_cycle_start' , TRUE);
	$_flash_cycle_end = get_post_meta($post->ID, '_flash_cycle_end' , TRUE);
	if(strtotime($today_date_time) >= strtotime($_flash_cycle_start) && strtotime($_flash_cycle_end) > strtotime($today_date_time)){
			$product_id = $post->ID;
			update_post_meta( $product_id, '_auction_dates_from', $_flash_cycle_start);
			update_post_meta( $product_id, '_auction_dates_to', $_flash_cycle_end);
			update_post_meta( $product_id, '_flash_status','yes');
			delete_post_meta($product_id, '_auction_fail_email_sent', 1);
			delete_post_meta($product_id, '_auction_finished_email_sent', 1);
			delete_post_meta($product_id, '_auction_fail_reason', 1);
			delete_post_meta($product_id, '_auction_closed', 1);
		}
	}
}
function getAdLinkNew($ad_id){
	//include("/home/401140.cloudwaysapps.com/qcqkjmndhe/public_html/wp-content/plugins/advanced-ads/classes/ad.php");
	
	$ad = new Advanced_Ads_Ad($ad_id);
	$options = $ad->options();
	$ad_options = isset( $options['tracking'] ) ? $options['tracking'] : array();
	$public_id = ( isset( $ad_options['public-id'] ) && ! empty( $ad_options['public-id'] ) )? $ad_options['public-id'] : false;
	$public_stats_slug = ( isset( $tracking_options['public-stats-slug'] ) )? $tracking_options['public-stats-slug'] : 'ad-stats';
	if( $public_id==""){
		$public_id=base64_encode($ad_id);
	}
	$public_link = $public_id ? site_url( '/ad-statistics/?id=' . $public_id) : false; 
	return $public_link;
}
function woocommerce__simple_auctions_winning_bid_message_custom( $product_id ) {

	global $product, $woocommerce;



	if (!(method_exists( $product, 'get_type') && $product->get_type() == 'auction'))

					return '';

	if ($product->is_closed())

				return '';

	$current_user = wp_get_current_user();



	if (!$current_user-> ID)

					return '';



	if ($product->get_auction_sealed() == 'yes')

					return '';



	if ($current_user->ID == $product->get_auction_current_bider() &&  wc_notice_count () == 0   ) {
		$message = '<div class="woocommerce-notices-wrapper" id="no_bid_msg">
						<div class="woocommerce-message" role="alert">'.__('No need to bid. Your bid is winning! ', 'wc_simple_auctions').'</div>
					</div><script type="text/javascript">jQuery(document).ready(function(){	setTimeout("jQuery(\'#no_bid_msg\').hide(\'slow\');",2000); });</script>';
		return $message;

	}else{
		return '';
	}

	

}
function getTimeZone_Custom(){
	global $wpdb;
	if (is_user_logged_in()){
		$user = wp_get_current_user();
		$user_id = $user->ID;
		if($user->roles[0]=='seller'){
			$zip_code = get_user_meta( $user_id, 'client_zip_code', true);
		}else{
			$zip_code = get_user_meta( $user_id, 'dentist_office_zip_code', true);
		}
		$timeZone = $wpdb->get_var("SELECT timezone FROM timezonebyzipcode WHERE zip = '".$zip_code."' LIMIT 1");
		if($timeZone !=""){
			return $timeZone;
		}else{
			$user_ip = $_SERVER['REMOTE_ADDR'];
			$pageurl = 'https://ipapi.co/'.$user_ip.'/timezone';
			$cURL=curl_init();
			curl_setopt($cURL,CURLOPT_URL,$pageurl);
			curl_setopt($cURL,CURLOPT_RETURNTRANSFER, TRUE);
			$timeZone=trim(curl_exec($cURL));
			curl_close($cURL);
			if(strpos($timeZone,'error') > 0){
				$pageurl = 'http://dentalassets.com/timezone.php?REMOTE_ADDR='.$user_ip;
				$cURL=curl_init();
				curl_setopt($cURL,CURLOPT_URL,$pageurl);
				curl_setopt($cURL,CURLOPT_RETURNTRANSFER, TRUE);
				$timeZone=trim(curl_exec($cURL));
				curl_close($cURL);
				if(strpos($timeZone,'error') > 0 || $timeZone==''){
					$pageurl = 'https://ladeedastudio.com/timezone.php?REMOTE_ADDR='.$user_ip;
					$cURL=curl_init();
					curl_setopt($cURL,CURLOPT_URL,$pageurl);
					curl_setopt($cURL,CURLOPT_RETURNTRANSFER, TRUE);
					$timeZone=trim(curl_exec($cURL));
					curl_close($cURL);
				}
			}
			return $timeZone;
		}
		
	}
	//$bid_count = $wpdb->get_var($wpdb->prepare("SELECT count(id) as count FROM wp_simple_auction_log WHERE auction_id = %d LIMIT 1",$post->ID));
	
}
function getDentistAddress(){
	if (is_user_logged_in()){
		$user = wp_get_current_user();
		if($user->roles[0]=='seller'){
			$user_id = dokan_get_current_user_id();
			$client_street = get_user_meta( $user_id, 'client_street', true);
			$client_apt_no = get_user_meta( $user_id, 'client_apt_no', true);
			$client_city = get_user_meta( $user_id, 'client_city', true);
			$client_state = get_user_meta( $user_id, 'client_state', true);
			$client_zip_code = get_user_meta( $user_id, 'client_zip_code', true);
			$address = $client_street." ".$client_apt_no." ".$client_city." ".$client_state." ".$client_zip_code;
		}else{
			$user_id = dokan_get_current_user_id();
			$dentist_office_street = get_user_meta( $user_id, 'dentist_office_street', true);
			$dentist_office_apt_no = get_user_meta( $user_id, 'dentist_office_apt_no', true);
			$dentist_office_city = get_user_meta( $user_id, 'dentist_office_city', true);
			$dentist_office_state = get_user_meta( $user_id, 'dentist_office_state', true);
			$dentist_office_zip_code = get_user_meta( $user_id, 'dentist_office_zip_code', true);
			$address = $dentist_office_street." ".$dentist_office_apt_no." ".$dentist_office_city." ".$dentist_office_state." ".$dentist_office_zip_code;
		}
	}else{
		$user_ip = getenv('REMOTE_ADDR');
		$pageurl = "http://www.geoplugin.net/php.gp?ip=$user_ip";
		$cURL=curl_init();
		curl_setopt($cURL,CURLOPT_URL,$pageurl);
		curl_setopt($cURL,CURLOPT_RETURNTRANSFER, TRUE);
		$geo=unserialize(trim(curl_exec($cURL)));
		curl_close($cURL);
		$country = $geo["geoplugin_countryName"];
		$city = $geo["geoplugin_city"];
		$address = $city." ".$country;
	}
	return $address;
}
function get_plan_dates($product_id){
	$user_id = dokan_get_current_user_id();
	$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($user_id);
	$active_cancelled_flag = 'no';
	if(count($subscriptions_users) > 0){
		foreach($subscriptions_users as $row){
			$plan_id = get_post_meta($row->ID,'product_id',true);
			$status = get_post_meta($row->ID,'status',true);
			$expired_date = get_post_meta($row->ID,'expired_date',true);
			if($status=='active'){
				if($plan_id != 1141 && $product_id != $plan_id){
					if($plan_id==948 && $product_id==942){
						$payment_due_date = get_post_meta( $row->ID, 'payment_due_date', true );
						if($payment_due_date){
							$deactive_date = strtotime("+4 week", $payment_due_date);
							$active_cancelled_flag = 'yes';
							$this_monday = date('Y-m-d',strtotime("monday next week",$deactive_date))." 08:30";
							$this_friday = date('Y-m-d',strtotime("friday next week",$deactive_date))." 10:30";
						}
					}
				}
			}else{
			}
		}
	}else{
		$this_monday = date("Y-m-d",strtotime( "monday this week" ))." 08:30";
		$this_friday = date('Y-m-d', strtotime( 'friday this week' ) )." 10:30";
	}
	if($this_monday==""){
		$this_monday = date("Y-m-d",strtotime( "monday this week" ))." 08:30";
		$this_friday = date('Y-m-d', strtotime( 'friday this week' ) )." 10:30";
	}
	return $this_monday."##".$this_friday;
}
function pay_for_plan($auction_id,$type){
	global $woocommerce;
	$custom_data = array();
	$woocommerce->cart->empty_cart();
	// select ID
	if($type=='single'){
		$product_id = 942;
		if($auction_id==''){
			$auction_id = $product_id;
		}	
	}elseif($type=='relist'){
		$product_id = 1642;	
	}elseif($type=='register'){
		$product_id = 1141;	
	}else{
		$product_id = 948;
		if($auction_id==''){
			$auction_id = $product_id;
		}
	}
	$custom_data['custom_data']['auction_id'] = $auction_id;
	$custom_data['custom_data']['plan_id'] = $product_id; 
	
	$user_id = dokan_get_current_user_id();
	$custom_data['custom_data']['user_id'] = $user_id; 
	$quantity = 0;
	foreach(WC()->cart->get_cart() as $key => $val ) {
		$_product = $val['data'];
        if($product_id == $_product->get_id()) {
			$quantity = $val['quantity'];
		}
    }
	if($quantity==0){
		WC()->cart->add_to_cart($product_id, '1', '0', array(), $custom_data); 
	}
	//echo "here";die;
	//check if product already in cart
	//if ( WC()->cart->get_cart_contents_count() == 0 ) {
		// if no products in cart, add it
		//WC()->cart->add_to_cart( $product_id );	  
	//}
	
	$url = get_permalink(48);
	if($auction_id==46){
		$url .="/?mode=reactive";
	}elseif($auction_id=='' && $type=='register'){
		$url .="/?mode=register";
	}elseif($type=='monthly' || $type=='single'){
		$url .="/?mode=change-plan";
	}
	wp_redirect($url);
	exit();
}
function pay_for_register_fee($auction_id,$type){
	$custom_data = array();

	// select ID
	if($type=='single'){
		$product_id = 942;	
	}else{
		$product_id = 948;
	}
	$custom_data['custom_data']['auction_id'] = $auction_id;
	$custom_data['custom_data']['plan_id'] = $product_id; 
	$user_id = dokan_get_current_user_id();
	$custom_data['custom_data']['user_id'] = $user_id; 
	WC()->cart->add_to_cart($product_id, '1', '0', array(), $custom_data); 
	//echo "here";die;
	//check if product already in cart
	//if ( WC()->cart->get_cart_contents_count() == 0 ) {
		// if no products in cart, add it
		//WC()->cart->add_to_cart( $product_id );	  
	//}
	$url = get_permalink(48);
	if($auction_id==46){
		$url .="/?mode=reactive";
	}
	wp_redirect($url);
	exit();
}
function pay_for_auction($auction_id,$mode){
	$custom_data = array();
	// select ID
	if($mode=='discount'){
		$product_id = 1642;	
	}else{
		$product_id = 126;	
	}
	$custom_data['custom_data']['auction_id'] = $auction_id; 
	$user_id = dokan_get_current_user_id();
	$custom_data['custom_data']['user_id'] = $user_id; 
	WC()->cart->add_to_cart($product_id, '1', '0', array(), $custom_data); 
	//check if product already in cart
	if ( WC()->cart->get_cart_contents_count() == 0 ) {
		// if no products in cart, add it
		//WC()->cart->add_to_cart( $product_id );	  
	}
	$url = get_permalink(48);
	if($mode=='discount'){
		$url =$url."?mode=relist";
	}
	wp_redirect($url);
}
function get_latlong($street_address){
	//$coordinates = get_latlong($_POST['street_1']." ".$_POST['city']." ".$_POST['state']);
	$street_address = str_replace(" ", "+", $street_address); //google doesn't like spaces in urls, but who does?
	$url 			= 'https://nominatim.openstreetmap.org/search?q='.$street_address.'&format=json&polygon=1&addressdetails=1'; 
	$google_api_response = wp_remote_get( $url ); 
	$results = json_decode( $google_api_response['body'] ); //grab our results from Google
	$results = (array) $results; //cast them to an array
	$latitude = $results[0]->lat;
	$longitude = $results[0]->lon;
	$return = array('latitude'  => $latitude,'longitude' => $longitude);
	return $return;
}
function curl_request($sURL,$sQueryString=null){
	//echo $sURL.'?'.$sQueryString."<br />";
	$cURL=curl_init();
	curl_setopt($cURL,CURLOPT_URL,$sURL.'?'.$sQueryString);
	curl_setopt($cURL,CURLOPT_RETURNTRANSFER, TRUE);
	$cResponse=trim(curl_exec($cURL));
	curl_close($cURL);
	return $cResponse;
}
function get_driving_information($start, $finish, $raw = false){
	$pageurl = "https://www.distance-cities.com/searchbd?from=".urlencode($start)."&to=".urlencode($finish)."&fromId=0&toId=0&flat=0&flon=0&tlat=0&tlon=0";
	$cURL=curl_init();
	curl_setopt($cURL,CURLOPT_URL,$pageurl);
	curl_setopt($cURL,CURLOPT_RETURNTRANSFER, TRUE);
	$html=trim(curl_exec($cURL));
	curl_close($cURL);
	$html = str_replace('&','&amp;',$html);
	$doc = new DOMDocument();
	@$doc->loadHTML($html);

	if(trim($doc->getElementById('sud')->nodeValue) =="" || $doc->getElementById('sud')->nodeValue ==NULL){
		//echo $doc->getElementById('p#results')->nodeValue;
		return str_replace("mi","",str_replace(",","",$doc->getElementById('kmslinearecta')->nodeValue));
	}else{
		return str_replace("mi","",str_replace(",","",$doc->getElementById('sud')->nodeValue));
	}
}
function getUserRole() {

	global $current_user;

	if (is_user_logged_in() ){

		$role = $current_user->roles[0];
		return $role;
	}
	return "";
}
function get_dentist_active_auction(){
	global $wpdb;
	$user_id  = get_current_user_id();
	$postids = array();
	$userauction	 = $wpdb->get_results("SELECT DISTINCT auction_id FROM ".$wpdb->prefix."simple_auction_log WHERE userid = $user_id ",ARRAY_N );
	if(isset($userauction) && !empty($userauction)){
		foreach ($userauction as $auction) {
			$postids[]= $auction[0];
		}
	}
	$args = array('post__in' 			=> $postids ,
					'post_type' 		=> 'product',
					'posts_per_page' 	=> '-1',
                    'order'		=> 'ASC',
                    'orderby'	=> 'meta_value',
                    //'meta_key' 	=> '_auction_dates_to',
					'tax_query' 		=> array(
						array(
							'taxonomy' => 'product_type',
							'field' => 'slug',
							'terms' => 'auction'
						)
					),
					'meta_query' => array(
								array(
									'key'     => '_auction_closed',
									'compare' => 'NOT EXISTS',
								)
					   ),
					'auction_arhive' => TRUE,      
					'show_past_auctions' 	=>  FALSE,      
				);
	$activeloop = new WP_Query( $args );
	if ($activeloop->have_posts()&&!empty($postids)) {
		return 'active';
	}else{
		return 'inactive';
	}
}
function my_active_auction_status(){
	global $wpdb,$today_date_time;
	$query = "SELECT wp_posts.* FROM wp_posts LEFT JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) LEFT JOIN wp_posts AS p2 ON (wp_posts.post_parent = p2.ID) WHERE 1=1 AND ( wp_term_relationships.term_taxonomy_id IN (17) ) AND wp_posts.post_author IN (".dokan_get_current_user_id().") AND wp_posts.post_type = 'product' AND (((wp_posts.post_status = 'publish' OR wp_posts.post_status = 'draft' OR wp_posts.post_status = 'pending') OR (wp_posts.post_status = 'inherit' AND (p2.post_status = 'publish' OR p2.post_status = 'draft' OR p2.post_status = 'pending')))) GROUP BY wp_posts.ID ORDER BY wp_posts.post_date DESC";
	$results = $wpdb->get_results($query, OBJECT);
	$active_auction = array();
	foreach($results as $post){
		$bid_count = $wpdb->get_var($wpdb->prepare("SELECT count(id) as count FROM wp_simple_auction_log WHERE auction_id = %d LIMIT 1",$post->ID));
		$_auction_dates_to = get_post_meta($post->ID, '_auction_dates_to', true );
		$_flash_cycle_start = get_post_meta( $post->ID, '_flash_cycle_start' , TRUE);
		$_flash_cycle_end = get_post_meta( $post->ID, '_flash_cycle_end' , TRUE);
		if(strtotime($_auction_dates_to) > strtotime($today_date_time) && strtotime($today_date_time) < strtotime($_flash_cycle_end) && $bid_count != 0){
			array_push($active_auction,'active');
		}else{
			array_push($active_auction,'inactive');
		}
	}
	if(in_array("active",$active_auction)){
		return 'active';
	}else{
		return 'inactive';
	}
}
function get_plan_orderid(){
	$plan_order_id= '';
	if (is_user_logged_in() ){
		$current_user = wp_get_current_user();
		$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($current_user->ID);
		foreach($subscriptions_users as $row){
			$plan_id = get_post_meta($row->ID,'product_id',true);
			if($plan_id != 1141){
				$metas = get_post_meta($row->ID);
				$payment_due_date = get_post_meta($row->ID,'payment_due_date',true);
				$status = get_post_meta($row->ID,'status',true);
				$expired_date = get_post_meta($row->ID,'expired_date',true);
				if($expired_date ==""){
					if($status=='active'){
						$plan_order_id = $row->ID;
					}
				}else{
					$curDateTime = date("Y-m-d H:i:s");
					$myDate = date("Y-m-d H:i:s",$expired_date);
					if($myDate > $curDateTime){
						if($status=='active'){
							$plan_order_id = $row->ID;
						}
					}
				}
			}
		}
	}
	return $plan_order_id;
}
function get_plan_status(){
	if (is_user_logged_in() ){
		$current_user = wp_get_current_user();
		$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($current_user->ID);
		$plan = 'inactive';
		foreach($subscriptions_users as $row){
			$plan_id = get_post_meta($row->ID,'product_id',true);
			if($plan_id != 1141){
				$metas = get_post_meta($row->ID);
				$status = get_post_meta($row->ID,'status',true);
				if($status=='active'){
					$payment_due_date = get_post_meta($row->ID,'payment_due_date',true);
					$expired_date = get_post_meta($row->ID,'expired_date',true);
					$start_date = get_post_meta($row->ID,'start_date',true);
					if($expired_date ==""){
						if($status=='active'){
							$plan = 'active';
							break;
						}else{
							$plan = 'inactive';
						}
					}else{
						//date_default_timezone_set('Asia/Kolkata');
		
						/*$curDateTime = date("Y-m-d H:i:s");
						$expired_date = date("Y-m-d H:i:s",$expired_date);
						$start_date = date("Y-m-d H:i:s",$start_date);*/
						$curDateTime = date("Y-m-d");
						$expired_date = date("Y-m-d",$expired_date);
						$start_date = date("Y-m-d",$start_date);
						if(isset($_GET['mode'])){
							//echo $expired_date.' > '.$curDateTime;
						}
						if($start_date <=  $curDateTime && $expired_date >= $curDateTime){
							if($status=='active'){
								$plan = "active";
								break;
							}else{
								$plan = "inactive";
							}
						}else{
							$plan = "inactive";
						}
					}
				}
			}
			//echo date("Y-m-d",$payment_due_date);
			
			/*foreach($myvals as $key=>$val){
				echo $key . ' : ' . $val[0] . '<br/>';
			}*/
		}
		return $plan;
	}else{
		return true;
	}
}

add_action( 'woocommerce_payment_complete', 'so_payment_complete' );
function so_payment_complete( $order_id ){
    $subscription = ywsbs_get_subscription_by_order($order_id);
	if($subscription){
		$product_id = get_post_meta($subscription->id,'product_id',true);
		/*
		if($product_id==948){
			$order_subscription_id = $subscription->id;
			$subscriptions = YWSBS_Subscription_Helper()->get_subscriptions_by_user( get_current_user_id() );
			$status = ywsbs_get_status();
			$flag = false;
			foreach ( $subscriptions as $subscription_post ) :
				$subscription = ywsbs_get_subscription( $subscription_post->ID );
				if(($status[$subscription->status]=='active' || $status[$subscription->status] == 'expired') && $subscription->product_id != 1141):
					$flag = true;
					$active_plan = $subscription->product_id;
				endif;
			endforeach;
			if($flag):
			if($active_plan == 942){
				$next_monday = date("Y-m-d",strtotime( "monday next week" ));
				$payment_due_date = date("Y-m-d", strtotime("+1 month", strtotime( "monday next week" )));
				update_post_meta($order_subscription_id,'start_date',strtotime($next_monday));
				update_post_meta($order_subscription_id,'payment_due_date',strtotime($payment_due_date));
			}
			endif;
		}
		if(!$flag):
			//cancel all previouse subscription except current one
			$user_id = get_post_meta($subscription->id,'user_id',true);
			$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($user_id);
			foreach($subscriptions_users as $row){
				$plan_id = get_post_meta($row->ID,'product_id',true);
				if($plan_id != 1141 && $product_id != $plan_id){
					update_post_meta ($row->ID,'status','cancelled');
					update_post_meta ($row->ID,'cancelled_date',strtotime(date("Y-m-d")));
					update_post_meta ($row->ID,'end_date',strtotime(date("Y-m-d")));
				}
			}
		endif;
		*/
		//cancel all previouse subscription except current one
		//important
		$user_id = get_post_meta($subscription->id,'user_id',true);
		$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($user_id);
		$active_cancelled_flag = 'no';
		foreach($subscriptions_users as $row){
			$plan_id = get_post_meta($row->ID,'product_id',true);
			if($plan_id != 1141 && $product_id != $plan_id){
				if($plan_id==948 && $product_id==942){
					//first deactive the recurring subscription
					$payment_due_date = get_post_meta( $row->ID, 'payment_due_date', true );
					if($payment_due_date){
						$deactive_date = strtotime("+4 week", $payment_due_date);
						update_post_meta ($row->ID,'cancelled_date',$deactive_date);
						update_post_meta ($row->ID,'end_date',$deactive_date);
						update_post_meta ($row->ID,'_plan_status',"active_cancelled");
						$status = get_post_meta($row->ID,'status',true);
						if($status=='active'){
							$active_cancelled_flag = 'yes';
							//calculate subscription for next week plan
							$next_monday_after_deactive = date('Y-m-d',strtotime("monday next week",$deactive_date))." 08:30";
							$next_friday_after_deactive = date('Y-m-d',strtotime("friday next week",$deactive_date))." 10:30";
						}
					}
					/*echo $payment_due_date."<br />";		
					echo $next_monday_after_deactive."<br />";
					echo $next_monday_after_deactive."<br />";
					die;*/
				}else{
					update_post_meta ($row->ID,'status','cancelled');
					update_post_meta ($row->ID,'cancelled_date',strtotime(date("Y-m-d")));
					update_post_meta ($row->ID,'end_date',strtotime(date("Y-m-d")));
				}
			}
			
			/**/
		}
		/*****************************************/
		if($product_id==942){
			if($active_cancelled_flag=='yes'){
				$this_monday =$next_monday_after_deactive;
				$this_thursday =$next_friday_after_deactive;
			}else{
				$this_monday = date("Y-m-d",strtotime( "monday this week" ))." 08:30";
				$this_thursday = date('Y-m-d', strtotime( 'friday this week' ) )." 10:30";
			}
			update_post_meta($subscription->id,'start_date',strtotime($this_monday));
			update_post_meta($subscription->id,'payment_due_date',strtotime($this_thursday));
			update_post_meta($subscription->id,'expired_date',strtotime($this_thursday));
		}
		if($product_id==1141){
			update_user_meta ( get_current_user_id(),'dentist_account_status','active');
		}
		
	}
	$order = wc_get_order( $order_id );
	$items = $order->get_items();
	foreach ( $items as $item ) {
		//$product_name = $item->get_name();
		$product_id = $item->get_product_id();
		//$product_variation_id = $item->get_variation_id();
		//$item_meta_data = $item->get_meta_data();
		$Auction_id = $item->get_meta('Auction ID');
		//print_r($item_meta_data);
		if($Auction_id){
			$postData = array('ID' =>$Auction_id, 'post_status' =>'publish');
			wp_update_post( $postData );
		}
	}
	if(isset($_POST['wc-yith-stripe-payment-token'])  && $_POST['wc-yith-stripe-payment-token'] =='new'){
		if(isset($_POST['card-number']) && $_POST['card-number']!=""){
			$number_array = explode(" ",$_POST['card-number']);
			//$last_part = array_pop($number_array);
			//$card_number = implode(" ",$number_array)." XXXX";
			update_post_meta($order_id,'_credit_card_number',end($number_array));
		}
	}
	if(!isset($_POST['wc-yith-stripe-payment-token'])){
		if(isset($_POST['card-number']) && $_POST['card-number']!=""){
			$number_array = explode(" ",$_POST['card-number']);
			//$last_part = array_pop($number_array);
			//$card_number = implode(" ",$number_array)." XXXX";
			update_post_meta($order_id,'_credit_card_number',end($number_array));
		}
	}
	if(isset($_POST['wc-yith-stripe-payment-token'])  && $_POST['wc-yith-stripe-payment-token'] !='new'){
		//if(isset($_POST['card-number-save']) && $_POST['card-number-save']!=""){
			$token_id = $_POST['wc-yith-stripe-payment-token'];
			update_post_meta($order_id,'_credit_card_number',$_POST['card-number-save-'.$token_id]);
		//}
	}
	
}
add_filter( 'woocommerce_payment_gateway_get_saved_payment_method_option_html', 'custom_card_number', 10, 3 );
function custom_card_number( $html, $token, $that ){
	// filter...
	$label = esc_html( $token->get_display_name() );
	$tmp = explode("ending in ",$label);
	$tmp2 = explode(" (",$tmp[1]);
	if($tmp2[0] !=""){
		$html .= '<input type="hidden" name="card-number-save-'.$token->get_id().'" value="'.$tmp2[0].'"/>';
	}
	return $html;
}
add_filter('woocommerce_email_recipient_customer_processing_order', 'wh_OrderProcessRecep', 10, 2);
function wh_OrderProcessRecep($recipient, $order){
    $order_id = $order->get_order_number();
	if(isset($_POST['wc-yith-stripe-payment-token'])  && $_POST['wc-yith-stripe-payment-token'] =='new'){
		if(isset($_POST['card-number']) && $_POST['card-number']!=""){
			$number_array = explode(" ",$_POST['card-number']);
			//$last_part = array_pop($number_array);
			//$card_number = implode(" ",$number_array)." XXXX";
			update_post_meta($order_id,'_credit_card_number',end($number_array));
		}
	}
	if(isset($_POST['wc-yith-stripe-payment-token'])  && $_POST['wc-yith-stripe-payment-token'] !='new'){
		//if(isset($_POST['card-number-save']) && $_POST['card-number-save']!=""){
			$token_id = $_POST['wc-yith-stripe-payment-token'];
			update_post_meta($order_id,'_credit_card_number',$_POST['card-number-save-'.$token_id]);
		//}
	}
    return $recipient;
}
add_action('gform_user_registered','add_dokan_address', 10, 4 ); 
function add_dokan_address( $user_id, $feed, $entry, $user_pass ) {
	  $shopname = rgar( $entry, '4' );
	  $phone = rgar( $entry, '9' );
	  $dokan_settings = array(
            'store_name'     => sanitize_text_field( wp_unslash($shopname)),
            'social'         => array(),
            'payment'        => array(),
            'phone'          => '',
			'address'        => array(),
            'show_email'     => 'no',
            'location'       => '',
            'find_address'   => '',
            'dokan_category' => '',
            'banner'         => 0,
        );
	update_user_meta( $user_id, 'dokan_enable_selling', 'yes' );
	update_user_meta( $user_id, 'dokan_profile_settings', $dokan_settings );
	update_user_meta( $user_id, 'dokan_store_name', $shopname);
}
add_filter('gform_us_states', 'us_states');
function us_states( $states ) {
    $new_states = array();
    foreach ( $states as $state ) {
        $new_states[ GF_Fields::get( 'address' )->get_us_state_code( $state ) ] = $state;
    }
    return $new_states;
}

add_action('um_registration_complete','after_registration_complete', 10, 2 );
function after_registration_complete($user_id, $args) {
	if($_POST['form_id']==103){
		global $US_state;
		$shopname = $_POST['user_login-103'];
		$phone = $_POST['phone_number-103'];
		$dokan_settings = array(
			'store_name'     => sanitize_text_field( wp_unslash($shopname)),
			'social'         => array(),
			'payment'        => array(),
			'phone'          => sanitize_text_field( wp_unslash($phone) ),
			'address'        => array(
							"street_1"=>strip_tags($_POST['client_street-103']),
							"street_2"=>strip_tags($_POST['client_apt_no-103']),
							"city"=>strip_tags($_POST['client_city-103']),
							"state"=>strip_tags($US_state[$submitted['client_state']]),
							"zip"=>strip_tags($_POST['client_zipcode_new-103']),
							"country"=>'US'),
			'show_email'     => 'no',
			'location'       => '',
			'find_address'   => '',
			'dokan_category' => '',
			'banner'         => 0,
		);
		update_user_meta( $user_id, 'dokan_enable_selling', 'yes' );
		update_user_meta( $user_id, 'dokan_profile_settings', $dokan_settings );
		update_user_meta( $user_id, 'dokan_store_name', $shopname);
	}
    // your code here
}
add_action( 'um_user_after_updating_profile', 'my_user_after_updating_profile', 10, 1 );
function my_user_after_updating_profile( $submitted ) {
		global $US_state;
		$user = wp_get_current_user();
		if($user->roles[0]=='seller'){
			$user_id = $user->ID;
			$shopname = $user->user_login;
			$phone = $submitted['phone_number'];
			$dokan_settings = array(
				'store_name'     => sanitize_text_field( wp_unslash($shopname)),
				'social'         => array(),
				'payment'        => array(),
				'phone'          => sanitize_text_field( wp_unslash($phone) ),
				'address'        => array(
								"street_1"=>strip_tags($submitted['client_street']),
								"street_2"=>strip_tags($submitted['client_apt_no']),
								"city"=>strip_tags($submitted['client_city']),
								"state"=>strip_tags($US_state[$submitted['client_state']]),
								"zip"=>strip_tags($submitted['client_zipcode_new']),
								"country"=>'US'),
				'show_email'     => 'no',
				'location'       => '',
				'find_address'   => '',
				'dokan_category' => '',
				'banner'         => 0,
			);
			update_user_meta( $user_id, 'dokan_profile_settings', $dokan_settings );
		}
}
add_action( 'dokan_edit_auction_product_content_before', 'dokan_edit_auction_product_content_before_custom');
function dokan_edit_auction_product_content_before_custom(){
	if ( isset( $_GET['message'] ) && $_GET['message'] == 'success') {
		$custom_data = array();
		// select ID
		$product_id = 126;	
		$custom_data['custom_data']['auction_id'] = $_GET['product_id']; 
		$user_id = dokan_get_current_user_id();
		$custom_data['custom_data']['user_id'] = $user_id; 
		WC()->cart->add_to_cart($product_id, '1', '0', array(), $custom_data); 
		//check if product already in cart
		if ( WC()->cart->get_cart_contents_count() == 0 ) {
			// if no products in cart, add it
			//WC()->cart->add_to_cart( $product_id );	  
		}
		$url = get_permalink(48);
		wp_redirect($url);
		exit;
	}
}

function iconic_add_engraving_text_to_cart_item($cart_item_data, $product_id, $variation_id ) {
	$cart_item_data['auction_id'] = $cart_item_data['custom_data']['auction_id'];
	$cart_item_data['user_id'] = $cart_item_data['custom_data']['user_id'];
    return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'iconic_add_engraving_text_to_cart_item', 10, 3 );
function iconic_display_engraving_text_cart( $item_data, $cart_item ) {
	if ( empty( $cart_item['auction_id'] ) ) {
		return $item_data;
	}
	
	$item_data = array();
	
	if($cart_item['product_id']==942 || $cart_item['product_id']==948){
		/*$item_data[] = array(
		'key'     => __( 'Auction ID', 'iconic' ),
		'value'   =>  $cart_item['auction_id'],
			'display' => '',
	
		);*/
		if($cart_item['product_id']==942){
			/*$this_monday = date("Y-m-d",strtotime( "monday this week" ))." 08:30";
			$this_thursday = date('Y-m-d', strtotime( 'friday this week' ) )." 10:30";*/
			$dates = explode("##",get_plan_dates(942));
			$this_monday = $dates[0];
			$this_thursday = $dates[1];
			$item_data[] = array(
			'key'     => __( 'Auction Cycle Starts', 'iconic' ),
			'value'   =>  date_i18n( get_option( 'date_format' ),  strtotime($this_monday)).' '.date('g:i A',strtotime($this_monday)).' PT',
			'display' => '',
	
			);
			$item_data[] = array(
				'key'     => __( 'Auction Cycle Ends', 'iconic' ),
				'value'   =>  date_i18n( get_option( 'date_format' ),  strtotime( $this_thursday )).' '.date('g:i A',strtotime($this_thursday)).' PT',
				'display' => '',
		
			);
		}
	}else{
		
		$item_data[] = array(
		'key'     => __( 'Auction ID', 'iconic' ),
		'value'   =>  $cart_item['auction_id'],
			'display' => '',
	
		);
		if($cart_item['auction_id'] != 46){
			if (defined('DOING_AJAX') && DOING_AJAX) {
			}else{
				echo '<script> jQuery("#back_btn_div").html("<a href=\"'.home_url('auction-activity/auction/?product_id='.$cart_item['auction_id'].'&action=edit').'\" style=\"font-size:17px !important;\" class=\"dokan-btn dokan-btn-theme btn-primary\" title=\"Back\">Back</a>");</script>';
			}
			$product = wc_get_product( $cart_item['auction_id'] );
			$item_data[] = array(
				'key'     => __( 'Service', 'iconic' ),
				'value'   =>  $product->get_name(),
				'display' => '',
		
			);
			$item_data[] = array(
				'key'     => __( 'Auction Begins', 'iconic' ),
				'value'   =>  date_i18n( get_option( 'date_format' ),  strtotime( $product->get_auction_start_time() )).' '.date_i18n( get_option( 'time_format' ),  strtotime( $product->get_auction_start_time() )),
				'display' => '',
		
			);
			$item_data[] = array(
				'key'     => __( 'Auction Ends', 'iconic' ),
				'value'   =>  date_i18n( get_option( 'date_format' ),  strtotime( $product->get_auction_end_time() )).' '.date_i18n( get_option( 'time_format' ),  strtotime( $product->get_auction_end_time() )),
				'display' => '',
		
			);
			$_flash_cycle_start = get_post_meta($cart_item['auction_id'], '_flash_cycle_start',true);
			$_flash_cycle_end = get_post_meta($cart_item['auction_id'], '_flash_cycle_end',true );
			$item_data[] = array(
				'key'     => __( 'Flash Bid Cycle<span class="TM_flash" style="position:relative;top: -5px;">®</span> <small>(if needed)</small>', 'iconic' ),
				'value'   =>  date_i18n(get_option('date_format'),strtotime($_flash_cycle_start)).' from '.date("g:i A",strtotime($_flash_cycle_start)).' to '.date_i18n(str_replace("@ ","",get_option('time_format')),strtotime($_flash_cycle_end)),
				'display' => '',
		
			);
		}
	}
	$item_data[] = array(
		'key'     => __( 'User', 'iconic' ),
		'value'   => $cart_item['user_id'] ,
		'display' => '',

		);
	return $item_data;
}
add_filter( 'woocommerce_get_item_data', 'iconic_display_engraving_text_cart', 10, 2 );
function iconic_add_engraving_text_to_order_items( $item, $cart_item_key, $values, $order ) {
	if ( empty( $values['auction_id'] ) ) {
		return;
	}
	if($values['product_id']==942 || $values['product_id']==948){
		if($values['product_id']==942){
			/*$this_monday = date("Y-m-d",strtotime( "monday this week" ))." 08:30";
			$this_thursday = date('Y-m-d', strtotime( 'friday this week' ) )." 10:30";*/
			$dates = explode("##",get_plan_dates(942));
			$this_monday = $dates[0];
			$this_thursday = $dates[1];
			$item->add_meta_data( __( 'Auction Cycle Starts', 'iconic' ),date_i18n( get_option( 'date_format' ),  strtotime( $this_monday )).' '.date('g:i A',strtotime($this_monday)).' PT');
		$item->add_meta_data( __( 'Auction Cycle Ends', 'iconic' ),date_i18n( get_option( 'date_format' ),  strtotime( $this_thursday )).' '.date('g:i A',strtotime($this_thursday)).' PT');
		}
		
	}else{
		//print_r($values);
		$product = wc_get_product( $values['auction_id'] );
		$item->add_meta_data( __( 'Auction ID', 'iconic' ), $values['auction_id'] );
		if($values['auction_id'] != 46){
			$item->add_meta_data( __( 'Service', 'iconic' ), $product->get_name() );
			$item->add_meta_data( __( 'Auction Begins', 'iconic' ), date_i18n( get_option( 'date_format' ),  strtotime( $product->get_auction_start_time() )).' '.date_i18n( get_option( 'time_format' ),  strtotime( $product->get_auction_start_time() )) );
			$item->add_meta_data( __( 'Auction Ends', 'iconic' ),date_i18n( get_option( 'date_format' ),  strtotime( $product->get_auction_end_time() )).' '.date_i18n( get_option( 'time_format' ),  strtotime( $product->get_auction_end_time() )) );
			
			$_flash_cycle_start = get_post_meta($values['auction_id'], '_flash_cycle_start',true);
			$_flash_cycle_end = get_post_meta($values['auction_id'], '_flash_cycle_end',true );
			$item->add_meta_data( __( 'Flash Bid Cycle<span class="TM_flash" style="position:relative;top: -5px;">®</span> <small>(if needed)</small>', 'iconic' ),str_replace(" PT","",date_i18n(get_option('date_format'),strtotime($_flash_cycle_start))).' from '.date("g:i A",strtotime($_flash_cycle_start)).' to '.date_i18n(str_replace("@ ","",get_option('time_format')),strtotime($_flash_cycle_end)));
		}
	}
}
add_action( 'woocommerce_checkout_create_order_line_item', 'iconic_add_engraving_text_to_order_items', 10, 4 );
add_action( 'woocommerce_order_status_completed', 'my_woocommerce_order_status_completed', 10, 1 );
function my_woocommerce_order_status_completed( $order_id ) {
	global $wpdb;
    $order       = wc_get_order( $order_id );
	$customer_id = $order->get_customer_id();
	$order = new WC_Order($order_id);
	//print_r($order);
	$Auction_id = '';
	$order_item = $order->get_items();
	foreach($order_item as $item_id => $item ){
		$Auction_id = $item->get_meta('Auction ID');
		if($Auction_id > 0 && $Auction_id !=""){
			 $post   = get_post( $Auction_id );
			 $seller = get_user_by( 'id', $post->post_author );
			 do_action( 'dokan_pending_product_published_notification', $post, $seller );
			
			$postData = array('ID' =>$Auction_id, 'post_status' =>'publish');
			wp_update_post( $postData );
		}
	}
	
}


add_action( 'woocommerce_edit_account_form', 'my_woocommerce_edit_account_form' );
function my_woocommerce_edit_account_form() {
  global $US_state;
  $user_id = get_current_user_id();
  $user = get_userdata( $user_id );
  if ( !$user )
    	return;
  $url = $user->user_url;
  if($user->roles[0]=='customer'){
		/*$new_auction_notification = get_user_meta( $user_id, 'new_auction_notification', true );
		$checked = '';
		if($new_auction_notification=='yes'){
			$checked = ' checked="checked" ';
		}
		echo '<a name="new_auction_notification">&nbsp;</a><br /><br />';
		echo '<input type="checkbox" name="new_auction_notification" value="yes" '.$checked.'/>&nbsp;<strong>Get notified immediately when new auctions are available in your area</strong><br /><br />';*/
		
		$key = 'designation';
		$value = get_user_meta( $user_id, 'designation', true );
		$options = array('DDS'=>'DDS','DMD'=>'DMD');
		echo '<p class="form-row form-row-thirds">
			  <label for="street">Designation</label>';
			  echo $value;
			 echo '<select name="'.$key.'" class="input-text hide" disabled="disabled"><option value="">Please Select</option>';
			  
		foreach($options as $k => $v){
			$selected = '';
			if($value==$k){
				$selected = ' selected="selected"';
			}?>
				<option value="<?php echo esc_attr($k); ?>" <?php echo $selected; ?>><?php echo esc_attr( $k ); ?></option>
			
		<?php }
		 echo '</select></p>';
			 
	}
  if($user->roles[0]=='customer'){
	$disable_array = array('dentist_office_street','dentist_office_apt_no','dentist_office_city','dentist_office_state','dentist_office_zip_code','dentist_office_email');
  	$field_array = array('<span class="tooltip_New">Change office address where treatment is administered<span class="tooltips" title="Please contact admin@Shopadoc.com to request any change to office address where treatment is rendered.">i</span>' => 'label',
					 'dentist_office_street'=>'Street',
					'dentist_office_apt_no'=>'Suite #' ,
					 'dentist_office_city'=>'City',
					 'dentist_office_state'=>'State',
					 'dentist_office_zip_code'=>'Zip Code',
					 'dentist_office_email'=>'Office email',
					 'dentist_personal_cell'=>'Office <i class="fa fa-phone icon">&nbsp;</i>',
					 'Change Licensed Dentist\'s address on file with the State Board of Dental Examiners'=>'label',
					 'dentist_home_street'=>'Street',
					 'dentist_home_apt_no'=>'Suite #',
					 'dentist_home_city'=>'City',
					 'dentist_home_state'=>'State',
					 'dentist_home_zip'=>'Zip Code',
					 'state_dental_license_no'=>'State Dental License #',);
	
  }elseif($user->roles[0]=='seller'){
	  $active_status = my_active_auction_status();
	  if($active_status=='active'){
		  $disable_array = array('client_street','client_apt_no','client_city','client_state','client_zip_code');
	  }else{
		  $disable_array = array();
	  }
	  $field_array = array(
	  				 'Change Address' => 'label',
					 'client_street'=>'Street',
					'client_apt_no'=>'Suite #' ,
					 'client_city'=>'City',
					 'client_state'=>'State',
					 'client_zip_code'=>'Zip Code',
					 'Change Phone Number' => 'label',
					 'client_cell_ph'=>'Mobile <i class="fa fa-phone icon">&nbsp;</i>',
					 'client_home_ph'=>'Home <i class="fa fa-phone icon">&nbsp;</i>',);
  }else{
	  $field_array =array();
  }
	echo '<fieldset>';				
	
	foreach ($field_array as $key => $val){		
		if($val=='label'){
			echo '<legend class="blue_text">'.$key.'</legend>';
		}elseif($val=='State'){
			$value = get_user_meta( $user_id, $key, true );
			echo '<p class="form-row form-row-thirds">
                  <label for="street">'.$val.'</label>';
				  if(in_array($key,$disable_array)){
					  echo $value;
				  	echo '<select name="'.$key.'" class="input-text hide" disabled="disabled" readonly="readonly" >';
				  }else{
					  echo '<select name="'.$key.'" class="input-text" >';
				  }
			foreach($US_state as $k => $v){
				$selected = '';
				if($value==$k){
					$selected = ' selected="selected"';
				}?>
                	<option value="<?php echo esc_attr($k); ?>" <?php echo $selected; ?>><?php echo esc_attr( $k ); ?></option>
                
			<?php }
			 echo '</select></p>';
			?>
			
		<?php }elseif($val=='Designation'){}else{
			$value = get_user_meta( $user_id, $key, true );	
		  ?>
			<p class="form-row form-row-thirds">
			  <label for="street"><?php echo $val;?></label>
              <?php if(in_array($key,$disable_array)){?>
			  	<input type="text" name="<?php echo $key;?>" value="<?php echo esc_attr( $value ); ?>" class="input-text" disabled="disabled" readonly="readonly"/>
              <?php }else{?>
			  	<input type="text" name="<?php echo $key;?>" value="<?php echo esc_attr( $value ); ?>" class="input-text" />
              <?php }?>
			</p>
		  <?php
		}
	}
	if($user->roles[0]=='customer'){
		if(isset($_GET['mode']) && ($_GET['mode']=='active' || $_GET['mode']=='de-active' || $_GET['mode']== 'unsubscribe')){
			//get_user_meta( $user_id, 'dentist_account_status', true );
			//if(!add_user_meta($user_id,'dentist_account_status',$_GET['mode'])) {
				update_user_meta ($user_id,'dentist_account_status',$_GET['mode']);
				if($_GET['mode']=='de-active' &&1==2){
					 global $current_user;
					$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($current_user->ID);
					foreach($subscriptions_users as $row){
						$plan_id = get_post_meta($row->ID,'product_id',true);
						if($plan_id != 1141){
							update_post_meta ($row->ID,'status','cancelled');
							update_post_meta ($row->ID,'cancelled_date',strtotime(date("Y-m-d")));
							update_post_meta ($row->ID,'end_date',strtotime(date("Y-m-d")));
						}
					}
				}
				
				if($_GET['mode']=='unsubscribe'){
					 global $current_user;
					$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($current_user->ID);
					foreach($subscriptions_users as $row){
						$plan_id = get_post_meta($row->ID,'product_id',true);
						if($plan_id == 1141 || 1==1){
							update_post_meta ($row->ID,'status','cancelled');
							update_post_meta ($row->ID,'cancelled_date',strtotime(date("Y-m-d")));
							update_post_meta ($row->ID,'end_date',strtotime(date("Y-m-d")));
						}
					}
				}
			//}
		}
		$dentist_account_status = get_user_meta( $user_id, 'dentist_account_status', true );
		//echo '<a name="dentist_account_status">&nbsp;</a><br /><br />';
		echo '<style type="text/css">.woocommerce-EditAccountForm button.woocommerce-Button{margin-top:-50px !important;}</style>';
		if($dentist_account_status=='de-active' && 1==2){
			echo '<p style="float:right;">Your account is currently deactived.&nbsp;';
			echo '<a href="'.home_url('/my-account/edit-account/?mode=active').'" class="bid_on" style="float:right;">Activate Account</a></p>';
			?>
           <!--<p style="float:right;clear:both;"> <a href="javascript:" class="example2 woocommerce-Button button">unsubscribe from all emails</a></p>-->
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
				<script type="text/javascript">
                                jQuery('.example2').on('click', function(){
                                    jQuery.confirm({
                                        title: 'Please Confirm',
										columnClass: 'col-md-6 col-md-offset-3',
                                        content: 'Are you sure you want to unsubscribe from all future emails?',
                                        buttons: {
											No: {
                                                text: 'No, keep me subscribed',
                                                //btnClass: 'btn-blue',
                                                /*keys: [
                                                    'enter',
                                                    'shift'
                                                ],*/
                                                /*action: function(){
                                                    //this.jQuerycontent // reference to the content
                                                    jQuery.alert('No');
                                                }*/
                                            },
                                            Yes: {
                                                text: 'Yes, please unsubscribe me',
                                                btnClass: 'btn-blue',
                                                /*keys: [
                                                    'enter',
                                                    'shift'
                                                ],*/
                                                action: function(){
                                                   // this.jQuerycontent // reference to the content
                                                    //jQuery.alert('Yes');
													window.location.replace("<?php echo home_url('/my-account/edit-account/?mode=unsubscribe');?>");
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>
			<?php
		}elseif($dentist_account_status =='unsubscribe' || $dentist_account_status=='de-active'){
			echo '<a href="'.get_site_url().'/?action=add_to_cart&type=register&auction_id=" class="" style="float:right;">Reactivate account</a>';
		}elseif(($dentist_account_status =='active' || $dentist_account_status =="")){
			$dentist_auction_status = get_dentist_active_auction();
			echo '<a href="javascript:" class="example2" style="float:right;">Deactivate Account</a>';
			?>
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

				<script type="text/javascript">
								<?php if($dentist_auction_status=='active'){?>
                               jQuery('.example2').on('click', function(){
                                    jQuery.alert({
                                        title: 'Alert!',
										columnClass: 'col-md-6 col-md-offset-3',
                                        content: 'Auction(s) in progress, you cannot deactivate at this time.',
                                    });
                                });
                            	<?php }else{?>
                                jQuery('.example2').on('click', function(){
                                    jQuery.confirm({
                                        title: 'Please Confirm',
										columnClass: 'col-md-8 col-md-offset-3',
                                        content: 'Are you sure you want to deactivate your account?<br />Deactivation will require a new registration fee be paid if you ever wish to reactivate.',
                                        buttons: {
											Yes: {
                                                text: 'Yes',
                                                action: function(){
                                                	window.location.replace("<?php echo home_url('/my-account/edit-account/?mode=de-active');?>");
                                                }
                                            },
											No: {
                                                text: 'No',
												btnClass: 'btn-blue',
                                            },
                                            
                                        }
                                    });
                                });
								<?php }?>
                            </script>
			<?php
		}
	}
	echo " </fieldset>";
 
}
add_action('woocommerce_save_account_details','my_woocommerce_save_account_details',10,1);
function my_woocommerce_save_account_details( $user_id ) {
 global $US_state;
 $user = get_userdata( $user_id );
  if ( !$user )
    	return;
 if($user->roles[0]=='customer'){
	 $disable_array = array('dentist_office_street','dentist_office_apt_no','dentist_office_city','dentist_office_state','dentist_office_zip_code','dentist_office_email');
  	$field_array = array('new_auction_notification'=>'New Auction Notification',
					 'designation'=>'Designation',
					 'Office address' => 'label',
					 'dentist_office_street'=>'Street',
					'dentist_office_apt_no'=>'Suite #' ,
					 'dentist_office_city'=>'City',
					 'dentist_office_state'=>'State',
					 'dentist_office_zip_code'=>'Zip Code',
					 'dentist_office_email'=>'Office email',
					 'dentist_personal_cell'=>'Personal cell',
					 'Home address'=>'label',
					 'dentist_home_street'=>'Street',
					 'dentist_home_apt_no'=>'Suite #',
					 'dentist_home_city'=>'City',
					 'dentist_home_state'=>'State',
					 'dentist_home_zip'=>'Zip Code',
					 'state_dental_license_no'=>'State Dental License #',);
	
  }elseif($user->roles[0]=='seller'){
	  $active_status = my_active_auction_status();
	  if($active_status=='active'){
		  $disable_array = array('client_street','client_apt_no','client_city','client_state','client_zip_code');
	  }else{
		  $disable_array = array();
	  }
	  $field_array = array(
					 'client_street'=>'Street',
					'client_apt_no'=>'Suite #' ,
					 'client_city'=>'City',
					 'client_state'=>'State',
					 'client_zip_code'=>'Zip Code',
					 'client_cell_ph'=>'Client cell ph.',
					 'client_home_ph'=>'Client home ph.',);
					 
	$shopname = $user->user_login;
	$submitted = $_POST['wpforms']['fields'];
	//print_r($submitted);die;
	$phone = $_POST['client_home_ph'];
	$dokan_settings = array(
		'store_name'     => sanitize_text_field( wp_unslash($shopname)),
		'social'         => array(),
		'payment'        => array(),
		'phone'          => sanitize_text_field( wp_unslash($phone) ),
		'address'        => array(
						"street_1"=>strip_tags($_POST['client_street']),
						"street_2"=>strip_tags($_POST['client_apt_no']),
						"city"=>strip_tags($_POST['client_city']),
						"state"=>strip_tags($US_state[$_POST['client_state']]),
						"zip"=>strip_tags($_POST['client_zip_code']),
						"country"=>'US'),
		'show_email'     => 'no',
		'location'       => '',
		'find_address'   => '',
		'dokan_category' => '',
		'banner'         => 0,
	);
	update_user_meta( $user_id, 'dokan_profile_settings', $dokan_settings );				 
  }else{
	  $field_array =array();
  }
  foreach($field_array as $key => $val){
	if(!in_array($key,$disable_array)){				 
  		update_user_meta( $user_id,$key, htmlentities( $_POST[ $key ] ) );
	}
  }
}
function my_user_after_updating_profile_custom( $user_id, $fields, $form_data, $userdata ) {
	global $US_state;
	//$user_id = get_current_user_id();
	$user = get_userdata( $user_id );
	if($user->roles[0]=='seller'){
		$shopname = $user->user_login;
		$submitted = $_POST['wpforms']['fields'];
		//print_r($submitted);die;
		$phone = $submitted['28'];
		$dokan_settings = array(
			'store_name'     => sanitize_text_field( wp_unslash($shopname)),
			'social'         => array(),
			'payment'        => array(),
			'phone'          => sanitize_text_field( wp_unslash($phone) ),
			'address'        => array(
							"street_1"=>strip_tags($submitted['22']),
							"street_2"=>strip_tags($submitted['23']),
							"city"=>strip_tags($submitted['24']),
							"state"=>strip_tags($US_state[$submitted['25']]),
							"zip"=>strip_tags($submitted['26']),
							"country"=>'US'),
			'show_email'     => 'no',
			'location'       => '',
			'find_address'   => '',
			'dokan_category' => '',
			'banner'         => 0,
		);
		update_user_meta( $user_id, 'dokan_profile_settings', $dokan_settings );
		//Auto Login Code
		wp_set_current_user($user_id);
		wp_set_auth_cookie($user_id);
		//wp_redirect(get_permalink(15));
		wp_redirect(dokan_get_navigation_url('new-auction-product'));
		exit;
	}else{
		//Auto Login Code
		wp_set_current_user($user_id);
		wp_set_auth_cookie($user_id);
		//wp_redirect(home_url('/my-account/edit-account/'));
		//exit;
	}

}
add_action( 'wpforms_user_registered', 'my_user_after_updating_profile_custom', 50, 4 );
add_action( 'wpforms_frontend_output_before', 'check_if_login', 10, 3 );
function check_if_login($form_data,$form){
	if($form->ID==154 || $form->ID==185){
		if (is_user_logged_in()){
			wp_redirect(wc_customer_edit_account_url());
		}
	}
}
add_filter ( 'woocommerce_account_menu_items', 'misha_remove_my_account_links',100,1 );
function misha_remove_my_account_links( $menu_links ){
 
	unset( $menu_links['edit-address'] ); // Addresses
 	//unset( $menu_links['dashboard'] ); // Remove Dashboard
	//unset( $menu_links['payment-methods'] ); // Remove Payment Methods
	unset( $menu_links['orders'] ); // Remove Orders
	unset( $menu_links['downloads'] ); // Disable Downloads
	unset( $menu_links['auctions-endpoint'] );
	//unset( $menu_links['edit-account'] ); // Remove Account details tab
	//unset( $menu_links['customer-logout'] ); // Remove Logout link
	 //$menu_links['my-auctions'] = __( 'My Auction', 'iconic' );
 //print_r($menu_links);
 	$auctions_item = array('dashboard' => __( 'Dashboard', 'woocommerce' ),'my-auctions' => __( 'My Auction', 'woocommerce' ) );
    // Remove 'subscriptions' key / label pair from original $items array
    unset( $menu_links['my-auctions'] );
	unset( $menu_links['dashboard'] );

    // merging arrays
    $menu_links = array_merge( $auctions_item, $menu_links );
	
	return $menu_links;
 
}
function iconic_add_my_auctions_endpoint() {
    add_rewrite_endpoint( 'my-auctions', EP_PAGES );
	if(isset($_POST['wptp_popup_id'])&& $_POST['wptp_popup_id'] !=""){
		$current_user = wp_get_current_user();
		if ($current_user->ID){
			add_option('termpopup_'.$current_user->ID,'accepted', '', 'yes' );
		}
	}
}
add_action( 'init', 'iconic_add_my_auctions_endpoint' );
function iconic_my_auctions_endpoint_content() {
    //echo 'Your new content';
	echo do_shortcode('[woocommerce_simple_auctions_my_auctions]');
	// [woocommerce_simple_auctions_my_auctions]
}
 
add_action( 'woocommerce_account_my-auctions_endpoint', 'iconic_my_auctions_endpoint_content' );


add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );
function woo_remove_product_tabs( $tabs ) {
    unset( $tabs['shipping'] );      	// Remove the description tab
    unset( $tabs['reviews'] ); 			// Remove the reviews tab
    unset( $tabs['seller'] );  	// Remove the additional information tab
	unset($tabs['more_seller_product']);
	unset($tabs['simle_auction_history']);
    return $tabs;
}
add_action( 'template_redirect','auction_handle_relist', 11 );
function auction_handle_relist(){
        if ( !is_user_logged_in() ) {
            return;
        }
		//Remoe persistent Items From Cart
		$user_id = dokan_get_current_user_id();
		foreach(WC()->cart->get_cart() as $key => $val ) {
			$user_id_cart_item = $val['custom_data']['user_id'];
			$_product = $val['data'];
			if($user_id_cart_item != $user_id){
			   if ($key) WC()->cart->remove_cart_item($key);
			}
		}
		if(isset($_GET['mode'])&& $_GET['mode']=='de-active-sub'){
			global $current_user;
			$subscriptions_users = YWSBS_Subscription_Helper()->get_subscriptions_by_user($current_user->ID);
			foreach($subscriptions_users as $row){
				$plan_id = get_post_meta($row->ID,'product_id',true);
				if($plan_id != 1141){
					$status = get_post_meta($row->ID,'status',true );
					if($status=='active'){
						/*update_post_meta ($row->ID,'status','cancelled');
						update_post_meta ($row->ID,'cancelled_date',strtotime(date("Y-m-d")));
						update_post_meta ($row->ID,'end_date',strtotime(date("Y-m-d")));*/
						$payment_due_date = get_post_meta( $row->ID, 'payment_due_date', true );
						$deactive_date = strtotime("+4 week", $payment_due_date);
						update_post_meta ($row->ID,'cancelled_date',$deactive_date);
						update_post_meta ($row->ID,'end_date',$deactive_date);
						update_post_meta ($row->ID,'_plan_status',"active_cancelled");
						/*
						$this->set( 'end_date', $this->payment_due_date );
						$this->set( 'payment_due_date', '' );
						$this->set( 'cancelled_date', current_time( 'timestamp' ) );
						$this->set( 'status', $new_status );
						*/
					}
				}
			}
		}
		global $woocommerce;
		if( is_cart() && WC()->cart->cart_contents_count == 0){
			wp_safe_redirect(home_url('/auction-activity/new-auction-product/'));
			exit();
		}
		if ( isset($_REQUEST['action'])&&$_REQUEST['action'] == 'clear_cart') {
			global $woocommerce;
			$woocommerce->cart->empty_cart();
		}
		if ( isset($_REQUEST['action'])&&$_REQUEST['action'] == 'add_to_cart') {
			pay_for_plan($_GET['auction_id'],$_GET['type']);
		}
        if ( !dokan_is_user_seller( get_current_user_id() ) ) {
            return;
        }
        $errors = array();
        global $woocommerce_auctions;
		if ( isset($_GET['action'])&&$_GET['action'] == 'delete_list') {
			$my_post = array('ID' =>base64_decode($_GET['product_id']),'post_status'   => 'private',);
			wp_update_post( $my_post );
			wp_redirect(dokan_get_navigation_url( 'auction' ));
		}
		
        if ( isset($_GET['action'])&&$_GET['action'] == 'relist') {
            if ( ! current_user_can( 'dokan_add_auction_product' ) ) {
                return;
            }
			
            $product_id = trim( $_GET['product_id'] );
			global $wpdb,$monday,$thursday,$flash_cycle_start,$flash_cycle_end;
			$bid_count = $wpdb->get_var($wpdb->prepare("SELECT count(id) as count FROM wp_simple_auction_log WHERE auction_id = %d LIMIT 1",$product_id));
			$_auction_dates_to = get_post_meta($product_id, '_auction_dates_to', true );
			if(strtotime($_auction_dates_to) < strtotime(date('Y-m-d H:i')) && $bid_count == 0){
				$timezone = getTimeZone_Custom();
				date_default_timezone_set($timezone);
				$today_date_time = date('Y-m-d H:i');
				$this_monday = date("Y-m-d",strtotime("monday this week"))." 09:30";
				if ($today_date_time < $this_monday) {
					$monday = $this_monday;
				}
				update_post_meta( $product_id, '_auction_dates_from', $monday );
				update_post_meta( $product_id, '_auction_dates_to', $thursday );
				update_post_meta( $product_id, '_flash_cycle_start', $flash_cycle_start );
				update_post_meta( $product_id, '_flash_cycle_end', $flash_cycle_end );
				delete_post_meta($product_id, '_auction_fail_email_sent', 1);
				delete_post_meta($product_id, '_auction_finished_email_sent', 1);
				delete_post_meta($product_id, '_auction_fail_reason', 1);
				delete_post_meta($product_id, '_auction_closed', 1);
				update_post_meta( $product_id, '_auction_relist_expire','no');
				update_post_meta( $product_id, '_flash_status','no');
				update_post_meta( $product_id, '_auction_has_started',0);
				
				$my_post = array('ID'           => $product_id,'post_status'   => 'pending',);
							 
				// Update the post into the database
				  wp_update_post( $my_post );
				if(isset($_GET['mode'])&&$_GET['mode'] == 'discount'){
					pay_for_auction($product_id,'discount');
				}else{
					pay_for_auction($product_id,'normal');
				}
			}else{
				wp_redirect(add_query_arg( array('product_id' =>$product_id, 'action' => 'relist_error' ), dokan_get_navigation_url( 'auction' ) ) );
                return;
				//$errors[] = __( 'You can not relist this auction.', 'dokan-auction' );
				//$errors = apply_filters( 'dokan_add_auction_product', $errors );
			}
            
        }
		if ( isset($_POST['action'])&&$_POST['action'] == 'update_price') {
			if ( ! current_user_can( 'dokan_add_auction_product' ) ) {
                return;
            }
			
            $product_id = trim( $_POST['product_id'] );
			$_auction_start_price = get_post_meta( $product_id, '_auction_start_price',TRUE);
			if($_POST['_new_price'] < $_auction_start_price){
				wp_redirect(add_query_arg( array('product_id' =>$product_id, 'action' => 'update_error' ), dokan_get_navigation_url( 'auction' ) ) );
            	return;
			}
			global $wpdb;
			global $today_date_time;
			$_flash_cycle_start = get_post_meta( $product_id , '_flash_cycle_start' , TRUE);
			$_flash_cycle_end = get_post_meta( $product_id , '_flash_cycle_end' , TRUE);
			
			update_post_meta( $product_id, '_auction_start_price', $_POST['_new_price']);
			update_post_meta( $product_id, '_auction_dates_from', $_flash_cycle_start);
			update_post_meta( $product_id, '_auction_dates_to', $_flash_cycle_end);
			update_post_meta( $product_id, '_flash_status','yes');
			delete_post_meta($product_id, '_auction_fail_email_sent', 1);
			delete_post_meta($product_id, '_auction_finished_email_sent', 1);
			delete_post_meta($product_id, '_auction_fail_reason', 1);
			delete_post_meta($product_id, '_auction_closed', 1);
			wp_redirect(add_query_arg( array('product_id' =>$product_id, 'action' => 'update_success' ), dokan_get_navigation_url( 'auction' ) ) );
            return;
		}
}
//add_action( 'woocommerce_simple_auctions_before_place_bid', 'play_sound' );
//add_filter('woocommerce_simple_auctions_placed_bid_message', 'play_sound',10,2 );
function play_sound($message,$product_id){
	echo $message;
	if(strpos($message,"placed bid for") > 0){
		$attr = array(
					'src'      => home_url('/applause-4.mp3'),
					'loop'     => '',
					'autoplay' => 'yes',
					'preload'  => 'none'
				);
		$message .= wp_audio_shortcode( $attr );
		
	}
	return $message;
}
add_action( 'woocommerce_before_single_product', 'play_sound2', 1 );
function play_sound2($product_id){
	global $product, $post,$today_date_time;
	$product_id = $post->ID;
	//
	$today = date("Y-m-d G:i",strtotime($today_date_time));
	//echo date("Y-m-d G:i",strtotime($today_date_time)).'=='.$product->get_auction_end_time();
	$_auction_current_bid = get_post_meta($product_id, '_auction_current_bid', true );
	$_auction_closed = get_post_meta($product_id, '_auction_closed', true );
	if (($product->get_auction_closed() == '2' && !$product->get_auction_payed())){
		$attr = array(
					'src'      => home_url('wp-content/uploads/sounds/auction_sucess.mp3'),
					'loop'     => '0',
					'autoplay' => 'yes',
					'preload'  => 'none',
					'class' => 'hide'
				);
		if(strtotime($today)==strtotime($product->get_auction_end_time())){
				echo '<audio id="myAudio" controls="false" volume=".2" style="display:none;"></audio>';
				echo wp_audio_shortcode( $attr );
		}
	}else{
		if(!$_auction_current_bid && $_auction_closed==1){
			$attr = array(
					'src'      => home_url('wp-content/uploads/sounds/auction_failure.mp3'),
					'loop'     => '0',
					'autoplay' => 'yes',
					'preload'  => 'none',
					'class' => 'hide'
				);
				if(strtotime($today)==strtotime($product->get_auction_end_time())){
					echo '<audio id="myAudio" controls="false" volume=".2" style="display:none;"></audio>';
					echo wp_audio_shortcode( $attr );
				}
		}else{
			$product = get_product($product_id);
			$auctionend = new DateTime($product->get_auction_dates_to());
			$auctionendformat = $auctionend->format('Y-m-d H:i:s');
			$time = current_time( 'timestamp' );
			$timeplus5 = date('Y-m-d H:i:s', strtotime('+5 minutes', $time));
			/*/
			if ($timeplus5 > $auctionendformat) {
				echo '<script type="text/javascript">jQuery( document ).ready(function() { playAudioLoop("'.home_url('wp-content/uploads/sounds/087168277-helicopter-sound-effect.mp3').'"); });</script><input type="hidden" id="play_snipping" value="yes" />';
			}else{
			
			}
			*/
		/*$attr = array(
					'src'      => home_url('wp-content/uploads/sounds/033581166-energetic-auctioneer-cattle-li.mp3'),
					'loop'     => 'yes',
					'autoplay' => 'yes',
					'preload'  => 'none',
					'class' => 'hide'
				);*/
		}
	}
		
		
		//echo do_shortcode('[audio src="'.home_url('/roller.mp3').'" autoplay="true"]');
		//echo do_shortcode('[sc_embed_player_template1 autoplay=true loops="true" volume="100" fileurl="'.home_url('wp-content/uploads/sounds/087168277-helicopter-sound-effect.mp3').'"]');
		
	//return $message;
}
add_filter( 'wp_audio_shortcode', 'filter_function_name_4420', 10, 5 );
function filter_function_name_4420( $html, $atts, $audio, $post_id, $library ){
	// filter...
	$html = str_replace("<audio",'<audio controlsList="nodownload" ',$html);
	return $html;
}
function dokan_header_user_menu_custom() {
	$cart_total = WC()->cart->total;
    ?>
    
    <ul class="nav navbar-nav navbar-right">
        <?php if($cart_total > 0 && 1==2){?>
        <li>
          
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php printf( __( 'Cart %s', 'dokan-theme' ), '<span class="dokan-cart-amount-top">(' . WC()->cart->get_cart_total() . ')</span>' ); ?> <b class="caret"></b></a>

            <ul class="dropdown-menu">
                <li>
                    <div class="widget_shopping_cart_content"></div>
                </li>
            </ul>
        </li>
		<?php }?>
        <?php if ( is_user_logged_in() ) { ?>

            <?php
            global $current_user;
            
            
            $is_seller = false;
            
            $user_id = $current_user->ID;
            if(  function_exists( 'dokan_is_user_seller' )){
                $is_seller = dokan_is_user_seller( $user_id );
            }
			
			if($is_seller){
				$display_name = 'hello! '.esc_html( $current_user->first_name);
			}else{
				$display_name = 'hello! '.esc_html( $current_user->first_name);
				$designation = get_user_meta( $user_id, 'designation', true );
				if($designation!=""){
					//$display_name .=', '.$designation;
				}
			}
            if ( $is_seller && 1==2) {
                ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php _e( 'Client Dashboard', 'dokan-theme' ); ?> <b class="caret"></b></a>

                    <ul class="dropdown-menu">
                      <!--  <li><a href="<?php echo dokan_get_store_url( $user_id ); ?>" target="_blank"><?php _e( 'Visit your store', 'dokan-theme' ); ?> <i class="fa fa-external-link"></i></a></li>
                        <li class="divider"></li>-->
                        <?php
                        $nav_urls = dokan_get_dashboard_nav();

                        foreach ($nav_urls as $key => $item) {
                            printf( '<li><a href="%s">%s &nbsp;%s</a></li>', $item['url'], $item['icon'], $item['title'] );
                        }
                        ?>
                    </ul>
                </li>
            <?php } ?>

            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $display_name;?> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <!--<li><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><?php _e( 'My Account', 'dokan-theme' ); ?></a></li>
-->
					<?php if($is_seller){?>
                    <li><a href="<?php echo dokan_get_navigation_url('auction'); ?>"><?php _e( 'ShopADoc® Auction Activity', 'dokan-theme' ); ?></a></li>
                    <li><a href="<?php echo dokan_get_navigation_url( 'new-auction-product' ); ?>"><?php _e( 'List My Service', 'dokan-theme' ); ?></a></li>
                    <li><a href="<?php echo wc_customer_edit_account_url(); ?>"><?php _e( 'Edit Contact Info', 'dokan-theme' ); ?></a></li>	
					<?php }else{?>
					<li><a href="<?php echo site_url(); ?>/shopadoc-auction-activity/ "><?php _e( 'ShopADoc® Auction Activity', 'dokan-theme' ); ?></a></li>
<!--                    <li><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>/my-auctions/"><?php _e( 'ShopADoc® Auction History', 'dokan-theme' ); ?></a></li>
-->					<li><a href="#" class="bid_on" onclick="jQuery('.dropdown').removeClass('open');"><?php _e( 'Auction Participation Options', 'dokan-theme' ); ?></a></li>
                    <li><a href="<?php echo wc_customer_edit_account_url(); ?>"><?php _e( 'Edit Registration Info', 'dokan-theme' ); ?></a></li>	
                    <!--<li><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' )); ?>"><?php _e( 'Change Payment Plan', 'dokan-theme' ); ?></a></li>-->
                    <li><a href="<?php echo wc_get_endpoint_url( 'payment-methods','', get_permalink( wc_get_page_id( 'myaccount' ) ) ); ?>"><?php _e( 'Update Card on File', 'dokan-theme' ); ?></a></li>	
                    <?php }?>
                    <!--<li class="divider"></li>
                    <li><a href="<?php echo wc_get_endpoint_url( 'edit-address', 'billing', get_permalink( wc_get_page_id( 'myaccount' ) ) ); ?>"><?php _e( 'Billing Address', 'dokan-theme' ); ?></a></li>
                    <li><a href="<?php echo wc_get_endpoint_url( 'edit-address', 'shipping', get_permalink( wc_get_page_id( 'myaccount' ) ) ); ?>"><?php _e( 'Shipping Address', 'dokan-theme' ); ?></a></li>-->
                </ul>
            </li>

            <li><a href="<?php echo home_url('/?customer-logout=true'); ?>"><?php _e( 'Log out', 'dokan-theme' ); ?></a><?php //wp_loginout( home_url('/my-account/?customer-logout=true') ); ?></li>

        <?php } else { ?>
            <li><a href="<?php echo get_permalink( wc_get_page_id( 'myaccount' ) ); ?>"><?php _e( 'Auction Sign-in', 'dokan-theme' ); ?></a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle sg-popup-id-675" data-toggle="dropdown"><?php _e( 'Register', 'dokan-theme' ); ?> <!--<b class="caret"></b>--></a>
               <!-- <ul class="dropdown-menu">
                    <li><a href="<?php echo get_permalink(91); ?>"><?php _e( 'New Client', 'dokan-theme' ); ?></a></li>
                    <li><a href="<?php echo get_permalink(99); ?>"><?php _e( 'New Dentist', 'dokan-theme' ); ?></a></li>
                    </ul>-->
            </li>
        <?php } ?>
    </ul>
    <?php
}
add_action('wp_logout','ps_redirect_after_logout');
function ps_redirect_after_logout(){
         wp_redirect(home_url('/'));
         exit();
}
add_filter( 'login_url', 'my_login_page', 10, 3 );
function my_login_page( $login_url, $redirect, $force_reauth ) {
	$redirect_text = '';
	if($redirect !=""){
		$redirect_text = '?redirect_to='.$redirect;
	}
    return home_url( '/my-account/'.$redirect_text);
}
add_action('wp_trash_post', 'restric_from_trash',10,1);
function restric_from_trash($id){
	if($id==126 || $id==942 || $id==948 || $id==1141 || $id==1642){
		wp_redirect( admin_url( 'edit.php?post_type=product' ) );
		exit;
	}
}


add_filter( 'dokan_get_dashboard_nav', 'dokan_add_help_menu');
function dokan_add_help_menu( $urls ) {
	unset($urls['dashboard']);
    /*$urls['help'] = array(
        'title' => __( 'Help', 'dokan'),
        'icon'  => '<i class="fa fa-user"></i>',
        'url'   => dokan_get_navigation_url( 'help' ),
        'pos'   => 51
    );*/
    return $urls;
}
/*add_filter( 'dokan_query_var_filter', 'dokan_load_document_menu' );
function dokan_load_document_menu( $query_vars ) {
    $query_vars['help'] = 'help';
    return $query_vars;
}
add_action( 'dokan_load_custom_template', 'dokan_load_template' );
function dokan_load_template( $query_vars ) {
    if ( isset( $query_vars['help'] ) ) {
        require_once dirname( __FILE__ ). '/help.php';
        exit();
    }
}*/

add_filter('woocommerce_checkout_get_value', function($input, $key ) {
    global $current_user,$US_state;
	$user_id = $current_user->ID;	
	$user = wp_get_current_user();
	if($user->roles[0]=='seller'){
		$user_id = dokan_get_current_user_id();
		$client_street = get_user_meta( $user_id, 'client_street', true);
		$client_apt_no = get_user_meta( $user_id, 'client_apt_no', true);
		$client_city = get_user_meta( $user_id, 'client_city', true);
		$client_state = get_user_meta( $user_id, 'client_state', true);
		$client_zip_code = get_user_meta( $user_id, 'client_zip_code', true);
		$client_cell_ph = get_user_meta( $user_id, 'client_cell_ph', true );
		$client_state = $US_state[$client_state];
	}else{
		$user_id = dokan_get_current_user_id();
		$client_street = get_user_meta( $user_id, 'dentist_office_street', true);
		$client_apt_no = get_user_meta( $user_id, 'dentist_office_apt_no', true);
		$client_city = get_user_meta( $user_id, 'dentist_office_city', true);
		$client_state = get_user_meta( $user_id, 'dentist_office_state', true);
		$client_zip_code = get_user_meta( $user_id, 'dentist_office_zip_code', true);
		$client_cell_ph = get_user_meta( $user_id, 'dentist_personal_cell', true );
		$client_state = $US_state[$client_state];
	}
	/*$client_street = get_user_meta( $user_id, 'client_street', true );
	$client_apt_no = get_user_meta( $user_id, 'client_apt_no', true );
	$client_city = get_user_meta( $user_id, 'client_city', true );
	$client_state = get_user_meta( $user_id, 'client_state', true );
	$client_zip_code = get_user_meta( $user_id, 'client_zip_code', true );
	$client_cell_ph = get_user_meta( $user_id, 'client_cell_ph', true );
	$client_home_ph = get_user_meta( $user_id, 'client_home_ph', true );
	$client_state = $US_state[$client_state];*/
    switch ($key) :
	    case 'billing_first_name':
        case 'shipping_first_name':
            return $current_user->first_name;
        break;

        case 'billing_last_name':
        case 'shipping_last_name':
            return $current_user->last_name;
        break;
		case 'billing_address_1':
            return $client_street;
        break;
		case 'billing_address_2':
            return $client_apt_no;
        break;
		case 'billing_city':
            return $client_city;
        break;
		case 'billing_state':
            return $client_state;
        break;
		case 'billing_postcode':
            return $client_zip_code;
        break;
        case 'billing_email':
            return $current_user->user_email;
        break;
        case 'billing_phone':
            return $client_cell_ph;
        break;
    endswitch;
}, 10, 2);

add_filter( 'dokan_register_scripts', 'dokan_register_scripts_custom');
function dokan_register_scripts_custom() {
	wp_deregister_script( 'dokan-script' );
	$scripts = array('dokan-script' => array(
                'src'       => get_template_directory_uri(). '-child/dokan/dokan.js',
                'deps'      => array( 'imgareaselect', 'customize-base', 'customize-model', 'dokan-i18n-jed' ),
                //'version'   => get_template_directory_uri() . '-child/dokan/dokan.js',
            ));
	foreach ( $scripts as $handle => $script ) {
            $deps      = isset( $script['deps'] ) ? $script['deps'] : false;
            $in_footer = isset( $script['in_footer'] ) ? $script['in_footer'] : true;
            $version   = isset( $script['version'] ) ? $script['version'] : DOKAN_PLUGIN_VERSION;

            wp_register_script( $handle, $script['src'], $deps, $version, $in_footer );
        }		
}
// Removes Order Notes Title - Additional Information & Notes Field
add_filter( 'woocommerce_enable_order_notes_field', '__return_false', 9999 );
// Remove Order Notes Field
add_filter( 'woocommerce_checkout_fields' , 'remove_order_notes' );
function remove_order_notes( $fields ) {
     unset($fields['order']['order_comments']);
     return $fields;
}
add_action( 'init', function() {

	add_shortcode( 'site_url', function( $atts = null, $content = null ) {
		return home_url("/");
	} );

} );

function my_test_shortcode(){
	$year = date('Y');
	echo $year;
}
add_shortcode('my-test', 'my_test_shortcode');
//remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
//add_action( 'woocommerce_review_order_before_payment', 'woocommerce_checkout_coupon_form' );
//add_action( 'advanced-ads-can-display', 'advads_show_ads_on_posts_only',10,2);
function advads_show_ads_on_posts_only($can_display, $ad){
    global $post;
	$ad_id = $ad->id;
	$ad_location = get_post_meta($ad_id, 'ad_location',true);
	$dentist_office_address = getDentistAddress();
	if(trim($dentist_office_address) !="" && trim($ad_location) !=""){
		$Distance = get_driving_information($dentist_office_address,$ad_location);
		if($Distance > 50){
			return false;
		}
	}
    //if( ! isset( $post->post_type ) || 'post' !== $post->post_type ){
 		//return false;
    //}
    return $can_display;
}
function theme_slug_filter_the_content( $content ) {
	//8,46,48,91,99
	global $wp;
	$pageIDS = array(8,48,91,99);
	$current_url =  home_url( $wp->request );
	if(strpos($current_url,"my-account/edit-account") > 0){
		 /*$content .= '<style type="text/css">#post-46 .entry-content .woocommerce-MyAccount-content{
	background: url('.home_url().'/wp-content/themes/dokan-child/watermark.png) no-repeat;
	background-size: cover;
	min-height:1000px;
}</style>';*/
	}
	if(in_array(get_the_ID(),$pageIDS) || strpos($current_url,"my-account/edit-account") > 0){
    $custom_content = '<div class="watermark"><img src="'.get_site_url().'/wp-content/themes/dokan-child/watermark-100.png" width="68" title="watermark" alt="watermark" /></div>';
    $custom_content .= $content;
    return $custom_content;
	}else{
		return $content;
	}
}
add_filter( 'the_content', 'theme_slug_filter_the_content' );

add_filter( 'default_checkout_billing_country', 'change_default_checkout_country' );
function change_default_checkout_country() {
  return 'US'; // country code
}
/* Auto Extend Auction by 2 min when a bid is placed within the last 5mins */
add_action( 'woocommerce_simple_auctions_outbid', 'woocommerce_simple_auctions_extend_time', 50 );
function woocommerce_simple_auctions_extend_time($data) {
    $product = get_product( $data['product_id'] );
    if ('auction' === $product->get_type() ) {
        $auctionend = new DateTime($product->get_auction_dates_to());
        $auctionendformat = $auctionend->format('Y-m-d H:i:s');
        $time = current_time( 'timestamp' );
        $timeplus5 = date('Y-m-d H:i:s', strtotime('+5 minutes', $time));
 
        if ($timeplus5 > $auctionendformat) {
            $auctionend->add(new DateInterval('PT300S'));
            update_post_meta( $data['product_id'], '_auction_dates_to', $auctionend->format('Y-m-d H:i:s') );
			update_post_meta( $data['product_id'], '_auction_dates_extend', 'yes' );
        }
    }
}
add_action('woocommerce_thankyou', 'enroll_student', 10, 1);
function enroll_student( $order_id ) {

    if ( ! $order_id )
        return;

    // Getting an instance of the order object
    $order = wc_get_order( $order_id );

    // iterating through each order items (getting product ID and the product object) 
    // (work for simple and variable products)
    foreach ( $order->get_items() as $item_id => $item ) {
		//print_r($item->get_meta_data( __( 'Auction ID', 'iconic' )));
		$auction_id = wc_get_order_item_meta( $item_id,  'Auction ID', true );
        if( $item['variation_id'] > 0 ){
            $product_id = $item['variation_id']; // variable product
        } else {
            $product_id = $item['product_id']; // simple product
        }
		//$auction_id = $item['auction_id'];
        // Get the product object
        //$product = wc_get_product( $product_id );

    }
	if($product_id==942 || $product_id==948){
		
		echo '<p style="width:100%;float:left;">';
		if($auction_id){
			echo '<a href="'.get_permalink( $auction_id ).'" class="bid_button button alt" >Return to Auction Listing</a>&nbsp;';
		}
    	echo '<a href="'.site_url().'/shopadoc-auction-activity/" class="bid_button button alt" >Proceed to Auctions</a>';
	}
	$user = wp_get_current_user();
	if($user->roles[0]=='seller'){
		echo '<a href="'.get_permalink( $auction_id ).'" style="padding:15px 30px;font-weight:bold;" class="bid_button button alt" >Proceed to Auction</a><!--&nbsp;<a href="'.dokan_get_navigation_url('auction').'" class="bid_button button alt" >Auction Activity</a>-->';
	}
	echo "</p>";
}
function ea_wpforms_description_above_field( $properties ) {
	if(in_array("wpforms-field-text",$properties['container']['class'])){
		$properties['description']['position'] = 'before';
	}
	return $properties;
}

if(isset($_REQUEST['mode'])&& ($_REQUEST['mode'] =='reactive' || $_REQUEST['mode'] =='register')){
	add_filter( 'woocommerce_checkout_fields' , 'bbloomer_add_field_and_reorder_fields' );
	function bbloomer_add_field_and_reorder_fields( $fields ) {
		$fields['billing']['page_mode'] = array(
		'default'=>$_GET['mode'],
		'priority' => 51,
		'class'     => array('hide'),
		 );
		return $fields;
	}
}
//add_filter('the_title','some_callback');
function some_callback($title){
    global $post,$wp;
	$types = array('post', 'page');
	if (in_array($post->post_type,$types)){
		if($post->ID == 46 /*&& $title =='Registration Info'*/){
			$current_url =  home_url( $wp->request );
			if(strpos($current_url,"my-account/edit-account") > 0){
				$user = wp_get_current_user();
				if($user->roles[0]=='seller'){
					$title = "Edit Client Contact";
				}else{
					$title = "Edit Registration Info";
				}
			}elseif(strpos($current_url,"my-account/my-auctions") > 0){
				$title = "ShopADoc® Auction History";
			}elseif(strpos($current_url,"my-account/payment-methods") > 0){
				$title = "Update Card on File";
			}elseif(strpos($current_url,"my-account/add-payment-method") > 0){
				$title = "Add Credit/Debit Card Info";
			}else{
				$title = "Change Payment Plan";
			}
			
		}
	}
	return $title;
}
global $title_right;
$title_right ="<span class='right-align-txt'>ShopADoc<span class='TM_title'>®</span></span>";
function wpse309151_title_update( $title, $id = null ) {
	global $post,$wp,$title_right;
    if ( ! is_admin() && ! is_null( $id ) ) {
        $post = get_post( $id );
		$current_url =  home_url( $wp->request );
        if ( $post instanceof WP_Post && ( $post->post_type == 'post' || $post->post_type == 'page' ) ) {
			if($post->ID == 48 || $post->ID == 54 || $post->ID == 56 || $post->ID == 60 || $post->ID == 62 || $post->ID == 66 || $post->ID == 68 || $post->ID == 91|| $post->ID == 99 || $post->ID == 1735 || $post->ID == 1325){
				$title = $post->post_title.$title_right;
				
			}
            if($post->ID == 46 /*&& $title =='Registration Info'*/){
			
			if(strpos($current_url,"my-account/edit-account") > 0){
				$user = wp_get_current_user();
				if($user->roles[0]=='seller'){
					$title = "Edit Client Contact";
				}else{
					$title = "Edit Registration Info";
				}
			}elseif(strpos($current_url,"my-account/my-auctions") > 0){
				$title = "ShopADoc® Auction History";
			}elseif(strpos($current_url,"my-account/my-auctions") > 0){
				$title = "ShopADoc® Auction History";
			}elseif(strpos($current_url,"my-account/payment-methods") > 0){
				$title = "Update Card on File";
			}elseif(strpos($current_url,"my-account/add-payment-method") > 0){
				$title = "Add Credit/Debit Card Info";
			}else{
				$title = "Change Payment Plan";
			}
			if (!is_user_logged_in()){
				$title = "Sign-in".$title_right;
			}
			}
			$title = $post->post_title.$title_right;
			if(strpos($current_url,"checkout/order-received") > 0){
				$order_id = str_replace('checkout/order-received/','',$wp->request);
				$title ="ShopADoc<span class='TM_title'>®</span>&nbsp;&nbsp;Auction Participation Receipt";
			}
        }
    }
    return $title;
}
add_filter( 'the_title', 'wpse309151_title_update', 10, 2 );

function wpse309151_remove_title_filter_nav_menu( $nav_menu, $args ) {
    // we are working with menu, so remove the title filter
    remove_filter( 'the_title', 'wpse309151_title_update', 10, 2 );
    return $nav_menu;
}
// this filter fires just before the nav menu item creation process
add_filter( 'pre_wp_nav_menu', 'wpse309151_remove_title_filter_nav_menu', 10, 2 );

function wpse309151_add_title_filter_non_menu( $items, $args ) {
    // we are done working with menu, so add the title filter back
    add_filter( 'the_title', 'wpse309151_title_update', 10, 2 );
    return $items;
}
// this filter fires after nav menu item creation is done
add_filter( 'wp_nav_menu_items', 'wpse309151_add_title_filter_non_menu', 10, 2 );

add_action( 'woocommerce_review_order_before_submit', 'bbloomer_add_checkout_per_product_terms', 9 );
   
function bbloomer_add_checkout_per_product_terms() {
 
//Single auction condition
$product_id_1 = 942;
$quantity = 0;
foreach(WC()->cart->get_cart() as $key => $val ) {
	$_product = $val['data'];
	if($product_id_1 == $_product->get_id()) {
		$quantity = $val['quantity'];
	}
}
//Monthly Auction Condition
$product_id_2 = 948;
$quantity_2 = 0;
foreach(WC()->cart->get_cart() as $key => $val ) {
	$_product = $val['data'];
	if($product_id_2 == $_product->get_id()) {
		$quantity_2 = $val['quantity'];
	}
}
//Registerration fee condition
$product_id_3 = 1141;
$quantity_3 = 0;
foreach(WC()->cart->get_cart() as $key => $val ) {
	$_product = $val['data'];
	if($product_id_3 == $_product->get_id()) {
		$quantity_3 = $val['quantity'];
	}
}
	
//$product_cart_id_1 = WC()->cart->generate_cart_id( $product_id_1 );
//$in_cart_1 = WC()->cart->find_product_in_cart($product_cart_id_1);
if($quantity > 0){    
?>
    <p class="form-row terms wc-terms-and-conditions">
    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox container_my">
    <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms-new" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms-new'] ) ), true ); ?> id="terms-new"> <span class="checkmark_my"></span><span>I authorize the above amount be charged to the card listed below for payment of the ShopADoc® Auction Participation Fee.</span> <span class="required">*</span>
    </label>
    <input type="hidden" name="terms-new-field" value="true">
    <?php 
		$term_text = 'I authorize the above amount be charged to the card listed below for payment of the ShopADoc® Auction Participation Fee.';
	?>
    </p>
<?php }elseif($quantity_2 > 0){?>
<p class="form-row terms wc-terms-and-conditions">
    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox container_my">
    <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms-new" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms-new'] ) ), true ); ?> id="terms-new"> <span class="checkmark_my"></span><span>I authorize the above amount be charged to the card listed below as a recurring charge every 4 weeks for the payment of the ShopADoc® Auction Participation Fee. I may deactivate this subscription payment method at anytime with 4 weeks notice.</span> <span class="required"> *</span>
    </label>
    <input type="hidden" name="terms-new-field" value="true">
    <?php 
		$term_text = 'I authorize the above amount be charged to the card listed below as a recurring charge every 4 weeks for the payment of the ShopADoc® Auction Participation Fee. I may deactivate this subscription payment method at anytime with 4 weeks notice.';
	?>
    </p>
<?php }elseif($quantity_3 > 0){?>
<p class="form-row terms wc-terms-and-conditions">
    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox container_my">
    <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms-new" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms-new'] ) ), true ); ?> id="terms-new"> <span class="checkmark_my"></span><span>I authorize ShopADoc The Dentist Marketplace Inc. to charge my credit/debit card, listed below, an annual registration fee in the amount of $99.99.<br />
The annual registration fee will be a recurring charge to this credit/debit card on your anniversary date of registration.<br /><br /> Under penalty of law, I certify I hold an active unrestricted license to practice dentistry and I am without pending investigation for disciplinary/ administrative action(s) against me. Should my status change, I agree to notify ShopADoc The Dentist Marketplace Inc. immediately by email to <a href="<?php echo home_url('/contact/'); ?>" title="Contact" target="_blank">ShopADoc1@gmail.com</a> and refrain from further participation on this site until reinstatement by the State Board of Dentistry. I have read and accept the <a href="<?php echo home_url('/user-agreement/'); ?>" title="User Agreement" target="_blank">User Agreement</a>, <a href="<?php echo home_url('/privacy-policy/'); ?>" title="Privacy Policy" target="_blank">Privacy Policy</a>, and <a href="<?php echo home_url('/house-rules/'); ?>" title="House Rules" target="_blank">House Rules</a>.</span> <span class="required">*</span>
    </label>
    <input type="hidden" name="terms-new-field" value="true">
    <?php 
		$term_text = 'I authorize ShopADoc The Dentist Marketplace Inc. to charge my credit/debit card, listed below, an annual registration fee in the amount of $99.99.<br />
The annual registration fee will be a recurring charge to this credit/debit card on your anniversary date of registration.<br /><br /> Under penalty of law, I certify I hold an active unrestricted license to practice dentistry and I am without pending investigation for disciplinary/ administrative action(s) against me. Should my status change, I agree to notify ShopADoc The Dentist Marketplace Inc. immediately by email to ShopADoc1@gmail.com and refrain from further participation on this site until reinstatement by the State Board of Dentistry. I have read and accept the User Agreement, Privacy Policy, and House Rules.';
	?>
    </p>
<?php }else{?>
<p class="form-row terms wc-terms-and-conditions">
    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox container_my">
    <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms-new" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms-new'] ) ), true ); ?> id="terms-new"> <span class="checkmark_my"></span><span>ShopADoc® may contact me as needed. I permit ShopADoc® to provide my contact information to the Dentist following a successful auction pairing for appointment scheduling. I have read and accept the <a href="<?php echo home_url('/user-agreement/'); ?>" title="User Agreement" target="_blank">User Agreement</a>, <a href="<?php echo home_url('/privacy-policy/'); ?>" title="Privacy Policy" target="_blank">Privacy Policy</a>, and <a href="<?php echo home_url('/house-rules/'); ?>" title="House Rules" target="_blank">House Rules</a>. I certify the x-ray(s) I am uploading have been taken within 30 days of the auction. I authorize the above amount be charged to the card listed below for payment of the ShopADoc® auction fee.</span> <span class="required">*</span>
    </label>
    <input type="hidden" name="terms-new-field" value="true">
    <?php 
		$term_text = 'ShopADoc® may contact me as needed. I permit ShopADoc® to provide my contact information to the Dentist following a successful auction pairing for appointment scheduling. I have read and accept the User Agreement, Privacy Policy, and House Rules. I certify the x-ray(s) I am uploading have been taken within 30 days of the auction. I authorize the above amount be charged to the card listed below for payment of the ShopADoc® auction fee.';
	?>
    </p>
<?php }?>
 <input type="hidden" name="_order_terms_text" value="<?php echo $term_text;?>">
<?php
// Show Terms 2
/*
$product_id_2 = 2152;
$product_cart_id_2 = WC()->cart->generate_cart_id( $product_id_2 );
$in_cart_2 = WC()->cart->find_product_in_cart( $product_cart_id_2 ); 
if ( $in_cart_2 ) {		  
	?>
        <p class="form-row terms wc-terms-and-conditions">
        <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
        <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms-2" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms-2'] ) ), true ); ?> id="terms-2"> <span>I authorize ShopADoc The Dentist Marketplace charge my credit/debit card listed below<br />
The amount of $12.99 for auction participation. I accept the User Agreement, Privacy Policy, and House Rules.</span> <span class="required">*</span>
        </label>
        <input type="hidden" name="terms-2-field" value="true">
        </p>
	<?php
	}
	*/
}
// Show notice if customer does not tick either terms
add_action( 'woocommerce_checkout_process', 'bbloomer_not_approved_terms_1' );
function bbloomer_not_approved_terms_1() {
    if ( $_POST['terms-new-field'] == true ) {
      if ( empty( $_POST['terms-new'] ) ) {
           wc_add_notice( __( 'Please read and accept the terms and conditions to proceed with your order.' ), 'error' );         
      }
   }
}
add_action('woocommerce_checkout_update_order_meta', 'custom_checkout_field_update_order_meta',20,1);
function custom_checkout_field_update_order_meta($order_id){
	if (!empty($_POST['_order_terms_text'])) {
		update_post_meta($order_id, '_order_terms_text',sanitize_text_field($_POST['_order_terms_text']));
	}
}
/*
add_action( 'woocommerce_checkout_process', 'bbloomer_not_approved_terms_2' ); 
function bbloomer_not_approved_terms_2() {
   if ( $_POST['terms-2-field'] == true ) {
      if ( empty( $_POST['terms-2'] ) ) {
         wc_add_notice( __( 'Please agree to terms-2' ), 'error' );         
      }
   }
}
*/
add_action( 'woocommerce_after_single_product_summary', 'custom_single_product_banner', 12 );
function custom_single_product_banner() {
	/*$output = '';
	if(is_user_logged_in()){
		$user = wp_get_current_user();
		$output = '<link rel="stylesheet"  href="'.home_url('/wp-content/themes/dokan-child/slider/css/lightslider.css').'"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="'.home_url('/wp-content/themes/dokan-child/slider/js/lightslider.js').'"></script> 
		<script>
			 $(document).ready(function() {
				
			});
		</script>';
		$output ='';
		if($user->roles[0]=='seller'){
				$output .= the_ad_group(59).the_ad_group(95).the_ad_group(100).the_ad_group(101);
				//$output .= '<div class="ad-zone" id="c57b5c52aff270f681f700f516b58055e"></div><div id="ca513a235a820d3d19f372ac7d04ca19a"></div>';
			}else{
				$output .= the_ad_group(59).the_ad_group(95).the_ad_group(100).the_ad_group(101);
			}
	}
    echo $output;*/
	
}
add_action( 'init', function() {
	add_shortcode( 'ad_section', function( $atts = null, $content = null ) {
		$output = '';
		if(is_user_logged_in()){
			$user = wp_get_current_user();
			$output = '<link rel="stylesheet"  href="'.home_url('/wp-content/themes/dokan-child/slider/css/lightslider.css').'"/>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="'.home_url('/wp-content/themes/dokan-child/slider/js/lightslider.js').'"></script> 
		<script>
			 $(document).ready(function() {
				/*$("#advads-grid-59").lightSlider({
					item: 3,
					loop:true,
					keyPress:true
				});*/
				/*$("#image-gallery").lightSlider({
					gallery:true,
					item:1,
					thumbItem:9,
					slideMargin: 0,
					speed:500,
					auto:true,
					loop:true,
					onSliderLoad: function() {
						$("#image-gallery").removeClass("cS-hidden");
					}  
				});*/
			});
		</script>';
		
		$output ='';
			if($user->roles[0]=='seller'){
				//$output .= the_ad_group(107).the_ad_group(108).the_ad_group(109).the_ad_group(110);
				$output .= '<div class="ads_div"><div class="advads-main" id="c2c9ba4709f26cc69919b8fe14985a2d2"></div><div class="advads-main" id="cecf361cf5be9652ac6d85a8b942bb08d"></div><div class="advads-main" id="c2bc5e0ae81103c57086052a71f001371"></div><div class="advads-main" id="caac99a31e29aff4f5d89c961a064e962"></div></div>';
				//$output .='<div id="cb0882e7c3fe132f117a982ca25c69857" class="advads-main"></div><div id="c73fa371ccccd3dd0a80290239b30ec06" class="advads-main"></div><div id="cc939da582843a805f7c38f7d8d813526" class="advads-main"></div>';
			
			}else{
				//echo "i am here";
				$output .= '<div class="ads_div"><div class="advads-main" id="c57b5c52aff270f681f700f516b58055e"></div><div class="advads-main" id="c9eb37b12dbbbc5b3cad9932fa4c3e8b3"></div><div class="advads-main" id="c7a0c95665efa3a5a052e90fe1da5fa16"></div><div class="advads-main" id="cf977d95931f6a6aaa7a23a58ad8ae277"></div></div>';
				//$output .= the_ad_group(59).the_ad_group(95).the_ad_group(100).the_ad_group(101);
				//$output .='<div id="caf26610fcfc508aff2e6a2b125f63e86"></div>';
			}
		}
		/*$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title like '%Client%' and post_title like '%Col 1%' ORDER BY ID ASC";
		$results = $wpdb->get_results($query, OBJECT);
		$html1 = '';
		foreach($results as $row){
			if($row->ID !=""){
				$html1 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
			}
		}*/
		if($user->roles[0]=='seller'){
			$rotations_client = maybe_unserialize(get_option('rotations_client'));
		}else{
			$rotations_client = maybe_unserialize(get_option('rotations_dentist'));
		}
		$rotation_output = '<div class="rotation_main">';
		$i = 1;
		foreach($rotations_client as $rotation_str){
				if($i == 1){
					$style =' style = "display:none;"'; 
				}else{
					$style =' style = "display:none;"';
				}
				$rotation_output .= '<div class="rotation_set" id="rotation_set_'.$i.'" '.$style.'>';
				$set_ads = array();
				$ads = explode(",",$rotation_str);
				foreach($ads as $ad){
					//track_ad_custom($ad,'wp_advads_impressions');
					$advanced_ads_ad_options = maybe_unserialize(get_post_meta($ad,'advanced_ads_ad_options',TRUE));
					//print_r($advanced_ads_ad_options);
					$image_id = $advanced_ads_ad_options['output']['image_id'];
					$url = $advanced_ads_ad_options['url'];
					$width = $advanced_ads_ad_options['width'];
					$height = $advanced_ads_ad_options['height'];
					$image = wp_get_attachment_image_src($image_id, 'full' );
					if ( $image ) {
						list( $image_url, $image_width, $image_height ) = $image;
					}
					$target = '';
					if($advanced_ads_ad_options['tracking']['target']=='new'){
						$target = ' target="_new"';
					}
					//$rotation_output .= '<div class="ad" ><a href="'.home_url('/linkout/'.$ad).'">';
					$rotation_output .= '<div class="rotation_ad" ><a href="'.home_url('/linkout/'.$ad).'" '.$target.'><img src="'.$image_url.'" alt=""  width="'.$width.'" height="'.$height.'"></a></div>';
					array_push($set_ads,$ad);
				}
				$rotation_output .='<input type="hidden" id="set_ads_'.$i.'" value="'.implode(',',$set_ads).'" />';
				$rotation_output .= '</div>';
				$i++;
		}
		$rotation_output .='<script type="text/javascript">startSlide('.get_option("current_rotation").');</script>';
		$rotation_output .= '</div>';
		echo $rotation_output;
    	//echo $output;
	} );

} );
function get_timestamp_custom( $timestamp = null, $fixed = false ) {
	    if ( ! isset( $timestamp ) || empty( $timestamp ) ) {
			$timestamp = time();
	    }

	    // -TODO using bitmap would be more efficient for database
	    // .. format using 5 6bit might be most useful for fast operations
	    $ts = gmdate( 'Y-m-d H:i:s', (int) $timestamp ); // time in UTC

        $week = absint( get_date_from_gmt( $ts, 'W' ) );
        $month = absint( get_date_from_gmt( $ts, 'm' ) );

        if ( 52 <= $week && 1 == $month ) {
            /**
             *  Fix for the new year inconsistency
             */
            $ts = get_date_from_gmt( $ts, 'ym01dH' );
        } elseif ( 12 === $month && in_array( $week, array( 1, 53 ) ) ) {
            $ts = get_date_from_gmt( $ts, 'ym52dH' );
        } else {
            $ts = get_date_from_gmt( $ts, 'ymWdH' ); // ensure wp local time
        }

		if ( $fixed ) {
			$ts = substr( $ts, 0, strlen( $ts ) - 2 );
			$ts .= '06';
		}

	    return $ts;
	}
	function track_ad_custom($id, $table) {
	    global $wpdb;
	    $timestamp =get_timestamp_custom( null, true );
		//echo "INSERT INTO $table (`ad_id`, `timestamp`, `count`) VALUES ($id, $timestamp, 1) ON DUPLICATE KEY UPDATE `count` = `count`+ 1";
	    $success = $wpdb->query( "INSERT INTO $table (`ad_id`, `timestamp`, `count`) VALUES ($id, $timestamp, 1) ON DUPLICATE KEY UPDATE `count` = `count`+ 1" );
		//do_action( 'advanced-ads-tracking-after-writing-into-db', $id, $table, $timestamp, $success );
	}
function my_slider_adjustments( $settings ) {
$settings['animation'] = "'fade'"; // change animation to fade
//$settings['speed'] = "'100'";
return $settings;
}
add_filter( 'advanced-ads-slider-settings', 'my_slider_adjustments' );
function my_function( $wrapper_options, $ad ){
    $wrapper_options['class'][] = 'my-ad';
    return $wrapper_options;
}
//add_filter( 'advanced-ads-output-wrapper-options', 'my_function', 10, 2 );
function my_ad_custom( $output, $ad ){
    $output = str_replace("<a",'<a class="my-ad" ',$output);
    return $output;
}
add_filter( 'advanced-ads-output-inside-wrapper', 'my_ad_custom', 30, 2 );

add_action( 'init', function() {
	add_shortcode( 'service_list', function( $atts = null, $content = null ) {
		$categories = get_categories( array(
							'taxonomy' => 'product_cat',
							'hide_empty' => false,
							'exclude'          => '15,46,47',
							'orderby' => 'term_id',
							'order'   => 'ASC'
						));
		echo '';
		$categories =  get_categories('parent=0&exclude=15&hide_empty=0&taxonomy=product_cat&orderby=term_id&order=asc');
		$i = 0;
		list($array1, $array2) = array_chunk($categories, ceil(count($categories) / 2));
		echo '<div class="dokan-form-group dokan-auction-category"><div class="content-half-part">';
		foreach($array1 as $cat){
				$categories_level_2 =  get_categories('parent='.$cat->term_id.'&exclude=15&hide_empty=0&taxonomy=product_cat&orderby=term_order&order=asc');	?>
				<ul><strong><?php echo $cat->name;?></strong>
				<?php foreach($categories_level_2 as $cat_level_2){?>
					<li><?php echo $cat_level_2->name;?></li>
				 <?php }?>
				</ul>
		<?php }
		echo '</div><div class="content-half-part">';
		foreach($array2 as $cat){
				$categories_level_2 =  get_categories('parent='.$cat->term_id.'&exclude=15&hide_empty=0&taxonomy=product_cat&orderby=term_order&order=asc');	?>
				<ul><strong><?php echo $cat->name;?></strong>
				<?php foreach($categories_level_2 as $cat_level_2){?>
					<li><?php echo $cat_level_2->name;?></li>
				 <?php }?>
				</ul>
        <?php }
		echo "<ul class='custom_service'><li>Six Month Smiles®, Invisalign®, & NTI-TSS®  are not registered trademarks of ShopADoc, Inc.</li></ul>";
		echo '</div></div>';
	} );

} );
add_action( 'init', function() {
	add_shortcode( 'confirm_page', function( $atts = null, $content = null ) {
		

		// Load entry details.
		$entry = wpforms()->entry->get( absint( $_GET['entry_id'] ) );

		// Double check that we found a real entry.
		if ( empty( $entry ) ) {
			return;
		}

		// Get form details.
		$form_data = wpforms()->form->get(
			$entry->form_id,
			array(
				'content_only' => true,
			)
		);

		// Double check that we found a valid entry.
		if ( empty( $form_data ) ) {
			return;
		}

		?>
	<!--	<link rel="stylesheet" href="<?php echo WPFORMS_PLUGIN_URL; ?>assets/css/wpforms-preview.css" type="text/css">-->
        <style type="text/css">
			.site{text-align:left;}
			@media print {
					#not_print{
					visibility: hidden;
				  }
				  /*body * {
					visibility: hidden;
				  }
				  #section-to-print, #print * {
					visibility: visible;
				  }
				  #print{
					position: absolute;
					left: 0;
					top: 0;
				  }*/
				}
		</style>
		<script>
		jQuery(function($){
					$('body').toggleClass('compact');
				// Print page.
				$(document).on('click', '.print', function(e) {
					e.preventDefault();
					window.print();
				});
		});
		</script>
			<div class="wpforms-preview" id="print">
				<!--<h1>
					<?php /* translators: %d - entry ID. */ ?>
					<div class="buttons">
						<a href="" class="button button-primary print"><?php esc_html_e( 'Print', 'wpforms-lite' ); ?></a>
					</div>
				</h1>-->
                <?php 
					$fields = apply_filters( 'wpforms_entry_single_data', wpforms_decode( $entry->fields ), $entry, $form_data );
					//print_r($fields);
					$email =$fields[3]['value'];
					$dated =$fields[33]['value'];
					$name =$fields[1]['value'];
					$street1 =$fields[17]['value'];
					$street2 =$fields[18]['value'];
					$city =$fields[19]['value'];
					$state =$fields[20]['value'];
					$zip =$fields[22]['value'];
					$phone =$fields[15]['value'];
					$card = str_replace("Visa","",str_replace("X","",$fields[30]['value']));
				?>
                <style type="text/css">
				.woocommerce .woocommerce-customer-details :last-child, .woocommerce .woocommerce-order-details :last-child, .woocommerce .woocommerce-order-downloads :last-child{
					font-size:16px;
				}
				.woocommerce ul.order_details li{
					font-size:12px;
				}
				.entry-title{
					font-family:'Open Sans', sans-serif;
				}
				.site-footer{position:relative !important;}
				</style>
                <p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received">Thank you. Your order has processed.<!--<span class="checkout_thank">ShopADoc ®</span>--></p>
  <ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">
    <li class="woocommerce-order-overview__order order"> Order number: <strong><?php echo $_GET['entry_id'];?></strong> </li>
    <li class="woocommerce-order-overview__date date"> Date: <strong><?php echo $dated;?></strong> </li>
    <li class="woocommerce-order-overview__email email"> Email: <strong><?php echo $email;?></strong> </li>
    <li class="woocommerce-order-overview__total total"> Total: <strong><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span><?php echo $fields[29]['amount'];?></span></strong> </li>
    <li class="woocommerce-order-overview__payment-method method"> Payment method: <strong>Card ending in <?php echo $card;?></strong> </li>
  </ul>
				<section class="woocommerce-order-details">
                  <h2 class="woocommerce-order-details__title">Order details</h2>
                  <table class="woocommerce-table woocommerce-table--order-details shop_table order_details" width="100%;">
                    <thead>
                      <tr>
                        <th class="woocommerce-table__product-name product-name">Product</th>
                        <th class="woocommerce-table__product-table product-total">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr class="woocommerce-table__line-item order_item">
                        <td class="woocommerce-table__product-name product-name"> Annual Registration <strong class="product-quantity">× 1</strong>
                          </td>
                        <td class="woocommerce-table__product-total product-total"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span><?php echo $fields[29]['amount'];?></span></td>
                      </tr>
                    </tbody>
                    <!--<tfoot>
                      <tr>
                        <th scope="row">Subtotal:</th>
                        <td><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span><?php echo $fields[29]['amount'];?></span></td>
                      </tr>
                      <tr>
                        <th scope="row">Payment method:</th>
                        <td>Card ending in <?php echo $card;?></td>
                      </tr>
                      <tr>
                        <th scope="row">Total:</th>
                        <td><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span><?php echo $fields[29]['amount'];?></span></td>
                      </tr>
                    </tfoot>-->
                  </table>
                </section>
				<section class="woocommerce-customer-details">
                  <h2 class="woocommerce-column__title">Billing address</h2>
                    <address>
                    <?php echo $name;?><br />
                    <?php echo $street1." ".$street2;?><br />
                    <?php echo $city.", ".$state." ".$zip?><br />
                    <p class="woocommerce-customer-details--phone"><?php echo $phone;?></p>
                    </address>
                </section>

				<?php
				/*

				if ( empty( $fields ) ) {

					// Whoops, no fields! This shouldn't happen under normal use cases.
					echo '<p class="no-fields">' . esc_html__( 'This entry does not have any fields', 'wpforms-lite' ) . '</p>';

				} else {

					echo '<div class="fields">';
					unset($fields[4]);
					unset($fields[31]);
					// Display the fields and their values.
					foreach ( $fields as $key => $field ) {

						$field_value  = apply_filters( 'wpforms_html_field_value', wp_strip_all_tags( $field['value'] ), $field, $form_data, 'entry-single' );
						$field_class  = sanitize_html_class( 'wpforms-field-' . $field['type'] );
						$field_class .= empty( $field_value ) ? ' empty' : '';

						echo '<div class="field ' . $field_class . '">';

							echo '<p class="field-name">';
								echo ! empty( $field['name'] ) ? wp_strip_all_tags( $field['name'] ) : sprintf( esc_html__( 'Field ID #%d', 'wpforms-lite' ), absint( $field['id'] ) );
							echo '</p>';

							echo '<p class="field-value">';
								echo ! empty( $field_value ) ? nl2br( make_clickable( $field_value ) ) : esc_html__( 'Empty', 'wpforms-lite' );
							echo '</p>';

						echo '</div>';
					}

					echo '</div>';
				}
				*/
				?>
			</div>
            <span id="not_print">
            <h1>You now have access to view and bid on auctions within ShopADoc The Dentist Marketplace®.</h1>
            <h1>Best of Luck!</h1>
            <div class="wpforms-confirmation-container-full wpforms-confirmation-scroll" id="wpforms-confirmation-154">
<div class="buttons"><a href="<?php echo site_url(); ?>/shopadoc-auction-activity/ " title="View Auctions" class="button button-primary"><?php esc_html_e( 'Proceed to Auctions', 'wpforms-lite' ); ?></a></div>
<?php /*?>
<p><h3>Upcoming Auctions</h3>
<?php echo do_shortcode('[future_auctions per_page="4" columns="4" orderby="date" order="desc"]'); ?>

<p><h3>Active Auctions</h3>
<?php echo do_shortcode('[ending_soon_auctions per_page="12" columns="4" order="asc"]'); ?>
</p>
</p>
<?php */?>
</div>
</span>
<?php //echo do_shortcode('[ad_section]');?>
		<?php
		//exit();
	} );

} );
add_filter('wpforms_field_properties_text', 'wpforms_field_properties_text_custom', 10, 3 );
function wpforms_field_properties_text_custom($properties, $field, $form_data){
	$$properties_new = array();
	$properties_new['container'] = $properties['container'];
	$properties_new['label'] = $properties['label'];
	$properties_new['description'] = $properties['description'];
	$properties_new['inputs'] = $properties['inputs'];
	$properties_new['error'] = $properties['error'];
	$properties = array();
	$properties = $properties_new;
	return $properties_new;
}
add_action( 'wpforms_display_field_before','field_label_custom', 16, 2 );
function field_label_custom( $field, $form_data ) {

	$label = $field['properties']['label'];
	if(strpos($field['css'],"mytooltip") > 0){
		// If the label is empty or disabled don't proceed.
		if ( empty( $label['value'] ) || $label['disabled'] ) {
			return;
		}
	
		$required = $label['required'] ? wpforms_get_field_required_label() : '';
	
		printf( '<label %s>%s%s</label>',
			wpforms_html_attributes( $label['id'], $label['class']." customTooltip", $label['data'], $label['attr'] ),
			$label['value'],
			$required
		);
	}
}
//add_action('woocommerce_product_thumbnails','report_abuse_link',11);
function report_abuse_link(){
	echo '<div class="abuse"><a href="'.home_url('/report-abuse/').'" title="Report Abuse">Report Abuse</a></div>';
}
function isa_order_received_text( $text, $order ) {
    $new = $text /*. '<span class="checkout_thank">ShopADoc ®</span>'*/;
    return $new;
}
add_filter('woocommerce_thankyou_order_received_text', 'isa_order_received_text', 10, 2 );
/*add_filter( 'woocommerce_get_price_html', 'wpa83367_price_html', 100, 2 );
function wpa83367_price_html( $price, $product ){
	$html = '<form action="'.get_permalink().'" method="post">
    	<table width="100%" border="0" >
        	<tr><td><i class="fa fa-arrow-up" onclick="updatePrice();">&nbsp;</i></td><td><input name="update_distance" type="submit" value="Update" /></td>/tr>
        </table>
        </form>';
   return $price.$html;
}*/
add_action( 'profile_update', 'custom_profile_redirect', 12 );
function custom_profile_redirect() {
	if (defined('DOING_AJAX') && DOING_AJAX) {
	}else{
		if (!is_admin()) {
			$user = wp_get_current_user();
			my_woocommerce_save_account_details($user->ID);
			wp_redirect(home_url('/my-account/edit-account/').'?mode=update');
			exit;
		}
	}
}
function op_bypass_add_to_cart_sold_individually_found_in_cart( $found_in_cart, $product_id ) {
    if ( $found_in_cart ) {
			$product = wc_get_product( $product_id );
			/* translators: %s: product name */
			throw new Exception( );
	}
    return $found_in_cart;
}
add_filter( 'woocommerce_add_to_cart_sold_individually_found_in_cart', 'op_bypass_add_to_cart_sold_individually_found_in_cart', 10, 2 );
add_action("template_redirect", 'redirection_cart_function');
function redirection_cart_function(){
    global $woocommerce;
    if( is_cart() && WC()->cart->cart_contents_count == 0){
        wp_safe_redirect(home_url());
    }
	if( is_cart() && WC()->cart->cart_contents_count > 0){
		 //wp_safe_redirect(home_url('/checkout/'));
	}
}
function custom_shop_page_redirect() {
	global $wp;
    if( is_shop() ){
		if (is_user_logged_in()){
			$user = wp_get_current_user();
			if($user->roles[0]=='seller'){
				wp_redirect( home_url('/auction-activity/auction/') );
			}else{
				wp_redirect( home_url( '/shopadoc-auction-activity/ ' ) );
			}
		}else{
			wp_redirect( home_url( '/shopadoc-auction-activity/ ' ) );
		}
        exit();
    }
	$current_url =  home_url( $wp->request );
	if(strpos($current_url,"settings") > 0 || strpos($current_url,"settings/payment") > 0 || strpos($current_url,"withdraw") > 0 || strpos($current_url,"reports") > 0 || strpos($current_url,"orders") > 0 || strpos($current_url,"products") > 0 || strpos($current_url,"new-product") > 0 || strpos($current_url,"coupons") > 0 || strpos($current_url,"reviews") > 0 || strpos($current_url,"store") > 0){
		wp_redirect( home_url('/auction-activity/auction/') );
		exit();
	}
}
add_action( 'template_redirect', 'custom_shop_page_redirect' );
function year_shortcode(){
	$year = date('Y');
	return $year;
}
add_shortcode('year', 'year_shortcode');
add_action( 'init', function() {
	add_shortcode( 'list_ads_stats','list_ads_stats_func');
} );
function list_ads_stats_func(){
	if (!is_user_logged_in()){
		wp_redirect( home_url( '/my-account/' ) );
		exit();
	}
	global $wpdb;
	$args = array(
					'post_status'         => 'publish',
					'ignore_sticky_posts' => 1,
					'orderby'             => 'post_date',
					'post_type' =>'advanced_ads',
					'order'               => 'DESC',
					'posts_per_page'      => -1,
					'meta_query' => array(array('key' => 'ad_user',get_current_user_id(),'compare' => 'EQUAL')),
				);
				$query = new WP_Query($args );
				//echo $wpdb->last_query;
				$ads = $wpdb->get_results( "SELECT post_id as ID FROM {$wpdb->prefix}postmeta WHERE meta_key = 'ad_user' and meta_value=".get_current_user_id(), OBJECT );
				//$ads = $query->posts;?>
                <style type="text/css">
				.my-listing-custom{
					float: left;
					width: 100%;
				}
				.table > thead > tr > th {
					font-size:17px;
				}
				tbody.scroll {
					display:block;
					height:167px;
					overflow:auto;
				}
				thead, tbody tr,tfoot {
					display:table;
					width:100%;
					table-layout:fixed;
				}
				thead,tfoot {
					width: calc( 100% - 1em )
				}
				table {
					width:100%;
				}
				@media (max-width: 448px) {
					.dokan-product-listing .table > thead > tr > td, .dokan-product-listing .table > tbody > tr > td, .dokan-product-listing .table > tfoot > tr > td{
						padding:8px 2px !important;
					}
				}
			</style>
<?php
        	 $periods = array(
				'today' => __('today', 'advanced-ads-tracking'),
				'yesterday' => __('yesterday', 'advanced-ads-tracking'),
				'last7days' => __('last 7 days', 'advanced-ads-tracking'),
				'thismonth' => __('this month', 'advanced-ads-tracking'),
				'lastmonth' => __('last month', 'advanced-ads-tracking'),
				'thisyear' => __('this year', 'advanced-ads-tracking'),
				'lastyear' => __('last year', 'advanced-ads-tracking'),
				// -TODO this is not fully supported for ranges of more than ~200 points; should be reviewed before 2015-09-01
				'custom' => __('custom', 'advanced-ads-tracking'),
			);
			
		?>
        <script src='/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<table style="width: 100%;">
      	<tbody>
        <tr>
          <td align="right"><form method="get" id="period-form">
              <label>
                <?php _e( 'Period', 'advanced-ads-tracking' ); ?>
                :&nbsp;</label>
              <select id="period" name="period" class="advads-stats-period" onchange="selectDateField();">
              	<option value="">- Please Select -</option>
				<?php foreach($periods as $_period_key => $_period) : ?>
                <option value="<?php echo $_period_key; ?>" <?php if(isset($_GET['period']) && $_GET['period']==$_period_key){ echo 'selected="selected"';}else{}?> ><?php echo $_period; ?></option>
                <?php endforeach; ?>
            </select>
            <?php 	$period = $_GET['period'];
					$from='';
					$to = '';
					if($period=='custom'){
						if(isset($_GET['from'])&& $_GET['from'] !=""){
							$from = $_GET['from'];
						}
						if(isset($_GET['from'])&& $_GET['from'] !=""){
							$to = $_GET['to'];
						}
					}
			?>
             <input type="text" id="from" name="from" class="advads-stats-from advads-datepicker <?php if($period !== 'custom') echo ' hidden'; ?>" value="<?php echo $from; ?>" size="10" maxlength="10" placeholder="<?php _e( 'from', 'advanced-ads-tracking' ); ?>"/>
                        <input type="text" id="to" name="to" class="advads-stats-to<?php
                            if($period !== 'custom') echo ' hidden'; ?>" value="<?php
                            echo $to; ?>" size="10" maxlength="10" placeholder="<?php _e( 'to', 'advanced-ads-tracking' ); ?>"/>
              <input type="submit" class="button button-primary" value="<?php echo esc_attr( __( 'Load', 'advanced-ads-tracking' ) ); ?>" />
            </form></td>
        </tr>
      </tbody>
    </table>
    <script>
	 jQuery( function() {
		jQuery( "#from,#to" ).datepicker({format:"mm/dd/yyyy"});
	  } );
	  function selectDateField(){
		  	var val = jQuery('#period').val();
		  	jQuery('#from,#to').removeClass('hidden');
		  	if(val=='custom'){
				jQuery('#from,#to').removeClass('hidden');
			}else{
				jQuery('#from,#to').addClass('hidden');
				jQuery('#from,#to').val('');
			}
	  }
	</script>
<div class="dokan-dashboard-wrap nano">
  <div class="dokan-dashboard-content dokan-product-listing my-listing-custom">
    <article class="dokan-product-listing-area">
      <div class="table-wrap"> 
        <!--<table class="table table-striped product-listing-table">-->
        
        <table class="table product-listing-table">
          <thead>
            <tr>
              <th class="image_col">IMAGE</th>
              <th>Ad</th>
              <th>Impressions</th>
              <th>Clicks</th>
              <th>CTR</th>
               <th>Action</th>
            </tr>
          </thead>
          <tbody class="scroll">
            <?php
			
			$util = Advanced_Ads_Tracking_Util::get_instance();
			if (isset($_GET['period'])) {
				// time handling; blog time offset in seconds
				$gmt_offset = 3600 * floatval( get_option( 'gmt_offset', 0 ) );
				// day start in seconds
				$now = $util->get_timestamp();
				$today_start = $now - $now % Advanced_Ads_Tracking_Util::MOD_HOUR;
				$start = null;
				$end = null;
				switch ($_GET['period']) {
					case 'today' :
						$start = $today_start;
						break;
					case 'yesterday' :
						$start = $util->get_timestamp( time() - DAY_IN_SECONDS );
						$start -= $start % Advanced_Ads_Tracking_Util::MOD_HOUR;
						$end = $today_start;
						break;
					case 'last7days' :
						// last seven full days // -TODO might do last or current week as well
						$start = $util->get_timestamp( time() - WEEK_IN_SECONDS );
						$start -= $start % Advanced_Ads_Tracking_Util::MOD_HOUR;
						break;
					case 'thismonth' :
						// timestamp from first day of the current month
						$start = $now - $now % Advanced_Ads_Tracking_Util::MOD_WEEK;
						break;
					case 'lastmonth' :
						// timestamp from first day of the last month
						$start = $util->get_timestamp( mktime(0, 0, 0, date("m") - 1, 1, date("Y")) );
						$end = $now - $now % Advanced_Ads_Tracking_Util::MOD_WEEK;
						break;
					case 'thisyear' :
						// timestamp from first day of the current year
						$start = $now - $now % Advanced_Ads_Tracking_Util::MOD_MONTH;
						break;
					case 'lastyear' :
						// timestamp from first day of previous year
						$start = $util->get_timestamp( mktime(0, 0, 0, 1, 1, date('Y') - 1) );
						$end = $now - $now % Advanced_Ads_Tracking_Util::MOD_MONTH;
						break;
					case 'custom' :
						$start  = $util->get_timestamp( strtotime( $_GET['from'] ) - $gmt_offset  );
						$end    = $util->get_timestamp( strtotime( $_GET['to'] ) - $gmt_offset + ( 24 * 3600 ) );
						break;
				}
			}
			// TODO limit range (mind groupIncrement/ granularity)
			// values might be null (not set) or false (error in input)
	
			$where = '';
			if (isset($start) && $start) {
				$where .= " AND `timestamp` >= $start";
			}
			if (isset($end) && $end) {
				if ( $where ) {
					$where .= " AND `timestamp` < $end";
				} else {
					$where .= " AND `timestamp` < $end";
				}
			}
			if ( count($ads) > 0) {
				foreach($ads as $ad) {
					$post_title = $wpdb->get_var("SELECT post_title FROM {$wpdb->prefix}posts where ID = '".$ad->ID."'");
					$impression_count = $wpdb->get_var("SELECT SUM(count) as total FROM `wp_advads_impressions` where ad_id='".$ad->ID."'".$where);
					$click_count = $wpdb->get_var("SELECT SUM(count) as total FROM `wp_advads_clicks` where ad_id='".$ad->ID."'".$where);
					$ctr  = number_format(($click_count / $impression_count) * 100,2);
					$advanced_ads_ad_options = maybe_unserialize(get_post_meta($ad->ID,'advanced_ads_ad_options',TRUE));
					$image_id = $advanced_ads_ad_options['output']['image_id'];
					$image = wp_get_attachment_image_src($image_id, 'thumb' );
					if ( $image ) {
						list( $image_url, $image_width, $image_height ) = $image;
					}
			?>
                    <tr id="row_<?php echo $ad->ID;?>">
                      <td class="post-status"><img src="<?php echo $image_url;?>" alt=""  width="" height="" /></td>
                      <td class="post-status"><?php echo $post_title;?></td>
                      <td class="post-status "><?php echo ($impression_count==0)? '0':$impression_count;?></td>
                      <td class="post-status "><?php echo ($click_count==0)? '0' : $click_count;?></td>
                      <td class="post-status "><?php echo ( 0 == $click_count )? '0.00 %' : number_format( 100 * $click_count / $impression_count, 2 ) . ' %';?></td>
                      <td class="post-status "><a href="<?php echo getAdLinkNew($ad->ID);?>" title="View State" >View Stats</a></td>
                    </tr>
            <?php } ?>
            <?php } else { ?>
            <tr>
              <td colspan="7"><?php _e( 'No Ad found', 'dokan-auction' ); ?></td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </article>
  </div>
</div>
<?php //echo do_shortcode("[list_adStats]");?>
<?php
}
function ad_hash_to_id_custom( $hash ) {
	$all_ads = Advanced_Ads::get_ads( array( 'post_status' => array( 'publish', 'future', 'draft', 'pending' ) ) );
	foreach ( $all_ads as $_ad ) {
		$ad = new Advanced_Ads_Ad( $_ad->ID );
		$options = $ad->options();
		if ( ! isset( $options['tracking'] ) ) continue;
		if ( ! isset( $options['tracking']['public-id'] ) ) continue;
		if ( $hash == $options['tracking']['public-id'] ) return $_ad->ID;
	}
	return false;
}
add_action( 'init', function() {
	add_shortcode( 'list_adStats','list_adStats_func');
} );
function list_adStats_func(){ if(!isset($_GET['id'])||$_GET['id']==""){
		wp_redirect(home_url("/ad-analytics/"));
	}
	$ad_id = ad_hash_to_id_custom($_GET['id']);
	if($ad_id==''){
		$ad_id = base64_decode($_GET['id']);
	}
	$period = ( isset( $_GET['period'] ) && ! empty( $_GET['period'] ) )? stripslashes( $_GET['period'] ) : 'last30days';
	$ad = new Advanced_Ads_Ad( $ad_id );
	$ad_options = $ad->options();
	$ad_name = ( isset( $ad_options['tracking']['public-name'] ) && !empty( $ad_options['tracking']['public-name'] ) )? $ad_options['tracking']['public-name'] : $ad->title;
	$ad = new Advanced_Ads_Ad( $ad_id );
	$ad_options = $ad->options();
	$util = Advanced_Ads_Tracking_Util::get_instance();
	$wptz = Advanced_Ads_Tracking::$WP_DateTimeZone;
        $today = date_create( 'now', $wptz );
        $admin_class = new Advanced_Ads_Tracking_Admin();
        $args = array(
            'ad_id' => array( $ad_id ), // actually no effect
            'period' => 'lastmonth',
            'groupby' => 'day',
            'groupFormat' => 'Y-m-d',
            'from' => null,
            'to' => null,
        );
        
        if ( 'last30days' == $period ) {
            $start_ts = intval( $today->format( 'U' ) );
			// unlike with emails, send the current day, then the last 30 days stops at ( today - 29 days )
            $start_ts = $start_ts - ( 29 * 24 * 60 * 60 );
            
            $start = date_create( '@' . $start_ts, $wptz );
            
            $args['period'] = 'custom';
            $args['from'] = $start->format( 'm/d/Y' );
            
            $end_ts = intval( $today->format( 'U' ) );
            $end = date_create( '@' . $end_ts, $wptz );
            
            $args['to'] = $end->format( 'm/d/Y' );
        }
        
        if ( 'last12months' == $period ) {
			$current_year = intval( $today->format( 'Y' ) );
			$current_month = intval( $today->format( 'm' ) );
			$past_year = $current_year - 1;
			
            $args['period'] = 'custom';
            $args['groupby'] = 'month';
			
            $args['from'] = $today->format( 'm/01/' . $past_year );
            $args['to'] = $today->format( 'm/d/Y' );
        }
        
        $impr_stats = $admin_class->load_stats( $args, 'wp_advads_impressions' );
        $clicks_stats = $admin_class->load_stats( $args, 'wp_advads_clicks' );
        $impr_series = array();
        $clicks_series = array();
        $first_date = false;
        $max_clicks = 0;
        $max_impr = 0;
        
		if( isset( $impr_stats ) && is_array( $impr_stats ) ) {
			foreach ( $impr_stats as $date => $impressions ) {
				if ( ! $first_date ) {
				$first_date = $date;
				}
				$impr = 0;
				if ( isset( $impressions[ $ad_id ] ) ) {
				$impr_series[] = array( $date, $impressions[ $ad_id ] );
				$impr = $impressions[ $ad_id ];
				} else {
				$impr_series[] = array( $date, 0 );
				}
				$clicks = 0;
				if ( isset( $clicks_stats[ $date ] ) && isset( $clicks_stats[ $date ][ $ad_id ] ) ) {
				$clicks_series[] = array( $date, $clicks_stats[ $date ][ $ad_id ] );
				$clicks = $clicks_stats[ $date ][ $ad_id ];
				} else {
				$clicks_series[] = array( $date, 0 );
				}
				if ( $impr > $max_impr ) {
				$max_impr = $impr;
				}
				if ( $clicks > $max_clicks ) {
				$max_clicks = $clicks;
				}
			}
		}
        $lines = array( $impr_series, $clicks_series );
	
	?>
    <style type="text/css">
		.my-listing-custom{
			float: left;
			width: 100%;
		}
		.table > thead > tr > th {
			font-size:17px;
		}
		header.entry-header{display:none;}
		tbody.scroll {
		display:block;
		height:167px;
		overflow:auto;
	}
	thead, tbody tr,tfoot {
		display:table;
		width:100%;
		table-layout:fixed;
	}
	thead,tfoot {
		width: calc( 100% - 1em )
	}
	table {
		width:100%;
	}
		@media (max-width: 448px) {
			.dokan-product-listing .table > thead > tr > td, .dokan-product-listing .table > tbody > tr > td, .dokan-product-listing .table > tfoot > tr > td{
				padding:8px 2px !important;
			}
		}
	
	</style>
    <table style="width: 100%;">
      <tbody>
        <tr>
          <td><h1 class="entry-title"><?php printf( __( 'Statistics for %s', 'advanced-ads-tracking' ), $ad_name );?><span class="right-align-txt">ShopADoc<span class="TM_title" style="top:10px;">®</span></span></h1></td>
        </tr>
        <tr>
          <td align="right"><form method="get" id="period-form">
              <label>
                <?php _e( 'Period', 'advanced-ads-tracking' ); ?>
                :&nbsp;</label>
              <select name="period">
                <option value="last30days" <?php selected( 'last30days', $period ); ?>>
                <?php _e( 'last 30 days', 'advanced-ads-tracking' ); ?>
                </option>
                <option value="lastmonth" <?php selected( 'lastmonth', $period ); ?>>
                <?php _e( 'last month', 'advanced-ads-tracking' ); ?>
                </option>
                <option value="last12months" <?php selected( 'last12months', $period ); ?>>
                <?php _e( 'last 12 months', 'advanced-ads-tracking' ); ?>
                </option>
              </select>
              <input type="hidden" name="id" value="<?php echo $_GET['id'];?>" />
              <input type="submit" class="button button-primary" value="<?php echo esc_attr( __( 'Load', 'advanced-ads-tracking' ) ); ?>" />
            </form></td>
        </tr>
      </tbody>
    </table>
    <div class="dokan-dashboard-wrap nano">
      <div class="dokan-dashboard-content dokan-product-listing my-listing-custom">
        <article class="dokan-product-listing-area">
          <div class="table-wrap"> 
            <!--<table class="table table-striped product-listing-table">-->
            <table class="table product-listing-table">
              <thead>
                <tr>
                  <th class="image_col">Date</th>
                  <th>Impressions</th>
                  <th>Clicks</th>
                  <th>CTR</th>
                  <!--<th>Action</th>--> 
                </tr>
              </thead>
              <tbody class="scroll">
                <?php
                    if( isset( $impr_stats ) && is_array( $impr_stats ) ) :
                    $impr_stats = array_reverse( $impr_stats );
                    $impr_sum = 0; 
                    $click_sum = 0; 
                foreach ( $impr_stats as $date => $all ) : ?>
                <tr>
                  <td><?php 
                                if ( 'last12months' == $period ) {
                                    echo date_i18n( 'M Y', strtotime( $date ) );
                                } else {
                                    echo date_i18n( get_option( 'date_format' ), strtotime( $date ) ); 
                                }
                            ?></td>
                  <td><?php
                                $impr = ( isset( $all[$ad_id] ) )? $all[$ad_id] : 0;
                                $impr_sum += $impr;
                                echo $impr;
                            ?></td>
                  <td><?php
                                $click = ( isset( $clicks_stats[$date] ) && isset( $clicks_stats[$date][$ad_id] ) )? $clicks_stats[$date][$ad_id] : 0;
                                $click_sum += $click;
                                echo $click;
                            ?></td>
                  <td><?php
                                $ctr = 0;
                                if ( 0 != $impr ) {
                                    $ctr = $click / $impr * 100;
                                }
                                echo number_format( $ctr, 2 ) . ' %';
                            ?></td>
                </tr>
                <?php endforeach; endif; ?>
              </tbody>
              <tfoot>
              	<tr style="background-color:#f0f0f0;color:#222;font-weight:bold;">
                  <td><?php _e( 'Total', 'advanced-ads-tracking' ); ?></td>
                  <td><?php echo $impr_sum; ?></td>
                  <td><?php echo $click_sum; ?></td>
                  <td><?php echo ( 0 == $click_sum )? '0.00 %' : number_format( 100 * $click_sum / $impr_sum, 2 ) . ' %'; ?></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </article>
      </div>
      <script type="text/javascript" src="<?php echo includes_url( '/js/jquery/jquery.js' ); ?>"></script> 
      <script type="text/javascript" src="<?php echo includes_url( '/js/jquery/jquery-migrate.min.js' ); ?>"></script> 
      <script type="text/javascript" src="<?php echo AAT_BASE_URL . 'admin/assets/jqplot/jquery.jqplot.min.js'; ?>"></script> 
      <script type="text/javascript" src="<?php echo AAT_BASE_URL . 'admin/assets/jqplot/plugins/jqplot.dateAxisRenderer.min.js'; ?>"></script> 
      <script type="text/javascript" src="<?php echo AAT_BASE_URL . 'admin/assets/jqplot/plugins/jqplot.highlighter.min.js'; ?>"></script> 
      <script type="text/javascript" src="<?php echo AAT_BASE_URL . 'admin/assets/jqplot/plugins/jqplot.cursor.min.js'; ?>"></script> 
      <script type="text/javascript" src="<?php echo AAT_BASE_URL . 'public/assets/js/public-stats.js'; ?>"></script>
      <link rel="stylesheet" href="<?php echo AAT_BASE_URL . 'admin/assets/jqplot/jquery.jqplot.min.css'; ?>" />
      <link rel="stylesheet" href="<?php echo AAT_BASE_URL . 'public/assets/css/public-stats.css'; ?>" />
      <?php do_action( 'advanced-ads-public-stats-head' ); ?>
      <script type="text/javascript">
                var statsGraphOptions = {
                    axes:{
                        xaxis:{
                            renderer: null,
                            <?php if ( 'last12months' == $period ) : ?>
                            tickOptions: { formatString: '%b %Y' },
                            <?php else : ?>
                            tickOptions: { formatString: '%b%d' },
                            <?php endif; ?>
                            tickInterval: '1 <?php echo $args['groupby']; ?>',
                            min: '<?php echo $first_date; ?>',        
                        },
                        yaxis:{
                            min: 0,
                            max: <?php echo ( intval( $max_impr * 1.1 / 10 ) + 1 ) * 10; ?>,
                            formatString: '$%.2f',
                            label: '<?php _e( 'impressions', 'advanced-ads-tracking' ); ?>',
                        },
                        y2axis:{
                            min: 0,
                            max: <?php echo ( intval( $max_clicks * 1.3 / 10 ) + 1 ) * 10; ?>,
                            label: '<?php _e( 'clicks', 'advanced-ads-tracking' ); ?>',
                        }
                    },
                    highlighter: {
                        show: true,
                    },
                    cursor: {
                        show: false
                    },
                    title: {
                        show: true
                    },
                    series: [
                        {
                            highlighter: {
                                formatString:'%s, %d <?php _e( 'impressions', 'advanced-ads-tracking' ); ?>',
                            },
                            lineWidth: 1,
                            markerOptions: { style: 'circle', size: 5 },
                            color: '#f06050',
                            label: '<?php _e( 'impressions', 'advanced-ads-tracking' ); ?>',
                        }, // impressions
                        {
                            yaxis:'y2axis', 
                            highlighter: {
                                formatString: '%s, %d <?php _e( 'clicks', 'advanced-ads-tracking' ); ?>',
                            },
                            lineWidth: 2,
                            linePattern: 'dashed',
                            markerOptions: { style: 'filledSquare', size: 5 },
                            color: '#4b5de4',
                            label: '<?php _e( 'clicks', 'advanced-ads-tracking' ); ?>',
                        } // clicks
                    ],
                }
                var lines = <?php echo json_encode( $lines ); ?>; 
                </script>
      <div id="public-stat-graph" style="float:left;top:20px;width:100%;font-size:13px;"></div>
      <div id="graph-legend" style="float:left;text-align:center;">
        <div class="legend-item">
          <div id="impr-legend"></div>
          <span class="legend-text">
          <?php _e( 'impressions', 'advanced-ads-tracking' ); ?>
          </span> </div>
        <div class="legend-item">
          <div id="click-legend"></div>
          <span class="legend-text">
          <?php _e( 'clicks', 'advanced-ads-tracking' ); ?>
          </span> </div>
      </div>
    </div>
    <?php
}
add_action( 'init', function() {
	
	add_shortcode( 'list_auctions','list_auctions_func');

} );
function list_auctions_func(){?>
<?php 
if (!is_user_logged_in()){
	wp_redirect( home_url( '/my-account/' ) );
	exit();
}
?>
<?php /*?>
<link rel="stylesheet" href="<?php echo home_url();?>/wp-content/themes/dokan-child/nanoscroller.css">
<script type="text/javascript" src="<?php echo home_url();?>/wp-content/themes/dokan-child/jquery.nanoscroller.js"></script>
<style type="text/css">
.nano {width: 100%; height: 167px; }
.nano .nano-content { padding: 10px; }
.nano .nano-pane   { background: #f0f0f0; }
</style>
<script type="text/javascript">
	jQuery(function(){
		jQuery('.nano').nanoScroller({
			preventPageScrolling: true,
			sliderMaxHeight: 25,
			alwaysVisible: true,
			contentClass: 'my-listing-custom'
		});
	});
</script>
<?php */?>
<style type="text/css">
.entry-header{display:none !important;}
ul.subsubsub{font-size:15px;margin-top:40px;}
.auction-list-fav .sav-fav-text,.auction-list-fav .fav-text,.auction-list-fav .swf_message{display:none !important;}
.auction-list-fav .swf_container{float:none;text-align:center;}
.my-listing-custom{
	float: left;
	width: 100%;
	height: 167px;
	overflow-y: scroll;
}
.table > thead > tr > th {
	font-size:17px;
}
@media (max-width: 448px) {
	.dokan-product-listing .table > thead > tr > td, .dokan-product-listing .table > tbody > tr > td, .dokan-product-listing .table > tfoot > tr > td{
		padding:8px 2px !important;
	}
}
</style>
<?php makeFlashLive();?>
<div class="dokan-dashboard-wrap">
	<div id="no_auction_div"></div>
    <div class="dokan-dashboard-content dokan-product-listing my-listing-custom">
        <article class="dokan-product-listing-area">
				<div class="table-wrap">
                <table class="table product-listing-table">
                    <thead>
                        <tr>
                            <th class="image_col"><?php _e( 'IMAGE', 'dokan-auction' ); ?></th>
                            <th><?php _e( 'SERVICE', 'dokan-auction' ); ?></th>
                            <th class="center ask_fee" ><?php _e( 'ASK FEE', 'dokan-auction' ); ?></th>
                            <th class="center"><?php _e( 'STATUS', 'dokan-auction' ); ?></th>
                            <th class="center"><?php _e( 'START DATE', 'dokan-auction' ); ?></th>
                            <th width="8%" class="center"><img src="<?php echo home_url('/wp-content/themes/dokan-child/Heart-Icon-Header-3D.png')?>" alt="" border="0" title="" width="25px"/></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        global $post;
						$pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
						$post_statuses = array('publish');
						if(isset($_GET['auction_status']) && $_GET['auction_status']=='past'){}else{
							$args = array(
								'post_status'         => $post_statuses,
								'ignore_sticky_posts' => 1,
								'orderby'             => 'post_date',
								//'author'              => dokan_get_current_user_id(),
								'order'               => 'DESC',
								'posts_per_page'      => -1,
								'tax_query'           => array( array( 'taxonomy' => 'product_type', 'field' => 'slug', 'terms' => 'auction' ) ),
								//'meta_query' => array(array('key' => '_auction_closed','compare' => 'NOT EXISTS',)),
								'auction_archive'     => TRUE,
								'show_past_auctions'  => TRUE,
								'paged'               => $pagenum
							);
						}
						

                        if ( isset( $_GET['post_status'] ) && in_array( $_GET['post_status'], $post_statuses ) ) {
                            $args['post_status'] = $_GET['post_status'];
                        }

                        // $original_post = $post;
                        $product_query = new WP_Query( $args );
						$count = $product_query->found_posts;
						$user_id    = get_current_user_id();
						$favourites = swf_get_favourites( $user_id) ;
						global $radius_distance;
						$i = 0;
                        if ( $product_query->have_posts() ) {
                            while ($product_query->have_posts()) {
                                $product_query->the_post();
                                $tr_class = ($post->post_status == 'pending' ) ? ' class="danger"' : '';
                                $product = dokan_wc_get_product( $post->ID );
								$_auction_start_price = get_post_meta($post->ID, '_auction_start_price',TRUE);
								global $wpdb,$today_date_time;
								$bid_count = $wpdb->get_var("SELECT count(id) as count FROM wp_simple_auction_log WHERE auction_id = '".$post->ID."' and userid = '".dokan_get_current_user_id()."' LIMIT 1");
								$auction_location = get_post_meta($post->ID, '_auction_location',true);
								$dentist_office_address = getDentistAddress();
								$Distance = 0;
								if(trim($dentist_office_address) !="" && trim($auction_location) !=""){
									$Distance = get_driving_information($dentist_office_address,$auction_location);
									//if($Distance > 50){
										//return false;
									//}
								}
								//echo $Distance."==".$dentist_office_address."==".$auction_location."<br />";
								if($Distance <= $radius_distance){
									$i++;
                                ?>
                                <tr<?php echo $tr_class; ?> >
                                    <td class="image_col"><a href="<?php echo get_permalink( $product->get_id() ); ?>"><?php echo $product->get_image(); ?></a></td>
                                    <td width="50%"><p><a href="<?php echo get_permalink( $product->get_id() ); ?>"><?php echo $product->get_title(); ?></a></p>
                                        
                                    </td>
                                    <td class="post-status" align="center">
                                    <label class="dokan-label">
                                        <?php
                                        if ( $product->get_price_html() ) {
                                            //echo str_replace("Current bid:","",str_replace("Ask Fee:","",$product->get_price_html()));
											//echo wc_price($_auction_start_price);
											echo "$".abs($_auction_start_price);
                                        } else {
                                            echo '<span class="na">&ndash;</span>';
                                        }
                                        ?>
                                        </label>
                                    </td>
                                    <?php 
										$_auction_current_bid = get_post_meta($product->get_id(), '_auction_current_bid', true );
										$_auction_closed = get_post_meta($product->get_id(), '_auction_closed', true );
										$_auction_dates_extend = get_post_meta($product->get_id(), '_auction_dates_extend', true );
										$_flash_status = get_post_meta($product->get_id(), '_flash_status', true );
										$customer_winner = get_post_meta($product->get_id(),'_auction_current_bider', true);
										//if(!$_auction_current_bid && $_auction_closed==1){
										if($product->is_closed() === TRUE){	
												global $today_date_time;
												$_flash_cycle_start = get_post_meta( $product->get_id() , '_flash_cycle_start' , TRUE);
												$_flash_cycle_end = get_post_meta( $product->get_id() , '_flash_cycle_end' , TRUE);
												if(strtotime($today_date_time) < strtotime($_flash_cycle_start) && strtotime($_flash_cycle_end) > strtotime($today_date_time)){
													if(!$_auction_current_bid){
														$status = '<span>countdown to Flash Bid Cycle<span class="TM_flash">®</span></span>';
														$class = " ended";
													}else{
														if($customer_winner == $user_id){
															$status = '<span class="red">✓ Email (Spam)</span>';
														}else{
															$status = '<span>ended</span>';
														}
														$class = " ended";
													}
												}else{
													if($customer_winner == $user_id){
														$status = '<span class="red">✓ Email (Spam)</span>';
													}else{
														$status = '<span>ended</span>';
													}
													$class = " ended";
												}
												/*if($customer_winner == $user_id){
													$status = '<span class="red">✓ Email (Spam)</span>';
												}else{
													$status = '<span>ended</span>';
												}*/
												$class = " ended";
										}else{
											if(($product->is_closed() === FALSE ) and ($product->is_started() === FALSE )){
												if($post->post_status=='pending'){
													$status = '<span>countdown to auction</span>';
													$class = " upcoming-pending";
												}else{
													$status = '<span>countdown to auction</span>';
													$class = " upcoming";
												}
											}else{
												if($post->post_status=='pending'){
													$status = '<span>Live: Pending Review</span>';
													$class = " live";
												}else{
													if ($_auction_dates_extend == 'yes') {
														$status = '<span>extended</span>';
														$class = " extended";
													}else{
														if($_flash_status == 'yes'){
															$status = '<span>Flash Bid Cycle<span class="TM_flash">®</span> live</span>';
															$class = " live";
														}else{
															$status = '<span style="color:red;">auction live</span>';
															$class = " live";
														}
													}
												}
											}
										}
									?>
                                    <td class="post-status status_col" align="center">
                                        <label class="dokan-label <?php echo /*$post->post_status.*/$class; ?>"><?php echo $status;//dokan_get_post_status( $post->post_status ); ?></label>
                                    </td>
                                   <td class="post-status date_col" align="center">
                                    <label class="dokan-label"><?php echo date_i18n('l m/d/Y',strtotime( $product->get_auction_start_time()));?></label>
                                    </td>
                                     <!--<td class="auction-list-fav"></td>-->
                                     <td class="auction-list-fav" align="center">
                                     <?php 
									 	if($bid_count >0){?>
                                        	<img class="bid_man" src="<?php echo home_url('/wp-content/themes/dokan-child/Bid-Active-Icon-on.png')?>" alt="" border="0" title="" width="25px"/>
										<?php }else{?>
                                        <?php //echo do_shortcode("[simple_favourites_button]");?>
                                        <?php if(in_array($post->ID,$favourites)){ ?>
												<img class="heart_img" src="<?php echo home_url('/wp-content/themes/dokan-child/Heart-Icon-Header.png')?>" alt="" border="0" title="" width="20px" style="margin-left:2px;"/>
										<?php }else{?>
                                        	<img class="heart_img" src="<?php echo home_url('/wp-content/themes/dokan-child/Heart-Icon-Header-empty.png')?>" alt="" border="0" title="" width="20px" style="margin-left:2px;"/>
                                        <?php }?>
										<?php }?>
                                     </td>
                                </tr>
								<?php }?>
                            <?php } ?>

                        <?php } else { ?>
                            <tr>
                                <td colspan="7"><?php _e( 'No auction found', 'dokan-auction' ); ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>
				</div>
                <?php
                wp_reset_postdata();

                $pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;

                if ( $product_query->max_num_pages > 1 ) {
                    echo '<div class="pagination-wrap">';
                    $page_links = paginate_links( array(
                        'current'   => $pagenum,
                        'total'     => $product_query->max_num_pages,
                        'base'      => add_query_arg( 'pagenum', '%#%' ),
                        'format'    => '',
                        'type'      => 'array',
                        'prev_text' => __( '&laquo; Previous', 'dokan-auction' ),
                        'next_text' => __( 'Next &raquo;', 'dokan-auction' )
                    ) );

                    echo '<ul class="pagination"><li>';
                    echo join("</li>\n\t<li>", $page_links);
                    echo "</li>\n</ul>\n";
                    echo '</div>';
                }
                ?>
    	</article>
    </div>
</div>
<script type="text/javascript">
	<?php if($i==0){?>
		jQuery("#no_auction_div").html('<h2>No current listings in your service area</h2>');
	<?php }?>
</script>
<?php //echo do_shortcode('[ad_section]');?>
<?php 
}
function change_role_name() {
    global $wp_roles;
    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();
    //You can list all currently available roles like this...
    //$roles = $wp_roles->get_names();
    //print_r($roles);

    //You can replace "administrator" with any other role "editor", "author", "contributor" or "subscriber"...
    $wp_roles->roles['seller']['name'] = 'Client';
    $wp_roles->role_names['seller'] = 'Client';   
	$wp_roles->roles['customer']['name'] = 'Dentist';
    $wp_roles->role_names['customer'] = 'Dentist';           
}
add_action('init', 'change_role_name');
add_filter( 'woocommerce_form_field', 'checkout_fields_in_label_error', 10, 4 );

function checkout_fields_in_label_error( $field, $key, $args, $value ) {
   if ( strpos( $field, '</span>' ) !== false && $args['required'] ) {
      $error = '<span class="error" style="display:none">';
      $error .= sprintf( __( 'Billing %s is a required field.', 'woocommerce' ), $args['label'] );
      $error .= '</span>';
      $field = substr_replace( $field, $error, strpos( $field, '</span>' ), 0);
   }
   return $field;
}
function prfx_featured_meta() {
    add_meta_box( 'prfx_meta', __( "We've Updated", 'prfx-textdomain' ), 'prfx_meta_callback', 'page', 'side', 'high' );
}
add_action( 'add_meta_boxes', 'prfx_featured_meta' );
function prfx_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'prfx_nonce' );
    //$prfx_stored_meta = get_post_meta( $post->ID );
    ?>
 <p>
    <!--<span class="prfx-row-title"><?php _e( 'Check if content has been updated: ', 'prfx-textdomain' )?></span>-->
    <div class="prfx-row-content">
        <label for="featured-checkbox">
            <input type="checkbox" name="update-checkbox" id="update-checkbox" value="yes" <?php //if ( isset ( $prfx_stored_meta['update-checkbox'] ) ) checked( $prfx_stored_meta['update-checkbox'][0], 'yes' ); ?> /><?php _e( 'Checking this box will force registered users to reaccept the terms pop up', 'prfx-textdomain' )?>
        </label>

    </div>
</p>   
<?php
}
function prfx_meta_save( $post_id ) {
	global $wpdb;
    // Checks save status - overcome autosave, etc.
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'prfx_nonce' ] ) && wp_verify_nonce( $_POST[ 'prfx_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
	if($post_id==56 || $post_id==60 || $post_id==62){
		if(isset($_POST['update-checkbox'])){
			//echo "i have update the content";die;
			$query = "SELECT option_id FROM wp_options where option_name like '%termpopup_%'";
			$results = $wpdb->get_results($query, OBJECT);
			foreach($results as $row){
				$wpdb->query('DELETE FROM wp_options WHERE option_id = "'.$row->option_id.'"');
			}
		}
	}
	/*if( isset( $_POST[ 'featured-checkbox' ] ) ) {
		update_post_meta( $post_id, 'update-checkbox', 'yes' );
	} else {
		update_post_meta( $post_id, 'update-checkbox', 'no' );
	}*/

}
add_action( 'save_post', 'prfx_meta_save' );
add_filter( 'woocommerce_get_price_html', 'custom_price_html', 100, 2 );
function custom_price_html( $price, $product ){
    return str_replace(',', '',$price);
}
//Create admin page 
add_action('admin_menu', 'ad_setting_admin_menu');
function ad_setting_admin_menu() {
    add_options_page('Ad Placement', 'Ad Placement', 'manage_options', __FILE__, 'ad_placement');
}
function ad_placement() {
	//print_r($_POST);
	if(isset($_POST['save_ad_setting']) && $_POST['save_ad_setting'] !=""){
		if($_POST['mode']=='dentist'){
			$rotations = array();
			for($i = 1;$i <= 10;$i++){
				$rotation_str = '';
				$option_name = 'position'.$i.'_col1_dentist';
				$new_value = $_POST['position'.$i.'_col1_dentist'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str = $new_value;
				}
				//Col2
				$option_name = 'position'.$i.'_col2_dentist';
				$new_value = $_POST['position'.$i.'_col2_dentist'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str .=",".$new_value;
				}
				//Col3
				$option_name = 'position'.$i.'_col3_dentist';
				$new_value = $_POST['position'.$i.'_col3_dentist'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str .=",".$new_value;
				}
				//Col4
				$option_name = 'position'.$i.'_col4_dentist';
				$new_value = $_POST['position'.$i.'_col4_dentist'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str .=",".$new_value;
				}
				$rotations[$i] .= $rotation_str;
			}
			$rotations_data = maybe_serialize($rotations);
			//print_r($rotations_data);
			$option_name = 'rotations_dentist';
			$new_value = $rotations_data;
			if ( get_option( $option_name ) !== false ) {
				update_option( $option_name, $new_value );
			}else{
				$deprecated = null;
				$autoload = 'yes';
				add_option( $option_name, $new_value, $deprecated, $autoload );
			}
		}else{
			$rotations = array();
			for($i = 1;$i <= 10;$i++){
				$rotation_str = '';
				$option_name = 'position'.$i.'_col1_client';
				$new_value = $_POST['position'.$i.'_col1_client'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str = $new_value;
				}
				//Col2
				$option_name = 'position'.$i.'_col2_client';
				$new_value = $_POST['position'.$i.'_col2_client'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str .=",".$new_value;
				}
				//Col3
				$option_name = 'position'.$i.'_col3_client';
				$new_value = $_POST['position'.$i.'_col3_client'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str .=",".$new_value;
				}
				//Col4
				$option_name = 'position'.$i.'_col4_client';
				$new_value = $_POST['position'.$i.'_col4_client'];
				if($new_value !=""){
					//echo $option_name.'=='.$new_value.'<br />';
					if ( get_option( $option_name ) !== false ) {
						update_option( $option_name, $new_value );
					}else{
						$deprecated = null;
						$autoload = 'yes';
						add_option( $option_name, $new_value, $deprecated, $autoload );
					}
					$rotation_str .=",".$new_value;
				}
				$rotations[$i] .= $rotation_str;
			}
			$rotations_data = maybe_serialize($rotations);
			//print_r($rotations_data);
			$option_name = 'rotations_client';
			$new_value = $rotations_data;
			if ( get_option( $option_name ) !== false ) {
				update_option( $option_name, $new_value );
			}else{
				$deprecated = null;
				$autoload = 'yes';
				add_option( $option_name, $new_value, $deprecated, $autoload );
			}
		}
	}
	?>
    <style type="text/css">
		.notice-error,.error{
			display:none !important;
		}
		ul{float:left;width:100%;margin:0;}
		ul.nav-tabs li{
			float:left;
			width:10%;
			border:solid 1px #888;
			color:#000;
			padding:10px;
			border-radius:5px 5px 0px 0px;
			border-bottom:none;
			text-align:center;
			font-weight:bold;
			margin:0;
		}
		ul.nav-tabs li.active{
			background:#ccc;
		}
		ul.nav-tabs li a{
			color: #000;
			text-decoration:none !important;
		}
		.submit{
			width:100%;
			text-align:right;
		}
		.submit .save-btn {
			padding: 0 28px;
			font-size: 18px;
			font-weight: bold;
		}
	</style>
	<div class="wrap">
  <div id="poststuff">
    <div id="post-body">
      <form method="post" action="">
        <div class="postbox">
          <h3 class="hndle">
            <label for="title">Ads Placement Setting</label>
          </h3>
        
          <?php if(isset($_GET['mode']) && $_GET['mode']== 'dentist'){ ?>
          	  <div class="inside">
            <?php 
				
				global $wpdb;
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title like '% D%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				$html1 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html1 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				/*
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title not like '% C%' and post_title like '%Col 2%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				//print_r($results);
				$html2 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html2 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title not like '%Client%' and post_title like '%Col 3%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				//print_r($results);
				$html3 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html3 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title not like '%Client%' and post_title like '%Col 4%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				//print_r($results);
				$html4 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html4 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				*/
				?>
              <ul class="nav nav-tabs">
                <li ><a href="<?php echo home_url('wp-admin/options-general.php?page=home%2Fshopadoc%2Fpublic_html%2Fwp-content%2Fthemes%2Fdokan-child%2Ffunctions.php');?>">Client</a></li>
                <li class="active"><a href="<?php echo home_url('wp-admin/options-general.php?page=home%2Fshopadoc%2Fpublic_html%2Fwp-content%2Fthemes%2Fdokan-child%2Ffunctions.php&mode=dentist');?>">Dentist</a></li>
              </ul>
              <style type="text/css">
			  .form-table th{padding:4px 0 !important;}
			  .form-table td{padding:5px 10px !important; }
			  .wp-core-ui select{width:75%;}
			  </style>
            <table class="form-table" border="1">
              <thead>
                <tr>
                  <th style="text-align:center" width="10%">ROTATIONS</th>
                  <th style="text-align:center">Column A</th>
                  <th style="text-align:center">Column B</th>
                  <th style="text-align:center">Column C</th>
                  <th style="text-align:center">Column D</th>
                </tr>
              </thead>
              <tbody>
                <?php for($i = 1;$i <= 10;$i++){
					$option_name1 = 'position'.$i.'_col1_dentist';
					$option_name2 = 'position'.$i.'_col2_dentist';
					$option_name3 = 'position'.$i.'_col3_dentist';
					$option_name4 = 'position'.$i.'_col4_dentist';
				?>
                <tr>
                  <td align="center" width="10%"><strong><?php echo $i?></strong></td>
                  <td align="center"><select name="position<?php echo $i?>_col1_dentist" id="position<?php echo $i?>_col1_dentist">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name1) !=""){?><span id="<?php echo $option_name1;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name1).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                  <td align="center"><select name="position<?php echo $i?>_col2_dentist" id="position<?php echo $i?>_col2_dentist">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name2) !=""){?><span id="<?php echo $option_name2;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name2).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                  <td align="center"><select name="position<?php echo $i?>_col3_dentist" id="position<?php echo $i?>_col3_dentist">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name3) !=""){?><span id="<?php echo $option_name3;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name3).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                  <td  align="center"><select name="position<?php echo $i?>_col4_dentist" id="position<?php echo $i?>_col4_dentist">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name4) !=""){?><span id="<?php echo $option_name4;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name4).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                </tr>
                <script type="text/javascript">
						jQuery('#<?php echo $option_name1;?>').change(function(){   
							jQuery("#<?php echo $option_name1;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						jQuery('#<?php echo $option_name2;?>').change(function(){   
							jQuery("#<?php echo $option_name2;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						jQuery('#<?php echo $option_name3;?>').change(function(){   
							jQuery("#<?php echo $option_name3;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						jQuery('#<?php echo $option_name4;?>').change(function(){   
							jQuery("#<?php echo $option_name4;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						document.getElementById('<?php echo $option_name1;?>').value = <?php echo get_option($option_name1);?> ;
						document.getElementById('<?php echo $option_name2;?>').value = <?php echo get_option($option_name2);?> ;
						document.getElementById('<?php echo $option_name3;?>').value = <?php echo get_option($option_name3);?> ;
						document.getElementById('<?php echo $option_name4;?>').value = <?php echo get_option($option_name4);?> ;
				</script>
                <?php 
				
				}?>
              </tbody>
            </table>
            <div class="submit">
              <input type="hidden" name="mode" value="dentist" />
              <input type="submit" class="button-primary save-btn" name="save_ad_setting" value="Save" />
            </div>
          </div>
          <?php }else{?>
         	 <div class="inside">
            <?php 
				
				global $wpdb;
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title like '% C%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				$html1 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html1 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				/*
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title like '%Client%' and post_title like '%Col 2%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				//print_r($results);
				$html2 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html2 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title like '%Client%' and post_title like '%Col 3%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				//print_r($results);
				$html3 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html3 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				$query = "SELECT * FROM wp_posts where post_status = 'publish' and post_type = 'advanced_ads' and post_title like '%Client%' and post_title like '%Col 4%' ORDER BY ID ASC";
				$results = $wpdb->get_results($query, OBJECT);
				//print_r($results);
				$html4 = '';
				foreach($results as $row){
					if($row->ID !=""){
						$html4 .= '<option value="'.$row->ID.'">'.$row->post_title.'</option>';
					}
				}
				*/
				?>
             <ul class="nav nav-tabs">
                <li class="active"><a href="<?php echo home_url('wp-admin/options-general.php?page=home%2Fshopadoc%2Fpublic_html%2Fwp-content%2Fthemes%2Fdokan-child%2Ffunctions.php');?>">Client</a></li>
                <li ><a href="<?php echo home_url('wp-admin/options-general.php?page=home%2Fshopadoc%2Fpublic_html%2Fwp-content%2Fthemes%2Fdokan-child%2Ffunctions.php&mode=dentist');?>">Dentist</a></li>
              </ul>
              <style type="text/css">
			  .form-table th{padding:4px 0 !important;}
			  .form-table td{padding:5px 10px !important; }
			  .wp-core-ui select{width:75%;}
			  </style>
            <table class="form-table" border="1">
              <thead>
                <tr>
                  <th style="text-align:center" width="10%">ROTATIONS</th>
                  <th style="text-align:center">Column A</th>
                  <th style="text-align:center">Column B</th>
                  <th style="text-align:center">Column C</th>
                  <th style="text-align:center">Column D</th>
                </tr>
              </thead>
              <tbody>
                <?php for($i = 1;$i <= 10;$i++){ 
					$option_name1 = 'position'.$i.'_col1_client';
					$option_name2 = 'position'.$i.'_col2_client';
					$option_name3 = 'position'.$i.'_col3_client';
					$option_name4 = 'position'.$i.'_col4_client';
					//$value1 = get_option('position'.$i.'_col1_client');
				?>
                <tr>
                  <td align="center" width="10%"><strong><?php echo $i?></strong></td>
                  <td align="center"><select name="position<?php echo $i?>_col1_client" id="position<?php echo $i?>_col1_client">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name1) !=""){?><span id="<?php echo $option_name1;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name1).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                  <td align="center"><select name="position<?php echo $i?>_col2_client" id="position<?php echo $i?>_col2_client">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name2) !=""){?><span id="<?php echo $option_name2;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name2).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                  <td align="center"><select name="position<?php echo $i?>_col3_client" id="position<?php echo $i?>_col3_client">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name3) !=""){?><span id="<?php echo $option_name3;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name3).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                  <td  align="center"><select name="position<?php echo $i?>_col4_client" id="position<?php echo $i?>_col4_client">
                      <option value="">- Please Select Ad -</option>
                      <?php echo $html1;?>
                    </select><?php if(get_option($option_name4) !=""){?><span id="<?php echo $option_name4;?>_view">&nbsp;<a href="<?php echo home_url('/wp-admin/post.php?post='.get_option($option_name4).'&action=edit');?>" target="_blank">View Ad</a></span><?php }?></td>
                </tr>
                <script type="text/javascript">
						jQuery('#<?php echo $option_name1;?>').change(function(){   
							jQuery("#<?php echo $option_name1;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						jQuery('#<?php echo $option_name2;?>').change(function(){   
							jQuery("#<?php echo $option_name2;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						jQuery('#<?php echo $option_name3;?>').change(function(){   
							jQuery("#<?php echo $option_name3;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						jQuery('#<?php echo $option_name4;?>').change(function(){   
							jQuery("#<?php echo $option_name4;?>_view").html('&nbsp;<a href="<?php echo home_url();?>/wp-admin/post.php?post='+jQuery(this).val()+'&action=edit" target="_blank">View Ad</a>');
						});
						document.getElementById('<?php echo $option_name1;?>').value = <?php echo get_option($option_name1);?> ;
						document.getElementById('<?php echo $option_name2;?>').value = <?php echo get_option($option_name2);?> ;
						document.getElementById('<?php echo $option_name3;?>').value = <?php echo get_option($option_name3);?> ;
						document.getElementById('<?php echo $option_name4;?>').value = <?php echo get_option($option_name4);?> ;
				</script>
                <?php 
				
				}?>
              </tbody>
            </table>
            <div class="submit">
              <input type="submit" class="button-primary save-btn" name="save_ad_setting" value="Save" />
            </div>
          </div>
          <?php }?>
        </div>
      </form>
    </div>
  </div>
</div>
<?php 
}
add_filter('wp_generate_attachment_metadata', 'txt_domain_delete_fullsize_image');
function txt_domain_delete_fullsize_image($metadata){
    $upload_dir = wp_upload_dir();
	if(strpos($metadata['file'],'-scaled') !== false){
		$full_image_path = trailingslashit($upload_dir['basedir']) . str_replace("-scaled","",$metadata['file']);
		$deleted = unlink($full_image_path);
	}
    return $metadata;
}
function wpse_240765_unset_images( $sizes ){
    unset( $sizes[ 'thumbnail' ]);
	unset( $sizes[ 'medium' ]);
    unset( $sizes[ 'medium_large' ] );
    unset( $sizes[ 'large' ]);
    unset( $sizes[ 'full' ] );
	
    unset( $sizes[ '1536x1536' ] );
    unset( $sizes[ '2048x2048' ] );
    unset( $sizes[ 'woocommerce_single' ] );
    unset( $sizes[ 'shop_single' ] );
    return $sizes;
}
add_filter( 'intermediate_image_sizes_advanced', 'wpse_240765_unset_images' );

add_filter('woocommerce_login_redirect', 'wc_login_redirect',2,10); 

function wc_login_redirect( $redirect_to, $user ) {
    if(!is_admin()){
		//$user = wp_get_current_user();
		if($user->roles[0]=='seller'){
			$redirect_to = home_url('/auction-activity/auction/');
		}else{
			$redirect_to = home_url('/shopadoc-auction-activity/');
		}
	}
    return $redirect_to;

}
?>