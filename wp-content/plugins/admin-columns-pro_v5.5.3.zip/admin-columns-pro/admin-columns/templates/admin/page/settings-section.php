<tr class="<?= esc_attr( $this->class ); ?>">
	<th scope="row">
		<h2><?= $this->title; ?></h2>
		<p><?= $this->description; ?></p>
	</th>
	<td>
		<?= $this->content; ?>
	</td>
</tr>