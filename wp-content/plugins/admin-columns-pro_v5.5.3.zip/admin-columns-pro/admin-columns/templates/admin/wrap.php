<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="cpac" class="wrap">
	<?= $this->content; ?>
</div>