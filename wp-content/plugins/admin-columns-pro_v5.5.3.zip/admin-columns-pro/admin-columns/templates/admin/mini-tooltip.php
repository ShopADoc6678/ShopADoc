<div class="ac-mini-tooltip">
	<?= $this->label; ?>
	<span class="ac-mini-tooltip-content">
		<?= $this->content; ?>
	</span>
</div>