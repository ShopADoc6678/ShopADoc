<?php

namespace AC\ColumnRepository;

interface Sort {

	public function sort( $columns );

}