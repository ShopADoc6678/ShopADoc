<?php

namespace AC;

interface Sanitize {

	public function sanitize( $data );

}