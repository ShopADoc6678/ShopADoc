<?php

namespace AC\Type;

interface Url {

	/**
	 * @return string
	 */
	public function get_url();

}