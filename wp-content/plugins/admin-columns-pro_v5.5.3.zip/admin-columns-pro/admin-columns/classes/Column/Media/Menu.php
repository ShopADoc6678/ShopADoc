<?php

namespace AC\Column\Media;

use AC\Column;

class Menu extends Column\Post\Menu {

}