<?php

namespace AC\Helper\Select;

interface Value {

	/**
	 * @param $entity
	 *
	 * @return string
	 */
	public function get_value( $entity );

}