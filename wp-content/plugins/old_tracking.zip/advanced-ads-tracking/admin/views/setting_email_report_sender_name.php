<input type="text" class="regular-text" name="<?php echo $this->plugin->options_slug; ?>[email-sender-name]" value="<?php echo esc_attr( $sender_name ); ?>" autocomplete="advads-sender-name"/>
