<input type="email" class="regular-text ltr" name="<?php 
	echo $this->plugin->options_slug; ?>[email-sender-address]" value="<?php 
	echo esc_attr( $sender_address ); 
	?>" autocomplete="email" />