<input type="number" name="<?php echo ADVADS_SLUG . '[' . AAR_SLUG . '][fallback-width]' ?>" value="<?php echo $width; ?>" />px
