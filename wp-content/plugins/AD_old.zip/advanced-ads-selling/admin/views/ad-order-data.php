<table>
    <tr>
	<th><?php _e( 'Setup URL', 'advanced-ads-selling' ); ?></th><td><a target="blank" href="<?php echo Advanced_Ads_Selling_Plugin::get_instance()->get_ad_setup_url( $hash ); ?>"><?php echo $hash; ?></a></td></tr>
</table>