<input name="<?php echo Advanced_Ads_Selling_Plugin::OPTION_KEY; ?>[wc-fixes]" type="checkbox" value="1" <?php checked( 1, $wc_fixes ); ?>/>
<p class="description"><?php _e( 'Applies the following changes to WooCommerce. Especially useful, when you don’t use WooCommerce for anything else than ads.', 'advanced-ads-selling' ); ?></p>
<ul>
    <li><?php _e( 'Remove product images', 'advanced-ads-selling' ); ?></li>
</ul>