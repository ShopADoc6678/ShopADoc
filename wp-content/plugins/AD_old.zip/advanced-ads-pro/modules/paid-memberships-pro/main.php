<?php

new Advanced_Ads_Pro_Module_PaidMembershipsPro;
