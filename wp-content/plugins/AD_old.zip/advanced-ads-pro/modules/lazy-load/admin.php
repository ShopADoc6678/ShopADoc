<?php

new Advanced_Ads_Pro_Module_Lazy_Load_Admin;
