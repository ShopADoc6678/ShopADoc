<?php

new Advanced_Ads_Pro_Module_Grids_Admin();
