<?php

// module configuration

$path = dirname( __FILE__ );

return array(
	'classmap' => array(
		'Advanced_Ads_Pro_Cache_Busting_Server_Info' => $path . '/server-info.class.php',
	),
	'textdomain' => null,
);
