<div class="notice notice-error advads-admin-notice"><p><?php echo $text; ?></p></div>
