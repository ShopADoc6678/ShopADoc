<p><label><input type="checkbox" disabled="disabled"/><?php esc_html_e( 'repeat the position', 'advanced-ads' ); ?></label>
	<?php Advanced_Ads_Admin_Upgrades::upgrade_link( null, ADVADS_URL . 'add-ons/advanced-ads-pro/', 'upgrade-content-repeat' ); ?>
</p>
