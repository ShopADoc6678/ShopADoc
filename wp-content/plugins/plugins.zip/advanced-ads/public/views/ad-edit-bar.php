<div class="advads-edit-bar advads-edit-appear">
<a href="<?php echo get_edit_post_link( $this->id ); ?>" class="advads-edit-button" title="<?php esc_attr_e( strip_tags( $this->title ) ); ?>" rel="nofollow"><span class="dashicons dashicons-edit"></span></a>
</div>
