<?php

// module configuration

$path = dirname( __FILE__ );

return array(
	'classmap' => array(
		'Advanced_Ads_Gutenberg' => $path . '/includes/class-gutenberg.php',
	),
	'textdomain' => null,
);