<?php

// module configuration
return array(
	'classmap'   => array(
		'Advanced_Ads_Privacy'       => __DIR__ . '/classes/class-privacy.php',
		'Advanced_Ads_Privacy_Admin' => __DIR__ . '/admin/admin.php',
	),
	'textdomain' => null,
);
