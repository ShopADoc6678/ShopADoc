<?php
namespace FileBird\Config;

defined('ABSPATH') || exit;

class Config {
  public static $_config = array(
    'fbv_table' => 'fbv',
    'fbv_relationship_table' => 'fbv_attachment_folder'
  );
  
}
