<div class="fbv-upload-inline">
  <label for="fbv"><?php _e('Choose folder: ', 'filebird') ?></label>
  <div id="fbv-folder-selector" class="fbv-folder-selector" name="fbv"></div>
  <!-- <select name="fbv" id="fbv" class="fbv"> -->
  <?php
    // foreach($tree as $k => $v) {
    //   echo sprintf('<option value="%1$d">%2$s</option>', $v['value'], $v['title']);
    // }
  ?>
  <!-- </select> -->
</div>