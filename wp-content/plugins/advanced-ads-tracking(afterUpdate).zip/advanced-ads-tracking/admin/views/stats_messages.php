<div class="wrap">
	<div class="updated">
		<?php foreach ( $messages as $_message ) : ?>
		<p><?php echo $_message; ?></p>
		<?php endforeach; ?>
	</div>
</div>
