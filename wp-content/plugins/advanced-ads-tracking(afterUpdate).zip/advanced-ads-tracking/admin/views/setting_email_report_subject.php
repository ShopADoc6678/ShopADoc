<input type="text" class="regular-text" name="<?php echo $this->plugin->options_slug; ?>[email-subject]" value="<?php echo esc_attr( $email_subject ); ?>" autocomplete="advads-email-subject"/>
